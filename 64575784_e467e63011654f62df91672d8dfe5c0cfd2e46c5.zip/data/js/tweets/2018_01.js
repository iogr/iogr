Grailbird.data.tweets_2018_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kris Kaspersky",
      "screen_name" : "kris_kaspersky",
      "indices" : [ 48, 63 ],
      "id_str" : "372111077",
      "id" : 372111077
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kris_kaspersky\/status\/780173376316928000\/video\/1",
      "indices" : [ 128, 151 ],
      "url" : "https:\/\/t.co\/QQIwpOZyF6",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/780172506720309248\/pu\/img\/sxbVmD-0_Oz3LtV2.jpg",
      "id_str" : "780172506720309248",
      "id" : 780172506720309248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/780172506720309248\/pu\/img\/sxbVmD-0_Oz3LtV2.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/QQIwpOZyF6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/AbTjL3Ecxo",
      "expanded_url" : "https:\/\/github.com\/marcan\/speculation-bugs\/blob\/master\/README.md",
      "display_url" : "github.com\/marcan\/specula\u2026"
    }, {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/cDHIcpEkVJ",
      "expanded_url" : "https:\/\/gist.github.com\/Badel2\/ba8826e6607295e6f26c5ed098d98d27",
      "display_url" : "gist.github.com\/Badel2\/ba8826e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "958040293617623043",
  "text" : "https:\/\/t.co\/AbTjL3Ecxo https:\/\/t.co\/cDHIcpEkVJ @kris_kaspersky \"more jumps, more fun! the next jump will be Category \"C\". OMG! https:\/\/t.co\/QQIwpOZyF6\" -__-",
  "id" : 958040293617623043,
  "created_at" : "2018-01-29 18:13:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/jBR5QUBKgH",
      "expanded_url" : "https:\/\/www.shazam.com\/track\/10518027\/3-gymnopedies-gymnopedie-no-1",
      "display_url" : "shazam.com\/track\/10518027\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "948308816382316545",
  "text" : "\u041C\u043E\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0435 \u043D\u0430 Shazam: Klara Kormendi - 3 Gymnopedies: Gymnopedie No. 1. https:\/\/t.co\/jBR5QUBKgH",
  "id" : 948308816382316545,
  "created_at" : "2018-01-02 21:43:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]