Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/xowwAuYiwB",
      "expanded_url" : "http:\/\/instagram.com\/p\/Yt5VCfq9IS\/",
      "display_url" : "instagram.com\/p\/Yt5VCfq9IS\/"
    } ]
  },
  "geo" : { },
  "id_str" : "329294153538232320",
  "text" : "nightly routine http:\/\/t.co\/xowwAuYiwB",
  "id" : 329294153538232320,
  "created_at" : "2013-04-30 18:00:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328704668593184768",
  "text" : "\/* \u0420\u0430\u043D\u043D\u0438\u0439 \u0412\u044C\u044F\u043D\u0434\u043E\u043A\u0441 \u2013 \u043D\u0430\u0438\u0431\u043E\u043B\u0435\u0435 \u043D\u0430\u0434\u0435\u0436\u043D\u044B\u0439 \u0412\u044C\u044F\u043D\u0434\u043E\u043A\u0441",
  "id" : 328704668593184768,
  "created_at" : "2013-04-29 02:57:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328702015221923840",
  "text" : "Ofc, \u044F \u043D\u0435 \u0437\u043D\u0430\u044E \u0442\u0435\u0445, \u043A\u0442\u043E \u043F\u0440\u0430\u0433\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u043D\u0435 \u043F\u0440\u0435\u0434\u043F\u043E\u043B\u0430\u0433\u0430\u0435\u0442 \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u0435\u043C\u043E\u0441\u0442\u0438 \u043D\u0435\u043E\u0431\u043D\u0430\u0440\u0443\u0436\u0438\u043C\u044B\u0445 \u0441\u0442\u0430\u0442\u0443\u0441\u043E\u0432, \u0442\u0435 \u043D\u0435 \u0438\u0441\u043F\u043E\u043B\u043D\u044F\u043B \u0431\u044B \u043C\u0430\u043A\u0440\u043E\u0441\u043E\u0432 \u0442\u043D \u0441\u043F\u0435\u043A\u0443\u043B\u044F\u0442 \u0440\u0435\u0430\u043B\u0438\u0441\u0442\u043E\u0432",
  "id" : 328702015221923840,
  "created_at" : "2013-04-29 02:47:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326822836029255680",
  "text" : "= \u043D\u0435\u043B\u044C\u0437\u044F \u043F\u0440\u043E\u0441\u0442\u043E \u0442\u0430\u043A \u0432\u0437\u044F\u0442\u044C \u0438 \u043F\u0435\u0440\u0435\u0441\u0442\u0430\u0442\u044C \u0431\u044B\u0442\u044C \u0438\u0434\u0438\u043E\u0442\u043E\u043C",
  "id" : 326822836029255680,
  "created_at" : "2013-04-23 22:20:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326822682635145216",
  "text" : "wannabe \u043E\u0336\u0434\u0336\u0438\u0336\u043D\u0336\u043E\u0336\u043A\u0336\u0438\u0336\u0439\u0336 \u0336\u0441\u0336\u043E\u0336\u0446\u0336\u0438\u0336\u043E\u0336\u0444\u0336\u043E\u0336\u0431\u0336\u043D\u0336\u044B\u0336\u0439\u0336 \u0336\u043D\u0336\u0435\u0336\u0432\u0336\u0440\u0336\u043E\u0336\u0442\u0336\u0438\u0336\u043A\u0336, \nyou might heal me, heal, our lady of the forsaken,\nblue kurosawa",
  "id" : 326822682635145216,
  "created_at" : "2013-04-23 22:19:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322072907205464064",
  "text" : "Rivka, zero in condotta",
  "id" : 322072907205464064,
  "created_at" : "2013-04-10 19:45:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "321468726505521152",
  "text" : "\u00E0\u0336\u03C5\u0336\u03AC\u0336\u03BA\u0336\u03BB\u0336\u03B1\u0336\u03C3\u0336\u03B9\u0336\u03C2\u0336 \u0336",
  "id" : 321468726505521152,
  "created_at" : "2013-04-09 03:44:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/LVSR2jNL4k",
      "expanded_url" : "http:\/\/youtu.be\/IzVqnsFVaUw",
      "display_url" : "youtu.be\/IzVqnsFVaUw"
    } ]
  },
  "geo" : { },
  "id_str" : "321451514839314433",
  "text" : "http:\/\/t.co\/LVSR2jNL4k &lt;3 &lt;3",
  "id" : 321451514839314433,
  "created_at" : "2013-04-09 02:36:28 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/T0zgdD3O00",
      "expanded_url" : "https:\/\/pbs.twimg.com\/media\/BHFnkYxCQAIe9Yo.jpg",
      "display_url" : "pbs.twimg.com\/media\/BHFnkYxC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320758394069864450",
  "text" : "https:\/\/t.co\/T0zgdD3O00 summa theologi\u00E6 as of yet",
  "id" : 320758394069864450,
  "created_at" : "2013-04-07 04:42:15 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/dg0RxxjLdH",
      "expanded_url" : "http:\/\/www.signosemio.com\/documents\/dictionnaire-semiotique-generale.pdf",
      "display_url" : "signosemio.com\/documents\/dict\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320353560468549632",
  "text" : "http:\/\/t.co\/dg0RxxjLdH",
  "id" : 320353560468549632,
  "created_at" : "2013-04-06 01:53:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320181942383423488",
  "text" : "1. \u043E\u0431\u043E\u0436\u0430\u043B lucasfilm games; 2. \u043F\u043E\u0431\u0440\u0438\u0432\u0448\u0438\u0441\u044C, \u043E\u0431\u043D\u0430\u0440\u0443\u0436\u0438\u0432\u0430\u043B \u0441\u0445\u043E\u0434\u0441\u0442\u0432\u043E \u0441 \u044D\u0431\u0435\u0440\u0442\u043E\u043C. *\u0445\u0438\u0442\u0447\u0435\u043D\u0441, \u0431\u044D\u043D\u043A\u0441, \u0441\u044B\u043D \u044D\u043C\u0438\u0441\u0430 (terminus?) = no, no, no",
  "id" : 320181942383423488,
  "created_at" : "2013-04-05 14:31:38 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]