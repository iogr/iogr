Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419502182292287488",
  "text" : "\u041B\u044E\u0434\u0438 \u0434\u0435\u043B\u044F\u0442\u0441\u044F \u043D\u0430 \u0442\u0435\u0445, \u043A\u0442\u043E \u0441\u0442\u0430\u0432\u0438\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u043F\u043B\u0430\u0441\u0442\u0438\u043D\u043A\u0438 \u043D\u0430 78 \u043E\u0431\u043E\u0440\u043E\u0442\u043E\u0432 \u0438 \u0442\u0435\u0445, \u0443 \u043A\u043E\u0433\u043E \u0432\u0441\u0435\u0433\u0434\u0430 \u0437\u0430\u0435\u043B\u043E \u0441\u043E\u0440\u043A\u043E\u043F\u044F\u0442\u043A\u0443.",
  "id" : 419502182292287488,
  "created_at" : "2014-01-04 16:14:48 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]