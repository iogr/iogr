Grailbird.data.tweets_2018_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/QvJDwuHeLa",
      "expanded_url" : "https:\/\/www.shazam.com\/track\/56025228\/gentle-disturbed",
      "display_url" : "shazam.com\/track\/56025228\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "959340006786719745",
  "text" : "Shazam: Avishai Cohen Trio - Gentle Disturbed. https:\/\/t.co\/QvJDwuHeLa",
  "id" : 959340006786719745,
  "created_at" : "2018-02-02 08:17:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]