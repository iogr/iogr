Grailbird.data.tweets_2015_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "638009369666416640",
  "text" : "catched a fancy for Adam Green\u2019s songs",
  "id" : 638009369666416640,
  "created_at" : "2015-08-30 15:24:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/pGqXu1NbBr",
      "expanded_url" : "http:\/\/youtu.be\/WCm0VbXgbsQ",
      "display_url" : "youtu.be\/WCm0VbXgbsQ"
    } ]
  },
  "geo" : { },
  "id_str" : "637848240713564160",
  "text" : "\u041C\u043E\u0442\u0442\u0438 \u0438 \u0448\u0442\u0443\u0434\u0438\u0438 http:\/\/t.co\/pGqXu1NbBr",
  "id" : 637848240713564160,
  "created_at" : "2015-08-30 04:44:05 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "637295313594773504",
  "text" : "\u0412\u0438\u043A\u0442\u043E\u0440 \u0411\u0443\u0442 \u0437\u0430\u044F\u0432\u0438\u043B, \u0447\u0442\u043E \u0447\u0430\u0439\u043D\u044B\u0439 \u0433\u0440\u0438\u0431 \u2014 \u043F\u0440\u043E\u0445\u043E\u0434 \u0432 \u0434\u0440\u0443\u0433\u0443\u044E \u0432\u0441\u0435\u043B\u0435\u043D\u043D\u0443\u044E",
  "id" : 637295313594773504,
  "created_at" : "2015-08-28 16:06:57 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "635960295853309952",
  "text" : "\u0414\u0436\u043E\u043D\u043D\u0438 \u0414\u0438 \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u0438\u0442 \u043D\u043E\u0432\u044B\u0439 \u0430\u0440\u043E\u043C\u0430\u0442 Dior \u0432 \u043F\u0443\u0441\u0442\u044B\u043D\u0435 \u0437\u043D\u0430\u043A\u043E\u0432\u044B\u0445 \u0441\u0438\u0441\u0442\u0435\u043C, \u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0432\u044B\u0442\u0440\u044F\u0445\u0438\u0432\u0430\u0442\u044C \u0441\u0435\u0431\u044F - \u0431\u0443\u0434\u0442\u043E \u043C\u0435\u0431\u0435\u043B\u044C \u0432 \u0431\u043E\u0440\u0434\u0435\u043B\u0435 \u0434\u0432\u0438\u0433\u0430\u0442\u044C.",
  "id" : 635960295853309952,
  "created_at" : "2015-08-24 23:42:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634767190135296000",
  "text" : "\u0418\u0441\u0442\u043E\u0440\u0438\u044F \u043B\u044E\u0431\u0432\u0438 \u043A\u043E\u0440\u0430\u0431\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u0442\u0430\u0442\u0443\u0438\u0440\u043E\u0432\u0449\u0438\u043A\u0430 \u0438 \u0434\u0440\u0435\u0441\u0441\u0438\u0440\u043E\u0432\u0449\u0438\u0446\u044B \u0434\u0435\u043B\u044C\u0444\u0438\u043D\u043E\u0432 \u0433\u0434\u0435-\u043D\u0438\u0431\u0443\u0434\u044C \u043D\u0430 \u0421\u0432\u044F\u0442\u043E\u0439 \u0437\u0435\u043C\u043B\u0435",
  "id" : 634767190135296000,
  "created_at" : "2015-08-21 16:41:06 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "634495666463580162",
  "text" : "\u041A\u0443\u0440\u0441 \u0434\u043E\u043B\u043B\u0430\u0440\u0430 \u043F\u0440\u0435\u0432\u044B\u0441\u0438\u043B \u05E1\u05EA \u0440\u0443\u0431\u043B\u0435\u0439",
  "id" : 634495666463580162,
  "created_at" : "2015-08-20 22:42:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632618272010190848",
  "text" : "\u0418\u0441\u0442\u043E\u043A \u0441\u043E\u0441\u0443\u0434\u0430 &gt; Campari &gt; \u05D4\u05DB\u05DE\u05D4 &gt; Curacao &gt; \u05D1\u05D9\u05E0\u05D4 &gt; Kir &gt; \u05D3\u05E2\u05EA &gt; Lemoncello &gt; \u0418\u0441\u0442\u043E\u043A \u0441\u0432\u0435\u0442\u0430 &gt; \u041A\u0430\u0442\u044F \u0421\u0430\u043C\u0431\u0443\u043A\u0430. \u041F\u043E\u0434\u0430\u0432\u0430\u0442\u044C \u0441 \u043A\u043E\u043A\u0442\u0435\u0439\u043B\u044C\u043D\u043E\u0439 \u0441\u043E\u043B\u043E\u043C\u0438\u043D\u043A\u043E\u0439",
  "id" : 632618272010190848,
  "created_at" : "2015-08-15 18:22:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632614828419457024",
  "text" : "\u0437\u0430\u0439\u0434\u0438 \u043B\u0435\u0442\u043E\u043C, \u0432\u044B\u0439\u0434\u0435\u0448\u044C \u043B\u044C\u0434\u043E\u043C",
  "id" : 632614828419457024,
  "created_at" : "2015-08-15 18:08:23 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "632588704536756224",
  "text" : "\u043F\u043E\u0445\u043C\u0435\u043B\u044C\u043D\u044B\u0439 \u0441\u043F\u043B\u0438\u043D, \u0442\u043E\u0441\u043A\u0430, \u043B\u0430\u0441\u043A\u043E\u0432\u0430\u044F \u0441\u043C\u0435\u0440\u0442\u044C \u043F\u0440\u043E\u0448\u043B\u043E\u0433\u043E, purple haze of hendrix day-long and a slightly bit of john mayer",
  "id" : 632588704536756224,
  "created_at" : "2015-08-15 16:24:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "631192375830933505",
  "text" : "\u0432\u043E\u0442 \u0438 \u0441\u043B\u0430\u0432\u043D\u043E. \u0440\u0430\u0434\u0443\u0435\u0442, \u0447\u0442\u043E \u0442\u044B, \u0445\u043E\u0442\u044F \u0431\u044B, \u0432\u044B\u0431\u0435\u0440\u0435\u0448\u044C \u0432 \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u0435 \u0442\u0435\u043C\u044B \u0434\u043B\u044F \u0432\u0442\u043E\u0440\u043E\u0433\u043E \u0440\u043E\u043C\u0430\u043D\u0430 \u043D\u0435 \u0431\u044B\u0442 \u0438\u0437\u0440\u0430\u0438\u043B\u044C\u0441\u043A\u043E\u0439 \u0435\u0448\u0438\u0432\u044B. \u043D\u0435\u0442, \u043D\u0443 \u043F\u0440\u0430\u0432\u0434\u0430? shivers",
  "id" : 631192375830933505,
  "created_at" : "2015-08-11 19:56:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]