Grailbird.data.tweets_2014_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "491277815858221056",
  "text" : "\u0422\u0435\u043B\u044C-\u0410\u0432\u0438\u0432 \u0445\u043E\u0440\u043E\u0448\u0438\u0439, \u0432\u043A\u043B\u044E\u0447\u0430\u044F \u0435\u0436\u0435\u0434\u043D\u0435\u0432\u043D\u044B\u0435 \u0432\u0437\u0440\u044B\u0432\u044B \u0441\u043D\u0430\u0440\u044F\u0434\u043E\u0432. \u0435\u0436\u0435\u0434\u043D\u0435\u0432\u043D\u043E \u0440\u0435\u043F\u0435\u0442\u0438\u0440\u0443\u0435\u0448\u044C \u043E\u0442\u0434\u044B\u0445, \u044D\u0442\u043E\u0442 \u0441\u043A\u0440\u043E\u043C\u043D\u044B\u0439 \u0431\u0443\u043A\u0435\u0442 \u0441\u0443\u0438\u0446\u0438\u0434\u0430\u043B\u044C\u043D\u044B\u0445 \u043F\u0440\u0430\u043A\u0442\u0438\u043A",
  "id" : 491277815858221056,
  "created_at" : "2014-07-21 17:45:33 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "486842135216680961",
  "text" : "parker 98",
  "id" : 486842135216680961,
  "created_at" : "2014-07-09 11:59:44 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]