Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/snapguide\/id421477397?mt=8&uo=4\" rel=\"nofollow\"\u003ESnapguide on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapguide",
      "screen_name" : "Snapguide",
      "indices" : [ 23, 33 ],
      "id_str" : "250403328",
      "id" : 250403328
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iogr\/status\/186189407248850944\/photo\/1",
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/RlJpxQ0F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApV6R4hCIAIG0LW.jpg",
      "id_str" : "186189407253045250",
      "id" : 186189407253045250,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApV6R4hCIAIG0LW.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 508
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 857,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 857,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 857,
        "resize" : "fit",
        "w" : 640
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/RlJpxQ0F"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/cRIlXVly",
      "expanded_url" : "http:\/\/snp.gd\/tv5ha",
      "display_url" : "snp.gd\/tv5ha"
    } ]
  },
  "geo" : { },
  "id_str" : "186189407248850944",
  "text" : "the secret is revealed @Snapguide http:\/\/t.co\/cRIlXVly http:\/\/t.co\/RlJpxQ0F",
  "id" : 186189407248850944,
  "created_at" : "2012-03-31 20:33:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/bmalqobm",
      "expanded_url" : "http:\/\/4sq.com\/GZL4ag",
      "display_url" : "4sq.com\/GZL4ag"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7624747461, 37.6065444946 ]
  },
  "id_str" : "186103003357511682",
  "text" : "\u0422\u0438\u0446\u0438\u0430\u043D\u043E \u0421\u043A\u0430\u0440\u043F\u0430 \"\u0424\u0443\u043D\u0434\u0430\u043C\u0435\u043D\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u0432\u0435\u0449\u0438\" , \u0420\u043E\u043C\u0430\u043D \u0421\u0435\u043D\u0438\u0447 \"\u0422\u0443\u0432\u0430\", \u041F\u0438\u0442\u0435\u0440 \u0413\u0435\u043B\u0434\u0435\u0440\u043B\u043E\u043E\u0441 \"\u0410\u043D\u0430\u0440\u0445\u0438\u044F \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442\" for vegging out with http:\/\/t.co\/bmalqobm",
  "id" : 186103003357511682,
  "created_at" : "2012-03-31 14:49:48 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 50, 61 ],
      "id_str" : "804341497441255424",
      "id" : 804341497441255424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/1A9Uj2Po",
      "expanded_url" : "http:\/\/4sq.com\/HagYPI",
      "display_url" : "4sq.com\/HagYPI"
    } ]
  },
  "geo" : { },
  "id_str" : "186095965051174913",
  "text" : "I just unlocked the Level 2 \"Fresh Brew\" badge on @foursquare! In it to win it! http:\/\/t.co\/1A9Uj2Po",
  "id" : 186095965051174913,
  "created_at" : "2012-03-31 14:21:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 38, 49 ],
      "id_str" : "804341497441255424",
      "id" : 804341497441255424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/3DiTZXSf",
      "expanded_url" : "http:\/\/4sq.com\/H3nD4l",
      "display_url" : "4sq.com\/H3nD4l"
    } ]
  },
  "geo" : { },
  "id_str" : "185724555602563074",
  "text" : "I just unlocked the \"9 to 5\" badge on @foursquare! http:\/\/t.co\/3DiTZXSf",
  "id" : 185724555602563074,
  "created_at" : "2012-03-30 13:45:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guybrush Threepwood",
      "screen_name" : "GUThreepwood",
      "indices" : [ 3, 16 ],
      "id_str" : "259819020",
      "id" : 259819020
    }, {
      "name" : "Hermione Swanson \u26A7",
      "screen_name" : "altergrounds",
      "indices" : [ 18, 31 ],
      "id_str" : "104934666",
      "id" : 104934666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185646102215802880",
  "text" : "RT @GUThreepwood: @altergrounds what are ya El Loco Del Chocko the west coast carribean rapper? I'm Guybrush Threeowood a mighty pirate  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hermione Swanson \u26A7",
        "screen_name" : "altergrounds",
        "indices" : [ 0, 13 ],
        "id_str" : "104934666",
        "id" : 104934666
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "184671410252283905",
    "geo" : { },
    "id_str" : "184735200507478016",
    "in_reply_to_user_id" : 104934666,
    "text" : "@altergrounds what are ya El Loco Del Chocko the west coast carribean rapper? I'm Guybrush Threeowood a mighty pirate now prepare to die!",
    "id" : 184735200507478016,
    "in_reply_to_status_id" : 184671410252283905,
    "created_at" : "2012-03-27 20:14:38 +0000",
    "in_reply_to_screen_name" : "altergrounds",
    "in_reply_to_user_id_str" : "104934666",
    "user" : {
      "name" : "Guybrush Threepwood",
      "screen_name" : "GUThreepwood",
      "protected" : false,
      "id_str" : "259819020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1260425388\/FancyPants_normal.jpg",
      "id" : 259819020,
      "verified" : false
    }
  },
  "id" : 185646102215802880,
  "created_at" : "2012-03-30 08:34:14 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Gilbert",
      "screen_name" : "grumpygamer",
      "indices" : [ 3, 15 ],
      "id_str" : "27531390",
      "id" : 27531390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185645671238471680",
  "text" : "RT @grumpygamer: Designing good adventure game puzzles is 25% puzzle design, 75% worrying.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185487256822366208",
    "text" : "Designing good adventure game puzzles is 25% puzzle design, 75% worrying.",
    "id" : 185487256822366208,
    "created_at" : "2012-03-29 22:03:02 +0000",
    "user" : {
      "name" : "Ron Gilbert",
      "screen_name" : "grumpygamer",
      "protected" : false,
      "id_str" : "27531390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948363930799194112\/0rRngzhC_normal.jpg",
      "id" : 27531390,
      "verified" : true
    }
  },
  "id" : 185645671238471680,
  "created_at" : "2012-03-30 08:32:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "knowledgestream",
      "indices" : [ 30, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185428163411722241",
  "text" : "\u0421\u043E\u0433\u043B\u0430\u0441\u0435\u043D \u0442\u043E\u043B\u044C\u043A\u043E \u0441 \u0420\u0430\u0431\u0438\u043D\u043E\u0432\u0438\u0447\u0435\u043C #knowledgestream",
  "id" : 185428163411722241,
  "created_at" : "2012-03-29 18:08:13 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "knowledgestream",
      "indices" : [ 109, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185415788071620608",
  "text" : "\"\u041D\u0443\u0436\u043D\u0430 \u0441\u043C\u0435\u043B\u043E\u0441\u0442\u044C \u0447\u0442\u043E\u0431\u044B \u043E\u0442\u043A\u0430\u0437\u0430\u0442\u044C\u0441\u044F \u043E\u0442 \u0442\u043E\u0433\u043E, \u0447\u0442\u043E \u043D\u0435 \u043F\u0440\u0438\u043D\u043E\u0441\u0438\u0442 \u0432\u0430\u043C \u043F\u0440\u0438\u0431\u044B\u043B\u0438\" \u0414\u0410! \u042F \u0443\u0436\u0435 \u043E\u0442\u043A\u0430\u0437\u0430\u043B\u0441\u044F \u043E\u0442 \u043D\u0438\u0436\u043D\u0435\u0433\u043E \u0431\u0435\u043B\u044C\u044F! #knowledgestream",
  "id" : 185415788071620608,
  "created_at" : "2012-03-29 17:19:03 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "knowledgestream",
      "indices" : [ 103, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185411623693987841",
  "text" : "\u041E\u0431\u0440\u0430\u0442\u0438\u0442\u0435 \u0432\u043D\u0438\u043C\u0430\u043D\u0438\u0435 \u043D\u0430 \u0435\u0433\u043E \u043D\u0430\u0442\u0440\u0435\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0433\u043E\u043B\u043E\u0441. \"Hello, my name is John and you're all my bitches now\" #knowledgestream",
  "id" : 185411623693987841,
  "created_at" : "2012-03-29 17:02:30 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "knowledgestream",
      "indices" : [ 72, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185406153696616450",
  "text" : "\u0423 \u043C\u0435\u043D\u044F \u043E\u0434\u0438\u043D \u0448\u0430\u0440 \u043F\u043E\u0445\u043E\u0436 \u043D\u0430 \u0444\u0443\u043D\u0434\u0443\u043A, \u0434\u0440\u0443\u0433\u043E\u0439 \u043D\u0430 \u043A\u0435\u0448\u044C\u044E - \u043A\u043E\u043C\u0443 \u043E\u0440\u0435\u0445\u043E\u0432\u043E\u0439 \u043F\u0430\u0441\u0442\u044B? #knowledgestream",
  "id" : 185406153696616450,
  "created_at" : "2012-03-29 16:40:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/DPGBa1Do",
      "expanded_url" : "http:\/\/4sq.com\/H114wo",
      "display_url" : "4sq.com\/H114wo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7406564357, 37.6090550423 ]
  },
  "id_str" : "185405476580769792",
  "text" : "I'm at Digital October (\u041C\u043E\u0441\u043A\u0432\u0430, \u0420\u043E\u0441\u0441\u0438\u044F) w\/ 35 others http:\/\/t.co\/DPGBa1Do",
  "id" : 185405476580769792,
  "created_at" : "2012-03-29 16:38:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184599473819885568",
  "text" : "\u0412\u0430\u0436\u043D\u043E: \u043D\u0435 \u0437\u0430\u0431\u044B\u0442\u044C \u043E\u0434\u0435\u0442\u044C \u0441\u043E\u0442\u043A\u0430\u043D\u043D\u0443\u044E \u0441\u0432\u0435\u0442\u043E\u043C \u0442\u0435\u043D\u0435\u0433\u043E\u0440\u043D\u0441\u043A\u0443\u044E \u0445\u043B\u0430\u043C\u0438\u0434\u0443 \u043F\u043E\u0434 \u043C\u043E\u044E \u0442\u0440\u0438\u0441\u0444\u0430\u043B\u044C\u0441\u043A\u0443\u044E \u043C\u0430\u043D\u0442\u0438\u044E \u0437\u0430\u043A\u0440\u044B\u0442\u044B\u0445 \u0434\u0432\u0435\u0440\u0435\u0439",
  "id" : 184599473819885568,
  "created_at" : "2012-03-27 11:15:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184599321122062336",
  "text" : "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u0431\u0443\u0434\u0443 \u0432 \u041D\u041C\u0423 \u0441 \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u044B\u043C \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u043E\u043C \u043E \u0431\u0443\u0434\u0443\u0449\u0435\u043C \u0435\u0433\u043E \u0444\u0438\u043D\u0430\u043D\u0441\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F.",
  "id" : 184599321122062336,
  "created_at" : "2012-03-27 11:14:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.azumio.com\" rel=\"nofollow\"\u003EAzumio\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instantheartrate",
      "indices" : [ 24, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/bp3EeeXB",
      "expanded_url" : "http:\/\/goo.gl\/4x4uz",
      "display_url" : "goo.gl\/4x4uz"
    } ]
  },
  "geo" : { },
  "id_str" : "184256027338878976",
  "text" : "My heart rate is 64bpm. #instantheartrate http:\/\/t.co\/bp3EeeXB",
  "id" : 184256027338878976,
  "created_at" : "2012-03-26 12:30:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/the-eatery\/id468299990?mt=8&uo=4\" rel=\"nofollow\"\u003EThe Eatery on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eatery",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 91 ],
      "url" : "https:\/\/t.co\/RNVrpueK",
      "expanded_url" : "https:\/\/eatery.massivehealth.com\/foods\/f49c8a15-afea-497e-8103-73566e4727f5",
      "display_url" : "eatery.massivehealth.com\/foods\/f49c8a15\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "184252254734397440",
  "text" : "Just ate Shroom soup at Cafe Brocard. See how healthy it was. #eatery https:\/\/t.co\/RNVrpueK",
  "id" : 184252254734397440,
  "created_at" : "2012-03-26 12:15:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/the-eatery\/id468299990?mt=8&uo=4\" rel=\"nofollow\"\u003EThe Eatery on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eatery",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 85 ],
      "url" : "https:\/\/t.co\/dRlk72UV",
      "expanded_url" : "https:\/\/eatery.massivehealth.com\/foods\/76aba976-4490-41a8-b19a-5d7157e7f097",
      "display_url" : "eatery.massivehealth.com\/foods\/76aba976\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "184252067739742209",
  "text" : "Just ate Salad at Cafe Brocard. See how healthy it was. #eatery https:\/\/t.co\/dRlk72UV",
  "id" : 184252067739742209,
  "created_at" : "2012-03-26 12:14:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/H9mNgCBq",
      "expanded_url" : "http:\/\/img.ly\/fNk6",
      "display_url" : "img.ly\/fNk6"
    } ]
  },
  "geo" : { },
  "id_str" : "184250751135125504",
  "text" : "\u041A\u0440\u0430\u0442\u043A\u043E\u0435 \u0441\u043E\u0434\u0435\u0440\u0436\u0430\u043D\u0438\u0435 \u043F\u0440\u043E\u0448\u0435\u0434\u0448\u0435\u0433\u043E \u0432\u043E\u0441\u043A\u0440\u0435\u0441\u0435\u043D\u0438\u044F (2 \u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0438\u0438, \u043E\u0431\u0441\u0443\u0436\u0434\u0435\u043D\u0438\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u0438\u0445 \u043F\u0440\u043E\u0435\u043A\u0442\u043E\u0432): http:\/\/t.co\/H9mNgCBq",
  "id" : 184250751135125504,
  "created_at" : "2012-03-26 12:09:36 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/jXYDTIZK",
      "expanded_url" : "http:\/\/levelss.com",
      "display_url" : "levelss.com"
    }, {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/v0e0wm1Z",
      "expanded_url" : "http:\/\/4sq.com\/H9hMr1",
      "display_url" : "4sq.com\/H9hMr1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.8044724784, 37.5852704117 ]
  },
  "id_str" : "184215056383361024",
  "text" : "I'm at Levels MAS &gt; http:\/\/t.co\/jXYDTIZK (Moscow) http:\/\/t.co\/v0e0wm1Z",
  "id" : 184215056383361024,
  "created_at" : "2012-03-26 09:47:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/the-eatery\/id468299990?mt=8&uo=4\" rel=\"nofollow\"\u003EThe Eatery on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eatery",
      "indices" : [ 74, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 103 ],
      "url" : "https:\/\/t.co\/sbxVundM",
      "expanded_url" : "https:\/\/eatery.massivehealth.com\/foods\/7a69b13b-0322-4b67-88e4-ec72cc779ec4",
      "display_url" : "eatery.massivehealth.com\/foods\/7a69b13b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "183913457500950528",
  "text" : "Just ate Choke at \u0414\u0438\u0437\u0430\u0439\u043D-\u0437\u0430\u0432\u043E\u0434 \"\u0424\u043B\u0430\u043A\u043E\u043D\" (Flacon). See how healthy it was. #eatery https:\/\/t.co\/sbxVundM",
  "id" : 183913457500950528,
  "created_at" : "2012-03-25 13:49:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/fontli\/id506650372?mt=8&uo=4\" rel=\"nofollow\"\u003EFontli on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/j2q5LDRP",
      "expanded_url" : "http:\/\/www.fontli.com\/UGhvdG9fNGY2ZjBiYjgwNWFhMTcwOTE5MDAwMGU2",
      "display_url" : "fontli.com\/UGhvdG9fNGY2Zj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "183889326030073856",
  "text" : "Sharing a post from Fontli http:\/\/t.co\/j2q5LDRP",
  "id" : 183889326030073856,
  "created_at" : "2012-03-25 12:13:26 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/the-eatery\/id468299990?mt=8&uo=4\" rel=\"nofollow\"\u003EThe Eatery on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eatery",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 84 ],
      "url" : "https:\/\/t.co\/1yXaHXt9",
      "expanded_url" : "https:\/\/eatery.massivehealth.com\/foods\/cf9dfb6f-7f8d-4fc3-a0e3-96b9f8107146",
      "display_url" : "eatery.massivehealth.com\/foods\/cf9dfb6f\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "183838117957087232",
  "text" : "Just ate this at Cafe Brocard. See how healthy it was. #eatery https:\/\/t.co\/1yXaHXt9",
  "id" : 183838117957087232,
  "created_at" : "2012-03-25 08:49:57 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 39, 50 ],
      "id_str" : "804341497441255424",
      "id" : 804341497441255424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/qkfoxvmQ",
      "expanded_url" : "http:\/\/4sq.com\/GNnk6H",
      "display_url" : "4sq.com\/GNnk6H"
    } ]
  },
  "geo" : { },
  "id_str" : "183645606684798976",
  "text" : "I just unlocked the \"Crunked\" badge on @foursquare! http:\/\/t.co\/qkfoxvmQ",
  "id" : 183645606684798976,
  "created_at" : "2012-03-24 20:04:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/isXDk1uy",
      "expanded_url" : "http:\/\/4sq.com\/GNnj2K",
      "display_url" : "4sq.com\/GNnj2K"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7655498, 37.610998 ]
  },
  "id_str" : "183645606919684097",
  "text" : "Duck yeah (@ ArteFAQ w\/ 16 others) http:\/\/t.co\/isXDk1uy",
  "id" : 183645606919684097,
  "created_at" : "2012-03-24 20:04:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183594658172112896",
  "text" : "\"\u0412\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0435 \u043F\u043E\u044F\u0432\u043B\u0435\u043D\u0438\u0435 \u0437\u0430\u043C\u044B\u043A\u0430\u043D\u0438\u0439 \u0432 Java \u0441\u0442\u0430\u043B\u043E \u0433\u043E\u0440\u044F\u0447\u0435\u0439 \u0442\u0435\u043C\u043E\u0439 \u0434\u043B\u044F \u043E\u0431\u0441\u0443\u0436\u0434\u0435\u043D\u0438\u0439.\" :)",
  "id" : 183594658172112896,
  "created_at" : "2012-03-24 16:42:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anton Gorbunov",
      "screen_name" : "iogr",
      "indices" : [ 0, 5 ],
      "id_str" : "64575784",
      "id" : 64575784
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "santa",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182919361516945409",
  "in_reply_to_user_id" : 64575784,
  "text" : "@iogr: \u041F\u043E\u043D\u0438\u043C\u0430\u044E, \u0447\u0442\u043E \u044D\u0442\u043E \u043D\u0435 \u0442\u0430\u043A \u043F\u0440\u043E\u0441\u0442\u043E, \u043D\u043E \u044F \u0437\u0430\u0433\u0430\u0434\u0430\u043B \u043D\u0430 \u041D\u0413 \u0441\u0442\u0430\u0442\u044C \u0433\u0435\u043D. \u0441\u0435\u043A\u0440\u0435\u0442\u0430\u0440\u0435\u043C \u0421\u0435\u0432\u0435\u0440\u043D\u043E\u0439 \u041A\u043E\u0440\u0435\u0438 \u0438 \u0432\u0441\u0435 \u0435\u0449\u0435 \u043D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B \u0443\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F #santa",
  "id" : 182919361516945409,
  "created_at" : "2012-03-22 19:59:08 +0000",
  "in_reply_to_screen_name" : "iogr",
  "in_reply_to_user_id_str" : "64575784",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182916863389474817",
  "text" : "\u042F \u0443\u0432\u0430\u0436\u0430\u044E freemium, \u043D\u043E \u043D\u0435 \u043D\u0443\u0436\u043D\u043E \u043F\u0440\u043E\u0434\u0430\u0432\u0430\u0442\u044C \u043C\u043D\u0435 \u0442\u0440\u0435\u0445\u043A\u043E\u043B\u0435\u0441\u043D\u044B\u0439 \u0430\u0432\u0442\u043E\u043C\u043E\u0431\u0438\u043B\u044C \u0438 \u0437\u0443\u0431\u043D\u0443\u044E \u0449\u0435\u0442\u043A\u0443 \u0441 \u043D\u0435\u0431\u043E\u043B\u044C\u0448\u0438\u043C \u0441\u0435\u043A\u0440\u0435\u0442\u043E\u043C. seems like you know what i'm about",
  "id" : 182916863389474817,
  "created_at" : "2012-03-22 19:49:13 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/the-eatery\/id468299990?mt=8&uo=4\" rel=\"nofollow\"\u003EThe Eatery on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eatery",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 102 ],
      "url" : "https:\/\/t.co\/48pagNu5",
      "expanded_url" : "https:\/\/eatery.massivehealth.com\/foods\/aafe7fe2-ce5c-4cd8-b714-d4ece1cca96f",
      "display_url" : "eatery.massivehealth.com\/foods\/aafe7fe2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182844341520314368",
  "text" : "Just ate this at \u0414\u0438\u0437\u0430\u0439\u043D-\u0437\u0430\u0432\u043E\u0434 \"\u0424\u043B\u0430\u043A\u043E\u043D\" (Flacon). See how healthy it was. #eatery https:\/\/t.co\/48pagNu5",
  "id" : 182844341520314368,
  "created_at" : "2012-03-22 15:01:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/uXQ1gBDc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=wgJfVRhotlQ",
      "display_url" : "youtube.com\/watch?v=wgJfVR\u2026"
    }, {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/qKnrCmla",
      "expanded_url" : "http:\/\/i373.photobucket.com\/albums\/oo172\/hvigilla\/beautifulcat.jpg",
      "display_url" : "i373.photobucket.com\/albums\/oo172\/h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182784236825219073",
  "text" : "http:\/\/t.co\/uXQ1gBDc\nhttp:\/\/t.co\/qKnrCmla\n\u043A\u0442\u043E \u043F\u0435\u0440\u0432\u044B\u043C \u0441\u043E\u0431\u0435\u0440\u0435\u0442 \u0432 \u043C\u0430\u0439\u043D\u043A\u0440\u0430\u0444\u0442\u0435 \u043C\u043E\u043D\u0438\u0442\u043E\u0440, cpu, gpu \u0438 \u0438\u043D\u0442\u0435\u0440\u043F\u0440\u0435\u0442\u0430\u0442\u043E\u0440, \u0447\u0442\u043E\u0431\u044B \u043D\u0430\u043F\u0438\u0441\u0430\u0442\u044C \u0441\u0430\u043C \u043C\u0430\u0439\u043D\u043A\u0440\u0430\u0444\u0442?",
  "id" : 182784236825219073,
  "created_at" : "2012-03-22 11:02:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eatery",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182452845205921793",
  "text" : "\u041D\u0430 \u0434\u0430\u043D\u043D\u044B\u0439 \u043C\u043E\u043C\u0435\u043D\u0442 \u043F\u043E\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u0438 The Eatery \u043E\u0446\u0435\u043D\u0438\u043B\u0438 \u0432 \u0441\u0440\u0435\u0434\u043D\u0435\u043C \u0431\u0443\u0442\u044B\u043B\u043A\u0443 \u0432\u043E\u0434\u044B \u043A\u0430\u043A \u043D\u0430 97% \u0437\u0434\u043E\u0440\u043E\u0432\u0443\u044E. \u041A\u0430\u0440\u0443\u0441\u0435\u043B\u044C, \u043E\u0442\u043A\u0440\u0435\u043F\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0435? #eatery",
  "id" : 182452845205921793,
  "created_at" : "2012-03-21 13:05:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/the-eatery\/id468299990?mt=8&uo=4\" rel=\"nofollow\"\u003EThe Eatery on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eatery",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 84 ],
      "url" : "https:\/\/t.co\/K67bRiA6",
      "expanded_url" : "https:\/\/eatery.massivehealth.com\/foods\/0ef933fd-f929-4567-b7df-7459074009b2",
      "display_url" : "eatery.massivehealth.com\/foods\/0ef933fd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182452520281571329",
  "text" : "Just ate this at Cafe Brocard. See how healthy it was. #eatery https:\/\/t.co\/K67bRiA6",
  "id" : 182452520281571329,
  "created_at" : "2012-03-21 13:04:05 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrey Vinokurov",
      "screen_name" : "Yuusou1989",
      "indices" : [ 0, 11 ],
      "id_str" : "255977897",
      "id" : 255977897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182380850686603264",
  "geo" : { },
  "id_str" : "182448959489454080",
  "in_reply_to_user_id" : 255977897,
  "text" : "@Yuusou1989 \u0437\u0430\u0447\u0435\u043A\u0438\u043D\u0438\u0442\u044C\u0441\u044F \u0432 \u043F\u0430\u043D\u043E\u043F\u0442\u0438\u043A\u0443\u043C\u0435, \u0434\u0430. \u041F\u0440\u0438\u0447\u0435\u043C \u0447\u0435\u0440\u0435\u0437 \u043F\u0430\u043D\u0435\u043B\u044C )",
  "id" : 182448959489454080,
  "in_reply_to_status_id" : 182380850686603264,
  "created_at" : "2012-03-21 12:49:56 +0000",
  "in_reply_to_screen_name" : "Yuusou1989",
  "in_reply_to_user_id_str" : "255977897",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0424-\u0442 \u043F\u043E\u043B\u0438\u0442\u043E\u043B\u043E\u0433\u0438\u0438 \u041C\u0413\u0423",
      "screen_name" : "polit_msu",
      "indices" : [ 3, 13 ],
      "id_str" : "226339221",
      "id" : 226339221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182423203052929025",
  "text" : "RT @polit_msu: \u0412 \u043A\u043E\u043D\u043A\u0443\u0440\u0441\u0435 \"\u041C\u0438\u0441\u0441 \u043F\u0440\u0430\u0432\u043E 2012\" \u0441\u0442\u0443\u0434\u0435\u043D\u0442\u043A\u0438 III \u043A\u0443\u0440\u0441\u0430 \u0444\u0430\u043A\u0443\u043B\u044C\u0442\u0435\u0442\u0430 \u043F\u043E\u043B\u0438\u0442\u043E\u043B\u043E\u0433\u0438\u0438 \u041C\u0413\u0423 \u0441\u0442\u0430\u043B\u0438 \"\u041C\u0438\u0441\u0441 \u0433\u0440\u0430\u0446\u0438\u044F\" \u0438 \"\u041C\u0438\u0441\u0441 \u044D\u043B\u0435\u0433\u0430\u043D\u0442\u043D\u043E\u0441\u0442\u044C\"! ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/polit_msu\/status\/182414628482060288\/photo\/1",
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/g7htu08B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AogRI1zCEAAFAMs.jpg",
        "id_str" : "182414628486254592",
        "id" : 182414628486254592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AogRI1zCEAAFAMs.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/g7htu08B"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182414628482060288",
    "text" : "\u0412 \u043A\u043E\u043D\u043A\u0443\u0440\u0441\u0435 \"\u041C\u0438\u0441\u0441 \u043F\u0440\u0430\u0432\u043E 2012\" \u0441\u0442\u0443\u0434\u0435\u043D\u0442\u043A\u0438 III \u043A\u0443\u0440\u0441\u0430 \u0444\u0430\u043A\u0443\u043B\u044C\u0442\u0435\u0442\u0430 \u043F\u043E\u043B\u0438\u0442\u043E\u043B\u043E\u0433\u0438\u0438 \u041C\u0413\u0423 \u0441\u0442\u0430\u043B\u0438 \"\u041C\u0438\u0441\u0441 \u0433\u0440\u0430\u0446\u0438\u044F\" \u0438 \"\u041C\u0438\u0441\u0441 \u044D\u043B\u0435\u0433\u0430\u043D\u0442\u043D\u043E\u0441\u0442\u044C\"! http:\/\/t.co\/g7htu08B",
    "id" : 182414628482060288,
    "created_at" : "2012-03-21 10:33:31 +0000",
    "user" : {
      "name" : "\u0424-\u0442 \u043F\u043E\u043B\u0438\u0442\u043E\u043B\u043E\u0433\u0438\u0438 \u041C\u0413\u0423",
      "screen_name" : "polit_msu",
      "protected" : false,
      "id_str" : "226339221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1281440634\/a_a5d0e584_normal.jpg",
      "id" : 226339221,
      "verified" : false
    }
  },
  "id" : 182423203052929025,
  "created_at" : "2012-03-21 11:07:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0447",
      "screen_name" : "informcentr",
      "indices" : [ 0, 12 ],
      "id_str" : "137856929",
      "id" : 137856929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182418963777589248",
  "geo" : { },
  "id_str" : "182422374153584640",
  "in_reply_to_user_id" : 137856929,
  "text" : "@informcentr \u043F\u0440\u0438 \u044D\u0442\u043E\u043C  \u043D\u0438 \u043E\u0434\u043D\u043E\u043C\u0443 \u0438\u0437 3 \u0447\u043B\u0435\u043D\u043E\u0432 \u0434\u0438\u0441\u0441 \u0441\u043E\u0432\u0435\u0442\u0430 \u043D\u0435\u043B\u044C\u0437\u044F \u0432\u044B\u0431\u0435\u0433\u0430\u0442\u044C \u043F\u043E \u0440\u0430\u0437\u043B\u0438\u0447\u043D\u044B\u043C \u043D\u0443\u0436\u0434\u0430\u043C \u0438\u0437 \u043A\u0430\u0434\u0440\u0430?",
  "id" : 182422374153584640,
  "in_reply_to_status_id" : 182418963777589248,
  "created_at" : "2012-03-21 11:04:17 +0000",
  "in_reply_to_screen_name" : "informcentr",
  "in_reply_to_user_id_str" : "137856929",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nikita Sherman",
      "screen_name" : "Sherman77",
      "indices" : [ 0, 10 ],
      "id_str" : "20440970",
      "id" : 20440970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "182379551995858945",
  "geo" : { },
  "id_str" : "182381611063574528",
  "in_reply_to_user_id" : 20440970,
  "text" : "@Sherman77 \u0437\u0430\u0447\u0435\u043C \u0442\u0430\u043A\u0438\u0435 \u043A\u0440\u0430\u0439\u043D\u043E\u0441\u0442\u0438? \u0414\u0430\u0432\u0430\u0439\u0442\u0435 \u0438\u0441\u043F\u0435\u0447\u0435\u043C \u0435\u0433\u043E \u0432 \u043C\u0438\u043A\u0440\u043E\u0432\u043E\u043B\u043D\u043E\u0432\u043A\u0435!",
  "id" : 182381611063574528,
  "in_reply_to_status_id" : 182379551995858945,
  "created_at" : "2012-03-21 08:22:19 +0000",
  "in_reply_to_screen_name" : "Sherman77",
  "in_reply_to_user_id_str" : "20440970",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182380438948544514",
  "text" : "\u041A\u0430\u043A \u0432\u0441\u0435\u0433\u0434\u0430. \u0432 \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0435 \u0434\u0432\u0430 \u043F\u0440\u043E\u0435\u043A\u0442\u0430, \u0432\u0441\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u0430, \u0438 \u0442\u0443\u0442 \u044F \u043F\u0440\u043E\u0434\u0443\u043C\u044B\u0432\u0430\u044E \"\u043A\u043E\u0435-\u0447\u0442\u043E \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u0435\u0439 foursquare\". \u041B\u0430\u0434\u043D\u043E, \u0441\u0434\u0435\u043B\u0430\u0435\u043C \u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0438\u044E.",
  "id" : 182380438948544514,
  "created_at" : "2012-03-21 08:17:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/XYLQPToq",
      "expanded_url" : "http:\/\/4sq.com\/GBtWKj",
      "display_url" : "4sq.com\/GBtWKj"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7270496672, 37.5809240341 ]
  },
  "id_str" : "182168653721124866",
  "text" : "I'm at Starbucks (\u041C\u043E\u0441\u043A\u0432\u0430) w\/ 8 others http:\/\/t.co\/XYLQPToq",
  "id" : 182168653721124866,
  "created_at" : "2012-03-20 18:16:06 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.localmind.com\/\" rel=\"nofollow\"\u003ELocalmind\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Localmind",
      "screen_name" : "localmind",
      "indices" : [ 98, 108 ],
      "id_str" : "228167084",
      "id" : 228167084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/jvAmGgE6",
      "expanded_url" : "http:\/\/lcl.md\/GCiWPd",
      "display_url" : "lcl.md\/GCiWPd"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.740774, 37.6086078 ]
  },
  "id_str" : "182144572779008001",
  "text" : "How much wood would a woodchuck chuck if a woodchuck could chuck wood?\n http:\/\/t.co\/jvAmGgE6 (via @Localmind)",
  "id" : 182144572779008001,
  "created_at" : "2012-03-20 16:40:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/Zpzmd1gR",
      "expanded_url" : "http:\/\/4sq.com\/GCUnB2",
      "display_url" : "4sq.com\/GCUnB2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7406564357, 37.6090550423 ]
  },
  "id_str" : "182141034631921664",
  "text" : "I'm at Digital October (\u041C\u043E\u0441\u043A\u0432\u0430, \u0420\u043E\u0441\u0441\u0438\u044F) w\/ 35 others http:\/\/t.co\/Zpzmd1gR",
  "id" : 182141034631921664,
  "created_at" : "2012-03-20 16:26:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/qQnQdewT",
      "expanded_url" : "http:\/\/4sq.com\/GD4RKT",
      "display_url" : "4sq.com\/GD4RKT"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.744120043, 37.584335804 ]
  },
  "id_str" : "182125052525948928",
  "text" : "I'm at \u0420\u0430\u0439\u0444\u0444\u0430\u0439\u0437\u0435\u043D\u0431\u0430\u043D\u043A (\u041C\u043E\u0441\u043A\u0432\u0430, \u041C\u043E\u0441\u043A\u0432\u0430) http:\/\/t.co\/qQnQdewT",
  "id" : 182125052525948928,
  "created_at" : "2012-03-20 15:22:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/jXYDTIZK",
      "expanded_url" : "http:\/\/levelss.com",
      "display_url" : "levelss.com"
    }, {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/usIhfukj",
      "expanded_url" : "http:\/\/4sq.com\/GBHHco",
      "display_url" : "4sq.com\/GBHHco"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.8044724784, 37.5852704117 ]
  },
  "id_str" : "182072431559708672",
  "text" : "Nape as3 physics (@ Levels MAS &gt; http:\/\/t.co\/jXYDTIZK) http:\/\/t.co\/usIhfukj",
  "id" : 182072431559708672,
  "created_at" : "2012-03-20 11:53:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181394587565293569",
  "text" : "An Irishman walks out of a bar.",
  "id" : 181394587565293569,
  "created_at" : "2012-03-18 15:00:14 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/Q5VZ6HiT",
      "expanded_url" : "http:\/\/habr.ru\/p\/139972\/",
      "display_url" : "habr.ru\/p\/139972\/"
    } ]
  },
  "geo" : { },
  "id_str" : "181379037644595201",
  "text" : "\u042D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u0440\u043D\u044B\u0439 \u0433\u0435\u043D\u0435\u0440\u0430\u0442\u043E\u0440 \u0442\u0440\u0430\u043D\u0441\u043B\u044F\u0442\u043E\u0440\u043E\u0432 \u0432 coco\/r http:\/\/t.co\/Q5VZ6HiT",
  "id" : 181379037644595201,
  "created_at" : "2012-03-18 13:58:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/UbBoBtVc",
      "expanded_url" : "http:\/\/4sq.com\/FP2gh1",
      "display_url" : "4sq.com\/FP2gh1"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7821683977, 37.5994128949 ]
  },
  "id_str" : "181085409684627456",
  "text" : "\u0422\u0440\u043E\u0439\u043D\u043E\u0435 \u043F\u0440\u0430\u0437\u0434\u043D\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u0440 (Careful, there are some maidens you can't un-see) (@ \u041A\u0443\u043A\u043B\u044B \u041F\u0438\u0441\u0442\u043E\u043B\u0435\u0442\u044B \/ Dolls Pistols) http:\/\/t.co\/UbBoBtVc",
  "id" : 181085409684627456,
  "created_at" : "2012-03-17 18:31:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/URyKBG2R",
      "expanded_url" : "http:\/\/www.destructoid.com\/the-ten-best-bars-in-videogames-223788.phtml",
      "display_url" : "destructoid.com\/the-ten-best-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180723357195571200",
  "text" : "C\u0434\u0435\u043B\u0430\u0442\u044C \u0434\u043E\u043A\u043B\u0430\u0434 \u043D\u0430 DevCon'\u0435? ++ http:\/\/t.co\/URyKBG2R",
  "id" : 180723357195571200,
  "created_at" : "2012-03-16 18:33:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Verso Books",
      "screen_name" : "VersoBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "23187207",
      "id" : 23187207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/xCkWlCVD",
      "expanded_url" : "http:\/\/backdoorbroadcasting.net\/2012\/03\/jacques-ranciere-modernity-revisited\/",
      "display_url" : "backdoorbroadcasting.net\/2012\/03\/jacque\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180275170185973762",
  "text" : "RT @VersoBooks: Podcast of Jacques Ranci\u00E8re lecture Modernity Revisited http:\/\/t.co\/xCkWlCVD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/xCkWlCVD",
        "expanded_url" : "http:\/\/backdoorbroadcasting.net\/2012\/03\/jacques-ranciere-modernity-revisited\/",
        "display_url" : "backdoorbroadcasting.net\/2012\/03\/jacque\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "180258468727500802",
    "text" : "Podcast of Jacques Ranci\u00E8re lecture Modernity Revisited http:\/\/t.co\/xCkWlCVD",
    "id" : 180258468727500802,
    "created_at" : "2012-03-15 11:45:42 +0000",
    "user" : {
      "name" : "Verso Books",
      "screen_name" : "VersoBooks",
      "protected" : false,
      "id_str" : "23187207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889515094572486657\/xtlkvZ7__normal.jpg",
      "id" : 23187207,
      "verified" : false
    }
  },
  "id" : 180275170185973762,
  "created_at" : "2012-03-15 12:52:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/3KxLlDXW",
      "expanded_url" : "http:\/\/rickrocket.de\/df\/",
      "display_url" : "rickrocket.de\/df\/"
    } ]
  },
  "geo" : { },
  "id_str" : "180236683571240960",
  "text" : "http:\/\/t.co\/3KxLlDXW  - \u0447\u044C\u044F-\u0442\u043E \u0437\u0430\u044F\u0432\u043A\u0430 \u043D\u0430 \u0440\u0430\u0431\u043E\u0442\u0443 \u0432 DF.",
  "id" : 180236683571240960,
  "created_at" : "2012-03-15 10:19:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TimOfLegend &:Y\u007D",
      "screen_name" : "TimOfLegend",
      "indices" : [ 21, 33 ],
      "id_str" : "24585498",
      "id" : 24585498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/c7aAn7XR",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gbXygxSObUQ#",
      "display_url" : "youtube.com\/watch?v=gbXygx\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179655660995215360",
  "text" : "http:\/\/t.co\/c7aAn7XR @timoflegend gathered 3 mln. other words the credit squeeze and crunch as well as world economic fandango are explained",
  "id" : 179655660995215360,
  "created_at" : "2012-03-13 19:50:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/LtvJYaju",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5yfcH5q_sow",
      "display_url" : "youtube.com\/watch?v=5yfcH5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179642688101036032",
  "text" : "\u0414\u043E\u043A\u0430\u0437\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u0442\u043E\u0433\u043E, \u0447\u0442\u043E \u0435\u0441\u0442\u044C \u043B\u044E\u0434\u0438, \u0437\u0430\u0434\u043E\u043B\u0436\u0430\u0432\u0448\u0438\u0435 \u0441\u0435\u0431\u0435 \u0436\u0438\u0437\u043D\u0438 \u043D\u0435 \u043C\u0435\u043D\u044C\u0448\u0435 \u043C\u043E\u0435\u0433\u043E: http:\/\/t.co\/LtvJYaju )",
  "id" : 179642688101036032,
  "created_at" : "2012-03-13 18:58:49 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 67, 78 ],
      "id_str" : "804341497441255424",
      "id" : 804341497441255424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/jXYDTIZK",
      "expanded_url" : "http:\/\/levelss.com",
      "display_url" : "levelss.com"
    }, {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/FpCLHXbt",
      "expanded_url" : "http:\/\/4sq.com\/xkjfrY",
      "display_url" : "4sq.com\/xkjfrY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.8044724784, 37.5852704117 ]
  },
  "id_str" : "179515119636721664",
  "text" : "I just became the mayor of Levels MAS &gt; http:\/\/t.co\/jXYDTIZK on @foursquare! http:\/\/t.co\/FpCLHXbt",
  "id" : 179515119636721664,
  "created_at" : "2012-03-13 10:31:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179276028097736705",
  "text" : "\u041F\u0440\u0438\u0448\u0435\u043B \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u043D\u0430 \u0441\u0435\u043C\u0438\u043D\u0430\u0440 \u043F\u043E \u0438\u0441\u0442\u043E\u0440\u0438\u0438 \u0438 \u0444\u0438\u043B\u043E\u0441\u043E\u0444\u0438\u0438 \u043D\u0430\u0443\u043A\u0438 \u0412\u0428\u042D \u0438 \u043F\u0440\u043E\u0432\u0435\u043B. \u0414\u0435\u043B\u0430\u043B \u0441 \u043D\u0438\u043C \u0432\u0441\u0435, \u0447\u0442\u043E \u0445\u043E\u0442\u0435\u043B, \u0445\u043E\u0442\u044F \u044F \u0438 \u043D\u0435 \u044F\u0432\u043B\u044F\u044E\u0441\u044C \u0421\u0443\u0432\u0435\u0440\u0435\u043D\u043D\u043E\u0439 \u0421\u0443\u0431\u0441\u0442\u0430\u043D\u0446\u0438\u0435\u0439.",
  "id" : 179276028097736705,
  "created_at" : "2012-03-12 18:41:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/JL5AUPMb",
      "expanded_url" : "http:\/\/www.theotherbrothersgame.com",
      "display_url" : "theotherbrothersgame.com"
    } ]
  },
  "geo" : { },
  "id_str" : "179271525231362051",
  "text" : "http:\/\/t.co\/JL5AUPMb for gems from beyond the pixeljoint",
  "id" : 179271525231362051,
  "created_at" : "2012-03-12 18:23:56 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/QoHyi8xd",
      "expanded_url" : "http:\/\/4sq.com\/AyT5Jy",
      "display_url" : "4sq.com\/AyT5Jy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.804267, 37.584898 ]
  },
  "id_str" : "179162276220248064",
  "text" : "wronggo manno doesn't eat cookie you tell maa (@ Levels mobile application studio) http:\/\/t.co\/QoHyi8xd",
  "id" : 179162276220248064,
  "created_at" : "2012-03-12 11:09:49 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria",
      "screen_name" : "pervomaj",
      "indices" : [ 0, 9 ],
      "id_str" : "46336383",
      "id" : 46336383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "179110388904886272",
  "geo" : { },
  "id_str" : "179114603039563776",
  "in_reply_to_user_id" : 46336383,
  "text" : "@pervomaj 86 \u0438\u0437-\u0437\u0430 \u0430\u0434\u0430",
  "id" : 179114603039563776,
  "in_reply_to_status_id" : 179110388904886272,
  "created_at" : "2012-03-12 08:00:23 +0000",
  "in_reply_to_screen_name" : "pervomaj",
  "in_reply_to_user_id_str" : "46336383",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/FJCMM0Ib",
      "expanded_url" : "http:\/\/blog.stephenwolfram.com\/2012\/03\/the-personal-analytics-of-my-life\/",
      "display_url" : "blog.stephenwolfram.com\/2012\/03\/the-pe\u2026"
    }, {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/RtMPUl5l",
      "expanded_url" : "http:\/\/worrydream.com\/Bio\/bio0.jpg",
      "display_url" : "worrydream.com\/Bio\/bio0.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "178703950323777536",
  "text" : "http:\/\/t.co\/FJCMM0Ib \u0441\u0440\u0430\u0432\u043D\u0438\u0442\u044C \u0441 http:\/\/t.co\/RtMPUl5l",
  "id" : 178703950323777536,
  "created_at" : "2012-03-11 04:48:36 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178454806153793536",
  "text" : "\u041E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E, \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0438\u0432\u0430\u044E\u0449\u0435\u0435 \u0441\u0432\u043E\u0431\u043E\u0434\u0443 \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0439 \u043F\u0440\u0435\u043F\u0440\u043E\u0432\u043E\u0436\u0434\u0430\u0435\u043C\u043E\u0433\u043E \u043D\u0435\u0441\u043E\u0432\u0435\u0440\u0448\u0435\u043D\u043D\u043E\u043B\u0435\u0442\u043D\u0435\u0433\u043E \u0434\u0435\u043B\u0438\u043D\u043A\u0432\u0435\u043D\u0442\u0430 \u043F\u043E \u0440\u0435\u0448\u0435\u043D\u0438\u044E \u0441\u0443\u0434\u0430 \u0432 \u0438\u0441\u043F\u0440\u0430\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u0443\u0447\u0440\u0435\u0436\u0434\u0435\u043D\u0438\u0435",
  "id" : 178454806153793536,
  "created_at" : "2012-03-10 12:18:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/QJXkMtCO",
      "expanded_url" : "http:\/\/www.rattraders.com\/methodology",
      "display_url" : "rattraders.com\/methodology"
    } ]
  },
  "geo" : { },
  "id_str" : "178168702703898624",
  "text" : "http:\/\/t.co\/QJXkMtCO \"Intelligent trading solutions\"",
  "id" : 178168702703898624,
  "created_at" : "2012-03-09 17:21:43 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178146695064985601",
  "text" : "\u041F\u0440\u0435\u0430\u043C\u0431\u0443\u043B\u0430. \u041C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u044F \u043F\u0440\u0438\u0434\u0438\u0440\u0430\u044E\u0441\u044C, \u043D\u043E \u043D\u0443\u0436\u043D\u043E \u0440\u0430\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u044C \u043A\u0442\u043E \u043F\u043E\u0431\u0440\u0438\u043B \u0414\u0436\u043E\u043D\u0430 \u041A\u0430\u0440\u0442\u0435\u0440\u0430, \u043F\u043E\u043A\u0430 \u043E\u043D \u0433\u043E\u043B\u043E\u0434\u0430\u043B \u043D\u0430 \u0442.\u043D. \u043C\u0430\u0440\u0441\u0435.",
  "id" : 178146695064985601,
  "created_at" : "2012-03-09 15:54:16 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/3Oaogxf8",
      "expanded_url" : "http:\/\/www.pixeljoint.com\/files\/icons\/lil_dude_on_crack.gif",
      "display_url" : "pixeljoint.com\/files\/icons\/li\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178144182081294338",
  "text" : "http:\/\/t.co\/3Oaogxf8",
  "id" : 178144182081294338,
  "created_at" : "2012-03-09 15:44:17 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178108602253451264",
  "text" : "\"..\u0432\u043E\u0441\u043A\u0440\u0435\u0441\u0430\u044E\u0442 \u043D\u0430 \u043A\u043E\u0440\u043E\u0442\u043A\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u0441\u0442\u0430\u0440\u044B\u0435 \u043E\u0448\u0438\u0431\u043A\u0438, \u0447\u0442\u043E\u0431\u044B \u043F\u043E\u0442\u043E\u043C \u0432\u0441\u043A\u043E\u0440\u0435 \u0438\u0441\u0447\u0435\u0437\u043D\u0443\u0442\u044C\" - \u043F\u0440\u043E\u0446\u0438\u0442\u0438\u0440\u043E\u0432\u0430\u043B \u044F, \u043F\u043E\u043A\u0443\u043F\u0430\u044F \u0448\u0430\u043F\u043A\u0443 \u0432 \u0444\u043E\u0440\u043C\u0435 \u0438\u0433\u0440\u0443\u0448\u0435\u0447\u043D\u043E\u0439 \u0433\u043E\u043B\u043E\u0432\u044B \u0435\u043D\u043E\u0442\u0430",
  "id" : 178108602253451264,
  "created_at" : "2012-03-09 13:22:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178088470919655424",
  "text" : "RT @rtshnaya: \u0420\u0435\u0442\u0432\u0438\u0442\u043D\u0438, \u0435\u0441\u043B\u0438 \u0442\u044B \u041F\u0415\u0420\u0421\u041F\u0415\u041A\u0422\u0418\u0412\u041D\u042B\u0419 \u0425\u041E\u041B\u041E\u0421\u0422\u042F\u041A.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "178073446515875841",
    "text" : "\u0420\u0435\u0442\u0432\u0438\u0442\u043D\u0438, \u0435\u0441\u043B\u0438 \u0442\u044B \u041F\u0415\u0420\u0421\u041F\u0415\u041A\u0422\u0418\u0412\u041D\u042B\u0419 \u0425\u041E\u041B\u041E\u0421\u0422\u042F\u041A.",
    "id" : 178073446515875841,
    "created_at" : "2012-03-09 11:03:12 +0000",
    "user" : {
      "name" : "Ksenia Ratushnaya",
      "screen_name" : "trescantabile",
      "protected" : false,
      "id_str" : "28081003",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1077314805827022852\/XCXwZSDH_normal.jpg",
      "id" : 28081003,
      "verified" : false
    }
  },
  "id" : 178088470919655424,
  "created_at" : "2012-03-09 12:02:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177414077264568320",
  "text" : "\u0412\u0441\u0435\u0445 \u043E\u0442\u0441\u0442\u0443\u043F\u0430\u044E\u0449\u0438\u0445 \u0441 \u043D\u0430\u0441\u0442\u0443\u043F\u0430\u044E\u0449\u0438\u043C, \u0442\u043D\u043C, \u0432 \u0421\u0442\u0443\u0434\u0438\u0438 \u0434\u0435\u043D\u044C \u0427\u0435\u043B\u043E\u0432\u0435\u043A\u0430, \u0443 \u041A\u043E\u0442\u043E\u0440\u043E\u0433\u043E \u0415\u0441\u0442\u044C \u041F\u043E\u043B \u044F\u0432\u043B\u044F\u0435\u0442\u0441\u044F \u0432\u0445\u043E\u0434\u043D\u044B\u043C \u0438 \u043F\u043E\u0441\u0432 game design orgy. \u041F\u043E\u0434\u0440\u043E\u0431\u043D\u043E\u0441\u0442\u0438 \u043F\u043E\u0437\u0436\u0435",
  "id" : 177414077264568320,
  "created_at" : "2012-03-07 15:23:06 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD835\uDD75\uD835\uDD94\uD835\uDD8D\uD835\uDD93 \uD835\uDD7D\uD835\uDD94\uD835\uDD92\uD835\uDD8A\uD835\uDD97\uD835\uDD94",
      "screen_name" : "romero",
      "indices" : [ 3, 10 ],
      "id_str" : "7753922",
      "id" : 7753922
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u00FCber",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177391563188609026",
  "text" : "RT @romero: Everyone should use \u00DCBER for their cab service (iPhone). I pressed the button and 2 mins later was in a town car. #\u00FCber",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u00FCber",
        "indices" : [ 114, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177251291729371136",
    "text" : "Everyone should use \u00DCBER for their cab service (iPhone). I pressed the button and 2 mins later was in a town car. #\u00FCber",
    "id" : 177251291729371136,
    "created_at" : "2012-03-07 04:36:15 +0000",
    "user" : {
      "name" : "\uD835\uDD75\uD835\uDD94\uD835\uDD8D\uD835\uDD93 \uD835\uDD7D\uD835\uDD94\uD835\uDD92\uD835\uDD8A\uD835\uDD97\uD835\uDD94",
      "screen_name" : "romero",
      "protected" : false,
      "id_str" : "7753922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1009742686990098432\/VZGvGxla_normal.jpg",
      "id" : 7753922,
      "verified" : true
    }
  },
  "id" : 177391563188609026,
  "created_at" : "2012-03-07 13:53:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/ytlkNEr2",
      "expanded_url" : "http:\/\/4sq.com\/A4Rbfy",
      "display_url" : "4sq.com\/A4Rbfy"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7599152663, 37.6139473915 ]
  },
  "id_str" : "177390718774542337",
  "text" : "RIDING A GOAT TO CANDY VAIL MOUNTAIN (@ Starbucks w\/ 6 others) http:\/\/t.co\/ytlkNEr2",
  "id" : 177390718774542337,
  "created_at" : "2012-03-07 13:50:17 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/7KddvbJD",
      "expanded_url" : "http:\/\/img.ly\/eLAh",
      "display_url" : "img.ly\/eLAh"
    } ]
  },
  "geo" : { },
  "id_str" : "176299921224376320",
  "text" : "http:\/\/t.co\/7KddvbJD \u0433\u043E\u0440\u0438\u0437\u043E\u043D\u0442\u0430\u043B\u044C\u043D\u0430\u044F \u043D\u0435\u043D\u043E\u0440\u043C\u0430\u0442\u0438\u0432\u043D\u0430\u044F \u0430\u043C\u043F\u043B\u0438\u0444\u0438\u0446\u0438\u044F \u0432\u044B\u0434\u0430\u0447\u0438 \u0438\u0437 \u0441\u0435\u0442\u0438 \u0441\u043B\u043E\u0432\u0430\u0440\u044F \u0432 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u044F\u0445 = reference counting syndrome. yo mum",
  "id" : 176299921224376320,
  "created_at" : "2012-03-04 13:35:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/TO4QMH4K",
      "expanded_url" : "http:\/\/acarol.woz.org",
      "display_url" : "acarol.woz.org"
    } ]
  },
  "geo" : { },
  "id_str" : "176292600792367105",
  "text" : "\u0412 \u043F\u043B\u0430\u043D\u0435 \u044D\u0441\u0442\u0435\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0445 \u0441\u043E\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0439 \u0433\u043E\u043B\u043E\u0441\u0443\u044E \u043D\u0435 \u0437\u0430 \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u0430, \u041C\u0430\u043D\u0434\u0435\u043B\u044C\u0431\u0440\u043E\u0442\u0430 \u0438 \u0441\u043E\u0446 \u0442\u0438\u043F\u0430 \u041B\u0443\u043C\u0430\u043D\u0430, \u043D\u0435 \u0437\u0430 \u0433\u0440\u0430\u043C\u043C\u043E\u0444\u043E\u043D\\\u043B\u0438\u0446\u0435\u043D\u0437\u0438\u044E, \u0430 \u0437\u0430 http:\/\/t.co\/TO4QMH4K",
  "id" : 176292600792367105,
  "created_at" : "2012-03-04 13:06:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/NZT04zCo",
      "expanded_url" : "http:\/\/img.ly\/eLvw",
      "display_url" : "img.ly\/eLvw"
    } ]
  },
  "geo" : { },
  "id_str" : "176281625716457472",
  "text" : "\u041F\u0440\u043E\u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u043B \u0437\u0430 \u041C\u0438\u0448\u0443 \u0414\u043B\u0438\u043D\u043D\u043E\u0433\u043E: http:\/\/t.co\/NZT04zCo \u043D\u0435 \u0445\u043E\u0447\u0443, \u0447\u0442\u043E\u0431\u044B \u0432\u0441\u0435 \u0437\u043D\u0430\u043B\u0438 - \u044D\u0442\u043E \u043B\u0438\u0447\u043D\u043E\u0435 )",
  "id" : 176281625716457472,
  "created_at" : "2012-03-04 12:23:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176280818673664001",
  "text" : "\u041F\u0440\u043E\u0442\u0438\u0432\u043D\u0438\u043A \u0433\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0430 \u0432\u043E \u0432\u0441\u0435\u0445 \u043F\u0440\u043E\u044F\u0432\u043B\u0435\u043D\u0438\u044F\u0445, \u044F \u043F\u0440\u043E\u0433\u043E\u043B\u043E\u0441\u043E\u0432\u0430\u043B \u043D\u0430 \u0432\u044B\u0431\u043E\u0440\u0430\u0445 \u043F\u0440\u0435\u0437\u0438\u0434\u0435\u043D\u0442\u0430 \u0433\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0430. non valet consequentia",
  "id" : 176280818673664001,
  "created_at" : "2012-03-04 12:19:56 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175111031989862400",
  "text" : "\u041F\u043E\u043B\u0438\u0441\u0442\u0430\u043B \u043C\u0435\u0441\u044F\u0447\u043D\u0443\u044E \u0432\u044B\u0440\u0443\u0447\u043A\u0443 \u0441 Paradise island \u0432\u0441\u0435\u0445 \u043C\u043E\u0434\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u0439, \u0432\u0434\u043E\u0445\u043D\u043E\u0432\u0438\u043B\u0441\u044F. \u0410\u043B\u0438\u0441\u0430 \u0427\u0443\u043C\u0430\u0447\u0435\u043D\u043A\u043E \u0447\u0442\u043E-\u0442\u043E \u0437\u043D\u0430\u0435\u0442.",
  "id" : 175111031989862400,
  "created_at" : "2012-03-01 06:51:38 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]