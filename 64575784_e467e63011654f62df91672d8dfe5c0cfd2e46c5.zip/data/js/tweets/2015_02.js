Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571711284732952577",
  "text" : "\u0440\u0430\u0441\u0442\u0438 \u0445\u0430\u0431\u0430\u0434\u043D\u0438\u043A\u043E\u043C",
  "id" : 571711284732952577,
  "created_at" : "2015-02-28 16:39:26 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570511457445658624",
  "text" : "Erro patris, pulcher matris \u2014 \u00AB\u041F\u0430\u043F\u0438\u043D \u0431\u0440\u043E\u0434\u044F\u0433\u0430, \u043C\u0430\u043C\u0438\u043D \u0441\u0438\u043C\u043F\u0430\u0442\u044F\u0433\u0430\u00BB",
  "id" : 570511457445658624,
  "created_at" : "2015-02-25 09:11:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/IzITpbMQvm",
      "expanded_url" : "http:\/\/pinterest.com\/pin\/451415562625399651\/",
      "display_url" : "pinterest.com\/pin\/4514155626\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567085751717097472",
  "text" : "Jeff Koons http:\/\/t.co\/IzITpbMQvm",
  "id" : 567085751717097472,
  "created_at" : "2015-02-15 22:19:13 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565956892502278145",
  "text" : "\u00AB\u042D\u0442\u043E \u043A\u0430\u043A \u0443\u043F\u0440\u0435\u043A\u0430\u0442\u044C \u043F\u0430\u043D\u043A\u0430 \u0432 \u0442\u043E\u043C, \u0447\u0442\u043E \u0435\u0433\u043E \u0433\u0438\u0442\u0430\u0440\u0430 \u0440\u0430\u0441\u0441\u0442\u0440\u043E\u0435\u043D\u0430\u00BB, \u0441\u043A\u0430\u0437\u0430\u043B \u043C\u043D\u0435 \u041C\u0438\u0445\u0430\u0438\u043B \u0412\u0438\u0437\u0435\u043B\u044C",
  "id" : 565956892502278145,
  "created_at" : "2015-02-12 19:33:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564854155618299905",
  "text" : "dance for me, \u0441\u043C\u0443\u0442\u043D\u0430\u044F \u0432\u0435\u0440\u0430 \u0432 \u0431\u0443\u0434\u0443\u0449\u0435\u0435, fanciulla gentile",
  "id" : 564854155618299905,
  "created_at" : "2015-02-09 18:31:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]