Grailbird.data.tweets_2016_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693857505189990401",
  "text" : "\u0412 \u0442\u0430\u0439\u043D\u043E\u043C \u043A\u0430\u0440\u043C\u0430\u043D\u0435 \u0440\u044E\u043A\u0437\u0430\u043A\u0430 \u043D\u0430\u0448\u0435\u043B \u0434\u043D\u0435\u0432\u043D\u0438\u043A\u0438 \u041E\u0434\u0435\u043D\u0430 \u043D\u0430 \u0447\u0435\u0440\u043D\u044B\u0439 \u0434\u0435\u043D\u044C",
  "id" : 693857505189990401,
  "created_at" : "2016-01-31 18:04:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "693566354142674947",
  "text" : "Betty Wright",
  "id" : 693566354142674947,
  "created_at" : "2016-01-30 22:47:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/LhXMVfjDVu",
      "expanded_url" : "https:\/\/youtu.be\/eiSjl8oDVYE",
      "display_url" : "youtu.be\/eiSjl8oDVYE"
    } ]
  },
  "geo" : { },
  "id_str" : "692645445689032704",
  "text" : "L'Inconnu de Limoise (JF Heintzen) https:\/\/t.co\/LhXMVfjDVu \u0413\u0434\u0435 \u043C\u043E\u0436\u043D\u043E \u043E\u0442\u044B\u0441\u043A\u0430\u0442\u044C \u0442\u0430\u043A\u043E\u0439 \u0434\u0438\u0430\u0442\u043E\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0430\u043A\u043A\u043E\u0440\u0434\u0435\u043E\u043D (\u0433\u0430\u0440\u043C\u043E\u043D\u044C)?",
  "id" : 692645445689032704,
  "created_at" : "2016-01-28 09:48:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "688421391868276736",
  "text" : "V L A D A",
  "id" : 688421391868276736,
  "created_at" : "2016-01-16 18:03:44 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "684720215100383234",
  "text" : "Dinah Washington",
  "id" : 684720215100383234,
  "created_at" : "2016-01-06 12:56:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]