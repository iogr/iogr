Grailbird.data.tweets_2015_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583029727427977216",
  "text" : "Scott McKenzie",
  "id" : 583029727427977216,
  "created_at" : "2015-03-31 22:14:53 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/G5JAZwdAqk",
      "expanded_url" : "http:\/\/vozduh.afisha.ru\/news\/7297\/",
      "display_url" : "vozduh.afisha.ru\/news\/7297\/"
    } ]
  },
  "geo" : { },
  "id_str" : "581484109974794241",
  "text" : "\u0411\u043E\u0436\u0435 \u043C\u043E\u0439, \u043E\u043D\u0430 \u0437\u043D\u0430\u043B\u0430! \u041F\u043E\u043B\u044C\u0437\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u0438\u0446\u0430 \u0444\u0435\u0439\u0441\u0431\u0443\u043A\u0430 \u043D\u0430\u0448\u043B\u0430 \u043D\u0435\u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0438\u0435 \u0432 \u0441\u044E\u0436\u0435\u0442\u0435 \u00AB\u0420\u0443\u0441\u0430\u043B\u043E\u0447\u043A\u0438\u00BB http:\/\/t.co\/G5JAZwdAqk",
  "id" : 581484109974794241,
  "created_at" : "2015-03-27 15:53:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "577119979268636673",
  "text" : "\u0417\u0430\u0432\u0442\u0440\u0430 \u0441\u0432\u0435\u0436\u0438\u0439 Olafur Arnalds",
  "id" : 577119979268636673,
  "created_at" : "2015-03-15 14:51:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575676212976222208",
  "text" : "Tinavie",
  "id" : 575676212976222208,
  "created_at" : "2015-03-11 15:14:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ToOK7fRk8q",
      "expanded_url" : "https:\/\/soundcloud.com\/fredviktor\/martin-grant-fw15-paris-fashion-show-soundtrack-by-fred-viktor",
      "display_url" : "soundcloud.com\/fredviktor\/mar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "575275450735394816",
  "text" : "https:\/\/t.co\/ToOK7fRk8q",
  "id" : 575275450735394816,
  "created_at" : "2015-03-10 12:42:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "575015905899474944",
  "text" : "'With Me' by Cashmere Cat; 'Exercise #5 (September)' by CFCF; 'Lude Pre (Red Hot + Bach)' by Francesco Tristano &amp; Carl Craig",
  "id" : 575015905899474944,
  "created_at" : "2015-03-09 19:30:49 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "574028198448623617",
  "text" : "Buena Vista Social Club",
  "id" : 574028198448623617,
  "created_at" : "2015-03-07 02:06:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]