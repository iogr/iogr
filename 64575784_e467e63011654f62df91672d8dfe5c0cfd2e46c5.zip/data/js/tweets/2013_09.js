Grailbird.data.tweets_2013_09 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Web App\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "378463725017387008",
  "geo" : { },
  "id_str" : "378646952755625984",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u043F\u0440\u043E\u0441\u0442\u043E \u043D\u0435 \u0435\u0448\u044C \u0441\u0430\u0445\u0430\u0440",
  "id" : 378646952755625984,
  "in_reply_to_status_id" : 378463725017387008,
  "created_at" : "2013-09-13 22:30:43 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Web App\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 30 ],
      "url" : "https:\/\/t.co\/bDpKu2fIlb",
      "expanded_url" : "https:\/\/play.google.com\/store\/apps\/developer?id=ScummVM",
      "display_url" : "play.google.com\/store\/apps\/dev\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "375446505278029826",
  "geo" : { },
  "id_str" : "375540113784061952",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn https:\/\/t.co\/bDpKu2fIlb",
  "id" : 375540113784061952,
  "in_reply_to_status_id" : 375446505278029826,
  "created_at" : "2013-09-05 08:45:14 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Web App\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/xzL88oKkL4",
      "expanded_url" : "http:\/\/www.twitch.tv\/dansgaming\/b\/424035448",
      "display_url" : "twitch.tv\/dansgaming\/b\/4\u2026"
    }, {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/vZj4rLal8Z",
      "expanded_url" : "http:\/\/www.twitch.tv\/dansgaming\/c\/1114664",
      "display_url" : "twitch.tv\/dansgaming\/c\/1\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "375110908588335104",
  "geo" : { },
  "id_str" : "375387042907422720",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn http:\/\/t.co\/xzL88oKkL4 http:\/\/t.co\/vZj4rLal8Z",
  "id" : 375387042907422720,
  "in_reply_to_status_id" : 375110908588335104,
  "created_at" : "2013-09-04 22:37:00 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]