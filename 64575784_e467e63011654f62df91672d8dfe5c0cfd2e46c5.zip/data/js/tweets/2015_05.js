Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601460987120594944",
  "text" : "\u041E\u0434\u0438\u043D\u043D\u0430\u0434\u0446\u0430\u0442\u044B\u0439 \u0447\u0430\u0441 \u0432\u0435\u0447\u0435\u0440\u0430, \u043C\u043E\u0439 \u0434\u0435\u043D\u044C \u043D\u0430\u0447\u0438\u043D\u0430\u0435\u0442\u0441\u044F.",
  "id" : 601460987120594944,
  "created_at" : "2015-05-21 18:54:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600429035873804289",
  "text" : "Evgeny Grinko",
  "id" : 600429035873804289,
  "created_at" : "2015-05-18 22:33:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594809473333604352",
  "text" : "\u0411\u0443\u043D\u0433\u0430\u043B\u043E \u0432 \u0414\u0430\u0440\u0434\u0436\u0438\u043B\u0438\u043D\u0433\u0435, \u0441\u0438\u043F\u0430\u043D\u043A \u0421\u0430\u0440\u0430 \u0424\u043E\u043B\u043A\u043D\u0435\u0440, \u0432\u0438\u0437\u0433 \u043A\u0430\u043B\u0438\u0442\u043A\u0438, \u043D\u0435\u043E\u0436\u0438\u0434\u0430\u043D\u043D\u044B\u0435 \u043C\u043E\u0434\u0443\u043B\u044F\u0446\u0438\u0438 \u0433\u043E\u043B\u043E\u0441\u0430 \u0434\u0435\u043B\u044C\u0444\u0438\u043D\u043E\u0432, \u0440\u0430\u0437\u043B\u0438\u0442\u044B\u0439 \u043F\u043E \u0441\u0442\u043E\u043B\u0443 Blue Kurasawa, \u041B\u0438\u0441\u0441\u0430\u0431\u043E\u043D.",
  "id" : 594809473333604352,
  "created_at" : "2015-05-03 10:23:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594808770280202242",
  "text" : "\u041F\u043E\u0440\u0442\u043E\u0431\u0435\u043B\u043B\u043E, \u0441\u043E\u0431\u0435\u0441\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0434\u043E \u0440\u0430\u0441\u0441\u0432\u0435\u0442\u0430 \u0441 \u041F\u0430\u0442\u0440\u0438\u0446\u0438\u0435\u0439, \u043D\u0438\u0447\u0435\u0433\u043E \u043E\u0441\u043E\u0431\u0435\u043D\u043D\u043E\u0433\u043E.",
  "id" : 594808770280202242,
  "created_at" : "2015-05-03 10:20:36 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]