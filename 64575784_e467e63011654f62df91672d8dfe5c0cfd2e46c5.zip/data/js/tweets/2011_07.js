Grailbird.data.tweets_2011_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "95658699133169664",
  "text" : "Three blind mice walk into a pub. \n\nThey are all unaware of their surroundings, so to derive humor from it would be exploitative",
  "id" : 95658699133169664,
  "created_at" : "2011-07-26 00:56:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/mP5Ige4",
      "expanded_url" : "http:\/\/allmobileworld.ru\/uploads\/posts\/2010-01\/1263831939_sam_max_scumm_vm_4.jpg",
      "display_url" : "allmobileworld.ru\/uploads\/posts\/\u2026"
    }, {
      "indices" : [ 81, 100 ],
      "url" : "http:\/\/t.co\/fxvDeyS",
      "expanded_url" : "http:\/\/static.ogl.ru\/i\/00\/01\/73\/87\/1163362037.jpg",
      "display_url" : "static.ogl.ru\/i\/00\/01\/73\/87\/\u2026"
    }, {
      "indices" : [ 101, 120 ],
      "url" : "http:\/\/t.co\/vuFI2Q2",
      "expanded_url" : "http:\/\/lparchive.org\/Full-Throttle-(Screenshot)\/Update%202\/1-2-1.png",
      "display_url" : "lparchive.org\/Full-Throttle-\u2026"
    }, {
      "indices" : [ 121, 140 ],
      "url" : "http:\/\/t.co\/99dmcYT",
      "expanded_url" : "http:\/\/www.gamingbits.com\/images\/stories\/pc_games\/thedig.jpg",
      "display_url" : "gamingbits.com\/images\/stories\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "94676937699631104",
  "text" : "\u0425\u0430\u0440\u0430\u043A\u0442\u0435\u0440\u043D\u0430\u044F \u0447\u0435\u0440\u0442\u0430 - \u0434\u043E 96 \u0433\u043B\u0430\u0437\u0430 \u0431\u044B\u043B\u0438 1, \u0440\u0435\u0436\u0435, 2-\u043F\u0438\u043A\u0441\u0435\u043B\u044C\u043D\u044B\u043C\u0438: http:\/\/t.co\/mP5Ige4 http:\/\/t.co\/fxvDeyS http:\/\/t.co\/vuFI2Q2 http:\/\/t.co\/99dmcYT",
  "id" : 94676937699631104,
  "created_at" : "2011-07-23 07:55:15 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94667403954360320",
  "text" : "\u041D\u0435 \u043D\u0443\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u042D\u043D\u0448\u0442\u0435\u0439\u043D\u043E\u043C, \u0447\u0442\u043E\u0431\u044B \u0434\u043E\u043A\u0430\u0437\u0430\u0442\u044C, \u0447\u0442\u043E \u0432\u0440\u0435\u043C\u044F p&c adventure \u0438\u0441\u043A\u0440\u0438\u0432\u043B\u0435\u043D\u043E - \u0438\u043D\u0430\u0447\u0435, \u043A\u0430\u043A \u0443\u0436\u0435 \u0432 1996(!) \u043C\u043E\u0433\u043B\u0438 \u0432\u044B\u0439\u0442\u0438 Toonstruck \u0438\u043B\u0438 Neverhood?",
  "id" : 94667403954360320,
  "created_at" : "2011-07-23 07:17:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/WYyylkD",
      "expanded_url" : "http:\/\/static02.gog.com\/upload\/images\/2009\/03\/ae317855dfb33b2a38c47c29721c1b1e281e0af1.jpg",
      "display_url" : "static02.gog.com\/upload\/images\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "94665297105133568",
  "text" : "http:\/\/t.co\/WYyylkD Teen agent, \u0432\u044B\u0448\u0435\u043B \u0432 1995 \u0433\u043E\u0434\u0443, \u0434\u0430\u0432\u0448\u0435\u043C \u0431\u043E\u043B\u0435\u0435 \u0447\u0435\u043C 20! \u0434\u0440\u0443\u0433\u0438\u0445 \u0448\u0435\u0434\u0435\u0432\u0440\u043E\u0432: Full throttle, Discworld, Torin's passage \u0438 \u043C\u043D. \u0434\u0440.",
  "id" : 94665297105133568,
  "created_at" : "2011-07-23 07:09:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94552452375920640",
  "text" : "\u041D\u0430\u0448\u0435\u043B \u0432 \u0430\u043F\u0441\u0442\u043E\u0440\u0435 \u043E\u0431\u0435 \u0447\u0430\u0441\u0442\u0438 Simon the sorcerer! http:\/\/instagr.am\/p\/IRLif\/",
  "id" : 94552452375920640,
  "created_at" : "2011-07-22 23:40:36 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94115654701039616",
  "text" : "27 \u0432\u0441\u043F\u043E\u043C\u043D\u0438\u043B",
  "id" : 94115654701039616,
  "created_at" : "2011-07-21 18:44:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94114947419734016",
  "text" : "\u041F\u043E\u043B\u0447\u0430\u0441\u0430 \u0434\u043E \u0432\u0437\u043B\u0435\u0442\u0430, \u043F\u043E\u043F\u0440\u043E\u0431\u0443\u044E \u043F\u043E\u0434\u0441\u0447\u0438\u0442\u0430\u0442\u044C \u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0443 \u043C\u0435\u043D\u044F \u0431\u044B\u043B\u043E \u043F\u0435\u0440\u0435\u043B\u0435\u0442\u043E\u0432. \u041D\u0430 \u0441\u043B\u0443\u0447\u0430\u0439 accident - \u0441\u043C. about.me )",
  "id" : 94114947419734016,
  "created_at" : "2011-07-21 18:42:06 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "94101620849262592",
  "text" : "\u0421\u0431\u0438\u043B \u0432 \u0442\u0435\u0440\u043C\u0438\u043D\u0430\u043B\u0435-\u043B\u043E\u0442\u043A\u0435 \u0441\u043E \u0441\u043D\u044D\u043A\u0430\u043C\u0438 \u0430\u044D\u0440\u043E\u043F\u043E\u0440\u0442\u0430 \u0432\u043D\u0443\u043A\u043E\u0432\u043E \u0445\u0430\u043B\u044F\u0432\u043D\u0443\u044E \u043F\u0430\u0447\u043A\u0443 \u043A\u0440\u044D\u043C\u0431\u043B\u043E\u0432 \u0438 \u043F\u043E\u0434\u0430\u0440\u0438\u043B \u0441\u0442\u043E\u044F\u0449\u0435\u043C\u0443 \u0440\u044F\u0434\u043E\u043C \u0445\u0430\u043A\u0430\u0441\u0443 ) \u0436\u0434\u0443 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F \u0433\u0435\u0439\u0442\u0430",
  "id" : 94101620849262592,
  "created_at" : "2011-07-21 17:49:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92656862494855168",
  "text" : "What's big, yellow, and doesn't swim? \n\nA bus full of children.",
  "id" : 92656862494855168,
  "created_at" : "2011-07-17 18:08:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "92656729787088896",
  "text" : "\u041A\u0443\u0440\u044C\u0435\u0440 \u043F\u043E\u0442\u0440\u0430\u0442\u0438\u043B \u0432\u044B\u0440\u0443\u0447\u043A\u0443 \u0437\u0430 \u0442\u0440\u0438 \u0434\u043D\u044F (9 \u0442\u0440) \u0438 \u0440\u0435\u0448\u0438\u043B \u043F\u043E\u0442\u0435\u0440\u044F\u0442\u044C\u0441\u044F ) \u043E\u0441\u0442\u0430\u0435\u0442\u0441\u044F \u0441 \u0435\u0433\u043E \u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044F\u043C\u0438 \u043F\u043E\u0433\u043E\u0432\u043E\u0440\u0438\u0442\u044C, \u0440\u0430\u0437\u0432\u0435 \u0447\u0442\u043E",
  "id" : 92656729787088896,
  "created_at" : "2011-07-17 18:07:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91933222266609664",
  "text" : "\u0422\u043E\u0442, \u043A\u0442\u043E \u043E\u0440\u0438\u0435\u043D\u0442\u0438\u0440\u0443\u0435\u200B\u0442\u0441\u044F, \u0441\u043A\u043E\u0440\u0435\u0435 \u0432\u0441\u0435\u0433\u043E \u0434\u043E\u0433\u0430\u0434\u0430\u0435\u0442\u0441\u044F\u200B \u0447\u0442\u043E \u0437\u0430 \u043D\u0438\u0448\u0430. )",
  "id" : 91933222266609664,
  "created_at" : "2011-07-15 18:12:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "91933159880536064",
  "text" : "\u0414\u0440\u0443\u0437\u044C\u044F, \u0438\u0449\u0443 \u043F\u0430\u0440\u0442\u043D\u0435\u0440\u0430 - \u043A\u043E\u0442\u043E\u0440\u043E\u043C\u0443 \u0431\u0443\u0434\u0435\u0442 \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u043E \u0433\u043E\u0434 \u0438\u043B\u0438 \u0434\u0432\u0430 \u0440\u0430\u0437\u0432\u0438\u0432\u0430\u0442\u044C \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442 \u043C\u0430\u0433\u0430\u0437\u0438\u043D \u0432 \u0442\u0435\u043C\u0430\u0442\u0438\u043A\u0435 \u0433\u0430\u0434\u0436\u0435\u0442\u043E\u0432.",
  "id" : 91933159880536064,
  "created_at" : "2011-07-15 18:12:28 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "90453691219456000",
  "text" : "\u0412 \u042A \u0414\u0435\u043D\u044C\u0433\u0438 \u0441\u0442\u0430\u0442\u044C\u044F \u043F\u0440\u043E \u0411\u0430\u043D\u043A \u041C\u043E\u0441\u043A\u0432\u044B - \"\u041E\u0434\u043D\u043E\u0440\u0443\u043A\u0438\u0439 \u0430\u0443\u0434\u0438\u0442\". ) \u041A\u043E\u043F\u0438\u0440\u0430\u0439\u0442\u0435\u0440\u044B \u043E\u043A",
  "id" : 90453691219456000,
  "created_at" : "2011-07-11 16:13:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041C\u0430\u043A\u0441\u0438\u043C",
      "screen_name" : "SeT1988",
      "indices" : [ 3, 11 ],
      "id_str" : "178410096",
      "id" : 178410096
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87925507211018241",
  "text" : "RT @SeT1988: \u041C\u041C\u0412\u0411 \u0443\u0434\u043B\u0438\u043D\u044F\u0435\u0442 \u0442\u043E\u0440\u0433\u043E\u0432\u0443\u044E \u0441\u0435\u0441\u0441\u0438\u044E \u043D\u0430 \u0444\u043E\u043D\u0434\u043E\u0432\u043E\u043C \u0440\u044B\u043D\u043A\u0435: \u0421 1 \u0441\u0435\u043D\u0442\u044F\u0431\u0440\u044F \u041C\u041C\u0412\u0411 \u0440\u0430\u0441\u0448\u0438\u0440\u0438\u0442 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0435 \u0440\u0430\u043C\u043A\u0438 \u0442\u043E\u0440\u0433\u043E\u0432 \u043D\u0430 \u0444\u043E\u043D\u0434\u043E\u0432\u043E\u043C \u0440... http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "87917017503514625",
    "text" : "\u041C\u041C\u0412\u0411 \u0443\u0434\u043B\u0438\u043D\u044F\u0435\u0442 \u0442\u043E\u0440\u0433\u043E\u0432\u0443\u044E \u0441\u0435\u0441\u0441\u0438\u044E \u043D\u0430 \u0444\u043E\u043D\u0434\u043E\u0432\u043E\u043C \u0440\u044B\u043D\u043A\u0435: \u0421 1 \u0441\u0435\u043D\u0442\u044F\u0431\u0440\u044F \u041C\u041C\u0412\u0411 \u0440\u0430\u0441\u0448\u0438\u0440\u0438\u0442 \u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0435 \u0440\u0430\u043C\u043A\u0438 \u0442\u043E\u0440\u0433\u043E\u0432 \u043D\u0430 \u0444\u043E\u043D\u0434\u043E\u0432\u043E\u043C \u0440... http:\/\/bit.ly\/klVXRm",
    "id" : 87917017503514625,
    "created_at" : "2011-07-04 16:13:45 +0000",
    "user" : {
      "name" : "\u041C\u0430\u043A\u0441\u0438\u043C",
      "screen_name" : "SeT1988",
      "protected" : false,
      "id_str" : "178410096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710368771182108673\/s3GVf-un_normal.jpg",
      "id" : 178410096,
      "verified" : false
    }
  },
  "id" : 87925507211018241,
  "created_at" : "2011-07-04 16:47:29 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87907146523615232",
  "text" : "\u0418\u043D\u0442\u0435\u0440\u0435\u0441\u0435\u043D \u043B\u0438\u0441\u0442\u0438\u043D\u0433 \u0410, \u0441\u0435\u0439\u0447\u0430\u0441 \u043F\u043E\u043A\u0430 \u0447\u0442\u043E \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 \u043D\u0430 \u043F\u0440\u043E\u0434\u0430\u0436\u0443 \u0431\u043E\u043D\u0434\u043E\u0432\/\u0430\u0434\u0440 - \u0434\u043E 25% \u043E\u0442 \u043A\u0430\u043F\u0438\u0442\u0430\u043B\u0430.",
  "id" : 87907146523615232,
  "created_at" : "2011-07-04 15:34:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87906418526658561",
  "text" : "\u0434\u043E 1 \u0441\u0435\u043D\u0442\u044F\u0431\u0440\u044F \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E \u0433\u043E\u0434\u0430 \u043E\u0442\u043C\u0435\u043D\u0438\u0442\u044C \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F \u043D\u0430 \u0440\u0430\u0437\u043C\u0435\u0449\u0435\u043D\u0438\u0435 \u0438 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u044E \u043E\u0431\u0440\u0430\u0449\u0435\u043D\u0438\u044F \u0446\u0435\u043D\u043D\u044B\u0445 \u0431\u0443\u043C\u0430\u0433 \u0440\u043E\u0441\u0441\u0438\u0439\u0441\u043A\u0438\u0445 \u044D\u043C\u0438\u0442\u0435\u043D\u0442\u043E\u0432 \u0437\u0430 \u043F\u0440\u0435\u0434\u0435\u043B\u0430\u043C\u0438 \u0441\u0442\u0440\u0430\u043D\u044B",
  "id" : 87906418526658561,
  "created_at" : "2011-07-04 15:31:38 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "87906329049579520",
  "text" : "\u0415\u0441\u043B\u0438 \u0432\u044B \u0436\u0430\u043B\u0435\u0435\u0442\u0435, \u0447\u0442\u043E \u043D\u0435 \u0438\u043C\u0435\u043B\u0438 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0438 \u0437\u0430\u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0432 90-\u0435, \u0442\u043E, \u0441\u043A\u043E\u043D\u0446\u0435\u043D\u0442\u0440\u0438\u0440\u0443\u0439\u0442\u0435\u0441\u044C: \u0414\u043C\u0438\u0442\u0440\u0438\u0439 \u041C\u0435\u0434\u0432\u0435\u0434\u0435\u0432 \u043F\u043E\u0440\u0443\u0447\u0438\u043B \u043F\u0440\u0430\u0432\u0438\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u0443 \u0432 \u0441\u0440\u043E\u043A",
  "id" : 87906329049579520,
  "created_at" : "2011-07-04 15:31:16 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "86909793519935488",
  "geo" : { },
  "id_str" : "86913501221748737",
  "in_reply_to_user_id" : 115707779,
  "text" : "@fuckdaoutlaws \u0433\u0434\u0435?",
  "id" : 86913501221748737,
  "in_reply_to_status_id" : 86909793519935488,
  "created_at" : "2011-07-01 21:46:08 +0000",
  "in_reply_to_screen_name" : "vasyunin",
  "in_reply_to_user_id_str" : "115707779",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]