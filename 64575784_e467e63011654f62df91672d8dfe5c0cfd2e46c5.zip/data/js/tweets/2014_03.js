Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445946722918096896",
  "text" : "\u043F\u0443\u0441\u0442\u044C \u0430\u043D\u0433\u0435\u043B\u044B \u043F\u0430\u0434\u0430\u044E\u0442, \u0430 wifi \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0430\u0435\u0442 \u0434\u044B\u0448\u0430\u0442\u044C, \u043E\u0431\u043C\u0430\u043D\u044B\u0432\u0430\u044F \u0441\u043C\u0435\u0440\u0442\u044C",
  "id" : 445946722918096896,
  "created_at" : "2014-03-18 15:35:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444586776070721536",
  "text" : "\u041F\u0443\u0440\u0438\u043C - \u044D\u0442\u043E \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0435\u043D\u0438\u0435 \u043A\u043B\u0430\u0441\u0441\u043E\u0432\u043E\u0439 \u0431\u043E\u0440\u044C\u0431\u044B \u0434\u0440\u0443\u0433\u0438\u043C\u0438 \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C\u0438",
  "id" : 444586776070721536,
  "created_at" : "2014-03-14 21:32:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Web App\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/QSE1ru8Vwr",
      "expanded_url" : "https:\/\/github.com\/iogr\/MarxC",
      "display_url" : "github.com\/iogr\/MarxC"
    } ]
  },
  "geo" : { },
  "id_str" : "440080461512318976",
  "text" : "MarxC , Karl Marx based programming language https:\/\/t.co\/QSE1ru8Vwr",
  "id" : 440080461512318976,
  "created_at" : "2014-03-02 11:05:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]