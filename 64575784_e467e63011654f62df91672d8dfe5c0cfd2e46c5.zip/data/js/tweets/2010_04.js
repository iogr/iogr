Grailbird.data.tweets_2010_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13052558946",
  "text" : "DST \u043F\u043E\u043A\u0443\u043F\u0430\u044E\u0442 icq \u0437\u0430 187,5$ \u043C\u043B\u043D. \u041F\u0435\u0447\u0430\u043B\u044C \u043A\u0430\u043A\u0430\u044F",
  "id" : 13052558946,
  "created_at" : "2010-04-29 00:00:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vova",
      "screen_name" : "Lefski",
      "indices" : [ 0, 7 ],
      "id_str" : "99797332",
      "id" : 99797332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13059007339",
  "in_reply_to_user_id" : 99797332,
  "text" : "@Lefski \u0434\u0430, 35 \u0432\u043C\u0435\u0441\u0442\u043E 2 - \u044D\u0442\u043E \u043F\u0440\u0435\u0441\u0442\u0443\u043F\u043B\u0435\u043D\u0438\u0435",
  "id" : 13059007339,
  "created_at" : "2010-04-29 00:00:00 +0000",
  "in_reply_to_screen_name" : "Lefski",
  "in_reply_to_user_id_str" : "99797332",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12940421995",
  "text" : "\u041E\u0447\u0435\u0440\u0435\u0434\u043D\u0430\u044F \u043F\u043E\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0441\u043E\u0446\u0438\u043E\u043B\u043E\u0433\u0438\u044F http:\/\/yfrog.com\/4b9esj",
  "id" : 12940421995,
  "created_at" : "2010-04-27 00:00:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0432\u0441\u0435\u0433\u0434\u0430 \u0442\u0430\u043A \u0434\u0435\u043B\u0430\u044E!",
      "screen_name" : "romandos",
      "indices" : [ 0, 9 ],
      "id_str" : "75751947",
      "id" : 75751947
    }, {
      "name" : "Anton Gorbunov",
      "screen_name" : "iogr",
      "indices" : [ 10, 15 ],
      "id_str" : "64575784",
      "id" : 64575784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "12753478471",
  "geo" : { },
  "id_str" : "12754339184",
  "in_reply_to_user_id" : 75751947,
  "text" : "@romandos @iogr \u0445\u043C",
  "id" : 12754339184,
  "in_reply_to_status_id" : 12753478471,
  "created_at" : "2010-04-24 00:00:00 +0000",
  "in_reply_to_screen_name" : "romandos",
  "in_reply_to_user_id_str" : "75751947",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12775855543",
  "text" : "\u0421\u0438\u0434\u0438\u043C \u0441\u043E \u0421\u0442\u0430\u0439\u043D\u043A\u0438\u043B\u043B\u043E\u043C \u0432 \"\u043A\u0443\u043A\u043B\u0430\u0445-\u043F\u0438\u0441\u0442\u043E\u043B\u0435\u0442\u0430\u0445\" http:\/\/yfrog.com\/jch3qj",
  "id" : 12775855543,
  "created_at" : "2010-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12778510652",
  "text" : "http:\/\/yfrog.com\/jayyywvj",
  "id" : 12778510652,
  "created_at" : "2010-04-24 00:00:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12692598346",
  "text" : "\u041F\u043E\u0439\u043C\u0430\u043B \u0432\u0447\u0435\u0440\u0430 \u043C\u0435\u0434\u0438\u0430\u0442\u043E\u0440 \u041C\u0430\u043B\u043C\u0441\u0442\u0438\u043D\u0430",
  "id" : 12692598346,
  "created_at" : "2010-04-23 00:00:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12526449991",
  "text" : "\u041D\u0438\u043A\u0430\u043A \u043D\u0435 \u043F\u043E\u043B\u0443\u0447\u0430\u0435\u0442\u0441\u044F \u043F\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u0442\u0430\u043A\u0438 \u0442\u0432\u0438\u0442\u0442\u0435\u0440\u0440\u0438\u0444\u0438\u043A",
  "id" : 12526449991,
  "created_at" : "2010-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12539690855",
  "text" : "\u0412\u0441\u0435, \u043A\u0430\u0436\u0435\u0442\u0441\u044F \u0442\u0430\u043A\u0438 \u043F\u043E\u0441\u0442\u0430\u0432\u0438\u043B http:\/\/yfrog.com\/0yrs7jj",
  "id" : 12539690855,
  "created_at" : "2010-04-20 00:00:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]