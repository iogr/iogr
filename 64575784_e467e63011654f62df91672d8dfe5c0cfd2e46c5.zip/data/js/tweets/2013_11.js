Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405622400529600512",
  "text" : "\u0438\u0434\u0438\u043E\u0442 \u043F\u043E\u0448\u0435\u043B \u0438 \u0432\u044B\u0443\u0447\u0438\u043B \u0438\u0432\u0440\u0438\u0442",
  "id" : 405622400529600512,
  "created_at" : "2013-11-27 09:01:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]