Grailbird.data.tweets_2016_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "725243953902133248",
  "text" : "Thelonious Monk, Rosamonte, \u0443\u0441\u0442\u0430\u043B\u043E\u0441\u0442\u044C",
  "id" : 725243953902133248,
  "created_at" : "2016-04-27 08:43:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "724505029747585024",
  "text" : "\u0411\u0440\u044D\u0434 \u041F\u0438\u0442\u0442 \u0438 \u0410\u043D\u0434\u0436\u0435\u043B\u0438\u043D\u0430 \u0414\u0436\u043E\u043B\u0438 \u043F\u0435\u0440\u0435\u0435\u0434\u0443\u0442 \u043D\u0430 \u0431\u0435\u0440\u0435\u0433 \u0422\u0435\u043C\u0437\u044B",
  "id" : 724505029747585024,
  "created_at" : "2016-04-25 07:47:14 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Web App\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "717977835378491392",
  "text" : "\u0414\u0435\u043D\u044C, \u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u0447\u0443\u0432\u0441\u0442\u0432\u0443\u0435\u0448\u044C \u0441\u0435\u0431\u044F \u0441\u043F\u0440\u0430\u0439\u0442\u043E\u0432\u044B\u043C \u043C\u043E\u043D\u0441\u0442\u0440\u043E\u043C",
  "id" : 717977835378491392,
  "created_at" : "2016-04-07 07:30:29 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]