Grailbird.data.tweets_2012_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "196643382225936385",
  "text" : "\u0417\u0430\u0440\u0430\u0437\u0438\u043B \u0441\u0435\u0431\u044F \u0438\u0434\u0435\u0435\u0439 \u043D\u0435 \u0433\u0440\u0443\u0437\u0438\u0442\u044C \u0441\u0435\u043C\u0430\u043D\u0442\u0438\u043A\u0443 \u0438 \u0432\u043C\u0435\u0441\u0442\u043E \u0435\u0435 \u0442.\u043D. \u043C\u0435\u043D\u0442\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u044D\u0444\u0444\u0435\u043A\u0442\u0430 \u0440\u0435\u043F\u043B\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0432 \u0434\u0438\u0430\u043B\u043E\u0433 \u0438\u0441\u043A\u043B\u044E\u0447\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u0441\u0438\u043D\u0442\u0430\u043A\u0441\u0438\u0441 \u0438\u043B\u0438 \"\u043F\u0440\u0430\u0433\u043C\u0430\u0442\u0438\u043A\u0443\"",
  "id" : 196643382225936385,
  "created_at" : "2012-04-29 16:53:30 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "194530481210011649",
  "text" : "Mechanical turk: through libidinal disinvestment (\"I'm going to work, so why bother with anything?\") to joblessness acceptance",
  "id" : 194530481210011649,
  "created_at" : "2012-04-23 20:57:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "193705155001204736",
  "text" : "\u041F\u0440\u043E\u0441\u0438\u0434\u0435\u043B \u043D\u0430 \u0441\u0442\u0443\u043F\u0435\u043D\u044C\u043A\u0435 \u0443 \u0432\u044B\u0445\u043E\u0434\u0430 \u0438\u0437 \u043C\u0430\u044F\u043A\u043E\u0432\u0441\u043A\u043E\u0439 \u043F\u043E\u043B\u0442\u043E\u0440\u0430 \u0447\u0430\u0441\u0430 \u0432 \u0441\u0432\u043E\u0435 \u0443\u0434\u043E\u0432\u043E\u043B\u044C\u0441\u0442\u0432\u0438\u0435. \u041D\u0430 \u0441\u0430\u043C\u043E\u043C \u0434\u0435\u043B\u0435 \u0443\u0436\u0435 \u0434\u0432\u0430.",
  "id" : 193705155001204736,
  "created_at" : "2012-04-21 14:18:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/QwkURSyS",
      "expanded_url" : "http:\/\/img.ly\/gZ2s",
      "display_url" : "img.ly\/gZ2s"
    } ]
  },
  "geo" : { },
  "id_str" : "192344542240972800",
  "text" : "http:\/\/t.co\/QwkURSyS \u0444\u043E\u043C \u0445\u0430\u0443\u0437\u0435 \u0431\u0438\u0441 \u0446\u0443\u043C \u043C\u0430\u0443\u0437\u0435 \u043B\u0438\u0445\u044C\u0442 \u043D\u0443\u0440 \u0435\u0439\u043D \u0442\u0440\u0438\u0442\u0442",
  "id" : 192344542240972800,
  "created_at" : "2012-04-17 20:11:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "f V nj",
      "screen_name" : "gotessa",
      "indices" : [ 0, 8 ],
      "id_str" : "888800355915620355",
      "id" : 888800355915620355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191970235568488449",
  "text" : "@gotessa try to shake",
  "id" : 191970235568488449,
  "created_at" : "2012-04-16 19:24:05 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u0438\u043A\u0438\u0442\u0430 \u0422\u043E\u043C\u0438\u043B\u043B\u0438\u043D",
      "screen_name" : "TomilinNikita",
      "indices" : [ 0, 14 ],
      "id_str" : "74164361",
      "id" : 74164361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "191968433536114690",
  "geo" : { },
  "id_str" : "191969628463968256",
  "in_reply_to_user_id" : 51485640,
  "text" : "@TomilinNikita \u0438\u0433\u0440\u0430\u043B \u043B\u0438 \u043E\u043D \u0432 grim fandango, \u0432\u043E\u0442 \u0432 \u0447\u0435\u043C \u0432\u043E\u043F\u0440\u043E\u0441.",
  "id" : 191969628463968256,
  "in_reply_to_status_id" : 191968433536114690,
  "created_at" : "2012-04-16 19:21:40 +0000",
  "in_reply_to_screen_name" : "TMLN_doc",
  "in_reply_to_user_id_str" : "51485640",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 43, 54 ],
      "id_str" : "804341497441255424",
      "id" : 804341497441255424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/gDaqyQuu",
      "expanded_url" : "http:\/\/4sq.com\/IfHnOV",
      "display_url" : "4sq.com\/IfHnOV"
    } ]
  },
  "geo" : { },
  "id_str" : "191879723025047553",
  "text" : "I just unlocked the \u201C4sqDay 2012\u201D badge on @foursquare! Cupcakes and crowns for all! http:\/\/t.co\/gDaqyQuu",
  "id" : 191879723025047553,
  "created_at" : "2012-04-16 13:24:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191868260533284865",
  "text" : "\u0421\u043E\u0444\u044C\u044F \u041B\u044C\u0432\u043E\u0432\u043D\u0430: \u0410 \u043C\u043E\u0436\u043D\u043E \u043B\u0438 \u043A\u043E\u0448\u0435\u0440\u043E\u0432\u0430\u0442\u044C \u043C\u043E\u0431\u0438\u043B\u044C\u043D\u043E\u0435 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435? \u041C\u043E\u0436\u043D\u043E \u043B\u0438 \u0435\u0435 \u043E\u043F\u0443\u0441\u043A\u0430\u0442\u044C \u0432 \u043C\u0438\u043A\u0432\u0443?\n\u041D\u0438\u043D\u0430 \u0418\u0437\u0440\u0430\u0438\u043B\u0435\u0432\u043D\u0430: \u0427\u0430\u0439\u043D\u0438\u043A \u044F \u0441\u0432\u043E\u0439 \u043E\u043F\u0443\u0441\u043A\u0430\u043B\u0430 \u2014 \u0432\u044B\u0434\u0435\u0440\u0436\u0430\u043B.",
  "id" : 191868260533284865,
  "created_at" : "2012-04-16 12:38:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/8IGPssI4",
      "expanded_url" : "http:\/\/instagr.am\/p\/JdEnnvq9L2\/",
      "display_url" : "instagr.am\/p\/JdEnnvq9L2\/"
    } ]
  },
  "geo" : { },
  "id_str" : "191629077810130944",
  "text" : "\u043C\u043B\u0440\u0434 \u0434\u043E\u043B http:\/\/t.co\/8IGPssI4",
  "id" : 191629077810130944,
  "created_at" : "2012-04-15 20:48:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191613790591270912",
  "text" : "\u0412 \u0442\u0430\u0440\u043D\u0430\u043A\u0441\u043A\u043E\u0439 \u043A\u043E\u043C\u043C\u0443\u043D\u0435 \u043A\u0430\u0444\u0435, \u043A\u043E\u043D\u0435\u0447\u043D\u043E, \u043F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u0435\u0439 \u043D\u0435 \u043F\u043E\u0442\u043E\u043C\u0443,\u0447\u0442\u043E \u0432 \u0441\u0442\u043E\u043B\u043E\u0432\u043E\u0439 \u0438 \u0431\u0438\u0431\u043B\u0438\u043E\u0442\u0435\u043A\u0435 \u043B\u0435\u0437\u0443\u0442 \u0432 \u0434\u0443\u0448\u0443 \u0441\u043E \u0441\u0432\u043E\u0438\u043C \u0441\u043E\u0446\u0438\u0430\u043B\u0438\u0437\u043C\u043E\u043C, \u0430 \u043F\u043E \u043E\u0431\u0441\u0442\u043E\u044F\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u0430\u043C",
  "id" : 191613790591270912,
  "created_at" : "2012-04-15 19:47:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191611088939388928",
  "text" : "\u0422\u0430\u0440\u043D\u0430\u043A\u0441\u043A\u0438\u0435 \u043A\u043E\u043C\u0443\u043D\u043D\u0430\u0440\u044B \u043F\u0440\u043E\u0438\u0437\u0432\u0435\u043B\u0438 \u0432\u043F\u0435\u0447\u0430\u0442\u043B\u0435\u043D\u0438\u0435 \u043D\u0430 \u0443\u0434 \u043D\u0430\u043D\u0438\u043C\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u0445, \u0410\u0440\u0441\u0435\u043D\u0442\u044C\u0435\u0432 \u0438 \u041C\u0435\u0434\u0432\u0435\u0434\u0435\u0432 \u043F\u0440\u0438\u0441\u0443\u0442\u0441\u0442\u0432\u043E\u0432\u0430\u043B\u0438 \u043A\u0430\u043A \u043F\u0440\u043E\u0432\u043E\u0434\u043D\u0438\u043A\u0438-\u043D\u0430\u0434\u0437\u0438\u0440\u0430\u0442\u0435\u043B\u0438 \u043E\u0442 \u0441\u043E\u0446\u0438\u0430\u043B\u0438\u0437\u043C\u0430",
  "id" : 191611088939388928,
  "created_at" : "2012-04-15 19:36:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191594199496396800",
  "text" : "\u041F\u0430\u0440\u0435\u043D\u044C, \u0441 \u043A\u043E\u0442\u043E\u0440\u044B\u043C \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0443\u044E appcrowdfunding, \u0432\u0435\u0434\u0435\u0442 \u043D\u0435 \u043C\u0435\u043D\u044C\u0448\u0435 \u0440\u0430\u0437\u043D\u043E\u043E\u0431\u0440\u0430\u0437\u043D\u044B\u0445 \u0436\u0443\u0440\u043D\u0430\u043B\u043E\u0432, \u0447\u0435\u043C \u0421\u0442\u0438\u0432\u0435\u043D \u0412\u043E\u043B\u044C\u0444\u0440\u0430\u043C.",
  "id" : 191594199496396800,
  "created_at" : "2012-04-15 18:29:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191591133976068096",
  "text" : "\u041A\u0430\u043D\u0438\u043A\u0443\u043B\u044B \u0432 \u0430\u043D\u0430\u0431\u0438\u043E\u0437\u0435, \u043F\u0435\u0440\u0435\u043C\u0435\u043D\u043A\u0430 \u0432 \u043A\u043E\u043C\u0435, \u0437\u0430\u043D\u044F\u0442\u0438\u044F \u0432 \u0430\u0434\u0443 Btw, \u0431\u044B\u0432\u0430\u044E\u0442 \u043B\u0438 \u0441\u043B\u0443\u0447\u0430\u0438 \u044D\u0445\u043E\u043F\u0440\u0430\u043A\u0441\u0438\u0438 \u043A\u0430\u0442\u0430\u043B\u0435\u043F\u0441\u0438\u0438 \u0443 \u043C\u0438\u043C\u043E\u0432? \u0415\u0441\u043B\u0438 \u044D\u0442\u043E \u043D\u0435 \u043C\u0435\u043C, \u0442\u043E \u0447\u0442\u043E \u0442\u043E\u0433\u0434\u0430 \u043C\u0435\u043C?",
  "id" : 191591133976068096,
  "created_at" : "2012-04-15 18:17:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191235336486141952",
  "text" : "\u041A\u0430\u0436\u0434\u0443\u044E \u043D\u0435\u0434\u0435\u043B\u044E \u0434\u0435\u043B\u0430\u044E \u043E\u0431\u0440\u0435\u0437\u0430\u043D\u0438\u0435. \u0418 \u043A\u0430\u0436\u0434\u044B\u0439 \u043E\u0431\u0440\u0435\u0437\u043E\u043A \u043F\u043E\u0445\u043E\u0436 \u043D\u0430 fix-it \u0442\u0438\u043A\u0435\u0442.  \u044F \u043F\u0440\u043E \u0440\u0435\u043C\u0435\u043D\u044C",
  "id" : 191235336486141952,
  "created_at" : "2012-04-14 18:43:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "191202801014161408",
  "text" : "Do molecular biologists wear designer genes?",
  "id" : 191202801014161408,
  "created_at" : "2012-04-14 16:34:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190883973096939520",
  "text" : "\u041F\u0440\u0438 \u043C\u044B\u0441\u043B\u044F\u0445 \u043E \u0437\u0430\u0431\u043E\u0442\u0435 \u043E \u0441\u0435\u0431\u0435 \u0432\u0441\u043F\u043E\u043C\u0438\u043D\u0430\u044E \u043A\u0430\u043A \u0425\u043E\u043A\u0438\u043D\u0433 \u0432 \u0438\u043D\u0442\u0435\u0440\u0432\u044C\u044E \u043A 70-\u043B\u0435\u0442\u0438\u044E \u0443\u043F\u043E\u043C\u0438\u043D\u0430\u0435\u0442 \u043E \u0442\u043E\u043C, \u0447\u0442\u043E \u043E\u043D \u0432\u0441\u0435 \u0435\u0449\u0435 \u0437\u0430\u043D\u0438\u043C\u0430\u0435\u0442 \u0441\u0435\u0431\u044F \u0440\u0430\u0437\u043C\u044B\u0448\u043B\u0435\u043D\u0438\u044F\u043C\u0438 \u043E \u0436\u0435\u043D\u0449\u0438\u043D\u0430\u0445",
  "id" : 190883973096939520,
  "created_at" : "2012-04-13 19:27:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/fontli\/id506650372?mt=8&uo=4\" rel=\"nofollow\"\u003EFontli on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 47 ],
      "url" : "http:\/\/t.co\/ijGKFUHp",
      "expanded_url" : "http:\/\/www.fontli.com\/UGhvdG9fNGY3ZDU0Y2EwNWFhMTcwZTYzMDAwMDA0",
      "display_url" : "fontli.com\/UGhvdG9fNGY3ZD\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190803617358426112",
  "text" : "Sharing a post from Fontli http:\/\/t.co\/ijGKFUHp",
  "id" : 190803617358426112,
  "created_at" : "2012-04-13 14:08:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yota",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190538612151037952",
  "text" : "Lte wifi \u0440\u043E\u0443\u0442\u0435\u0440 \u0443 \u043C\u0435\u043D\u044F \u0432 \u0448\u0442\u0430\u043D\u0430\u0445 #yota",
  "id" : 190538612151037952,
  "created_at" : "2012-04-12 20:35:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Not Dylan Moran",
      "screen_name" : "NotDylanMoran",
      "indices" : [ 0, 14 ],
      "id_str" : "113276240",
      "id" : 113276240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/wyRrCYl0",
      "expanded_url" : "http:\/\/itineraries.msnbc.msn.com\/_news\/2012\/04\/11\/11126072-remembering-the-12-dogs-aboard-the-titanic",
      "display_url" : "itineraries.msnbc.msn.com\/_news\/2012\/04\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "190537292996292609",
  "in_reply_to_user_id" : 113276240,
  "text" : "@notdylanmoran mister Moran this is weri funny but I sink your grammi could survive: http:\/\/t.co\/wyRrCYl0",
  "id" : 190537292996292609,
  "created_at" : "2012-04-12 20:30:05 +0000",
  "in_reply_to_screen_name" : "NotDylanMoran",
  "in_reply_to_user_id_str" : "113276240",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190533489265868800",
  "text" : "\u041F\u043E\u0440\u0430 \u043F\u0435\u0440\u0435\u0441\u0442\u0430\u0442\u044C \u043E\u0431\u043C\u0430\u043D\u044B\u0432\u0430\u0442\u044C \u0441\u0435\u0431\u044F - \u044D\u0442\u043E \u0431\u044B\u043B \u041B\u0435\u043F\u0440\u0438\u043A\u043E\u043D",
  "id" : 190533489265868800,
  "created_at" : "2012-04-12 20:14:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u041E\u0432\u0446\u044B",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "190533347154477057",
  "text" : "\u0412\u0430\u0436\u043D\u043E: \u0420\u0443\u043A\u0430, \u0438\u0433\u0440\u0430\u0432\u0448\u0430\u044F \u0432 \u043E\u0432\u0435\u0446 \u043D\u0430 \u043C\u043E\u0435\u043C \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u0435 \u0438 \u0442\u0432\u0438\u0442\u0438\u0432\u0448\u0430\u044F \u043E\u0431 \u044D\u0442\u043E\u043C \u043F\u043E\u043A\u0430 \u044F \u0441\u043F\u0430\u043B \u043D\u0435 \u043F\u0440\u043E\u0448\u043B\u0430 \u0434\u0430\u043B\u044C\u0448\u0435 8 \u0443\u0440\u043E\u0432\u043D\u044F #\u041E\u0432\u0446\u044B",
  "id" : 190533347154477057,
  "created_at" : "2012-04-12 20:14:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/dqSCRHxo",
      "expanded_url" : "http:\/\/4sq.com\/IIGble",
      "display_url" : "4sq.com\/IIGble"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7546202493, 37.6364234552 ]
  },
  "id_str" : "190510898954244097",
  "text" : "\u0438\u043D\u0430\u0447\u0435 \u043C\u0435\u0434\u0432\u0435\u0434\u044C \u043D\u0430\u0441\u0442\u0438\u0433\u043D\u0435\u0442 (@ \u0414\u043E\u0440\u043E\u0433\u0430\u044F, \u044F \u043F\u0435\u0440\u0435\u0437\u0432\u043E\u043D\u044E w\/ 4 others) http:\/\/t.co\/dqSCRHxo",
  "id" : 190510898954244097,
  "created_at" : "2012-04-12 18:45:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189672988906487809",
  "text" : "Someone has already told you about app crowdfunding in order to plug you to something? Unheard of! Sacrilege!",
  "id" : 189672988906487809,
  "created_at" : "2012-04-10 11:15:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tylercowen",
      "screen_name" : "tylercowen",
      "indices" : [ 26, 37 ],
      "id_str" : "8496762",
      "id" : 8496762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189425923760730112",
  "text" : "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u044F \u043E\u0442\u043A\u0440\u044B\u043B \u0434\u043B\u044F \u0441\u0435\u0431\u044F @TylerCowen'\u0430, \u044D\u043A\u043E\u043D\u043E\u043C\u0438\u0441\u0442\u0430",
  "id" : 189425923760730112,
  "created_at" : "2012-04-09 18:53:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 120 ],
      "url" : "https:\/\/t.co\/BXx1dzzf",
      "expanded_url" : "https:\/\/www.jstor.org\/stable\/40180254",
      "display_url" : "jstor.org\/stable\/40180254"
    } ]
  },
  "geo" : { },
  "id_str" : "189365222362972160",
  "text" : "Compositional verificationing of multi-agent systems in temporal multi-epistemic logic like a Girl https:\/\/t.co\/BXx1dzzf",
  "id" : 189365222362972160,
  "created_at" : "2012-04-09 14:52:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "antistate",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/sJBUUA0J",
      "expanded_url" : "http:\/\/falanster.livejournal.com\/443362.html",
      "display_url" : "falanster.livejournal.com\/443362.html"
    } ]
  },
  "geo" : { },
  "id_str" : "189357871463546880",
  "text" : "\u0421\u043E\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u0430\u044F \u0431\u043E\u0440\u044C\u0431\u0430 \u0432\u043E \u0424\u0440\u0430\u043D\u0446\u0438\u0438: \u043F\u043E\u0437\u0438\u0446\u0438\u044F \u043A\u043E\u043B\u043B\u0435\u043A\u0442\u0438\u0432\u0430 \u0422\u0430\u0440\u043D\u0430\u043A http:\/\/t.co\/sJBUUA0J \u0417\u0430\u0439\u0434\u0443 \u043D\u0435\u0441\u043C\u043E\u0442\u0440\u044F \u043D\u0430 \u043F\u043E\u0433\u043E\u0434\u0443, \u043F\u0440\u043E\u0441\u0442\u0443\u0434\u0443 \u0438 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D\u043D\u043E\u0441\u0442\u044C #antistate",
  "id" : 189357871463546880,
  "created_at" : "2012-04-09 14:23:29 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189350375340515328",
  "text" : "0x10c L2 reverse decompiling like a Girl",
  "id" : 189350375340515328,
  "created_at" : "2012-04-09 13:53:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/IVLQGm0u",
      "expanded_url" : "http:\/\/bit.ly\/IqK521",
      "display_url" : "bit.ly\/IqK521"
    } ]
  },
  "geo" : { },
  "id_str" : "189345204652871681",
  "text" : "Taylor & Francis Online :: The social agency of dead bodies - Mortality - Volume 15, Issue 4: http:\/\/t.co\/IVLQGm0u",
  "id" : 189345204652871681,
  "created_at" : "2012-04-09 13:33:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189303302087901184",
  "text" : "\u041A\u0430\u043A \u043D\u0430\u0439\u0442\u0438 \u043E\u0441\u0442\u0440\u043E\u0443\u043C\u043D\u044B\u0445 \u043B\u0438\u043D\u0433\u0432\u0438\u0441\u0442\u043E\u0432, \u043F\u0440\u0435\u0432\u043E\u0441\u0445\u043E\u0434\u043D\u043E \u0432\u043B\u0430\u0434\u0435\u044E\u0449\u0438\u0445 \u0430\u043D\u0433\u043B\u0438\u0439\u0441\u043A\u0438\u043C \u044F\u0437\u044B\u043A\u043E\u043C \u0434\u043B\u044F \u0441\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u044F  \u0441\u043B\u043E\u0432\u0430\u0440\u044F \u043A\u043E\u0440\u043E\u0442\u043A\u0438\u0445 \u0438\u0440\u043E\u043D\u0438\u0447\u043D\u044B\u0445 \u0442\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0445 \u0433\u0435\u043D\u0435\u0440\u0430\u0446\u0438\u0439?",
  "id" : 189303302087901184,
  "created_at" : "2012-04-09 10:46:38 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anton Gorbunov",
      "screen_name" : "iogr",
      "indices" : [ 0, 5 ],
      "id_str" : "64575784",
      "id" : 64575784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "189296893162037248",
  "in_reply_to_user_id" : 64575784,
  "text" : "@iogr: \u0416\u0435\u043D\u0449\u0438\u043D\u0430 \u043F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043B\u0430 \u043D\u0430 \u043C\u0435\u043D\u044F, \u043F\u0440\u043E\u0442\u044F\u043D\u0443\u043B\u0430 \u043C\u043D\u0435 \u0440\u0443\u043A\u0443 \u0438 \u043F\u0435\u0440\u0435\u0448\u043B\u0430 \u043D\u0430 \u044D\u043F\u0438\u043B\u0435\u043F\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0435 \u0441\u0443\u0434\u043E\u0440\u043E\u0433\u0438. \u0438\u043C\u0443\u043D\u043D\u043E\u0433\u0440\u0430\u043C\u043C\u0430 pussy riot hihihihihi",
  "id" : 189296893162037248,
  "created_at" : "2012-04-09 10:21:10 +0000",
  "in_reply_to_screen_name" : "iogr",
  "in_reply_to_user_id_str" : "64575784",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/ubIbyM2j",
      "expanded_url" : "http:\/\/img.ly\/gtTe",
      "display_url" : "img.ly\/gtTe"
    } ]
  },
  "geo" : { },
  "id_str" : "189015876496920576",
  "text" : "http:\/\/t.co\/ubIbyM2j",
  "id" : 189015876496920576,
  "created_at" : "2012-04-08 15:44:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/OxA6T21W",
      "expanded_url" : "http:\/\/img.ly\/gtsf",
      "display_url" : "img.ly\/gtsf"
    }, {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/PrsN3gCs",
      "expanded_url" : "http:\/\/30.media.tumblr.com\/tumblr_m0f7u9kxLI1ro66c2o1_500.jpg",
      "display_url" : "30.media.tumblr.com\/tumblr_m0f7u9k\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "188985559056777218",
  "text" : "What my feet are doing right this moment. http:\/\/t.co\/OxA6T21W P.S. http:\/\/t.co\/PrsN3gCs",
  "id" : 188985559056777218,
  "created_at" : "2012-04-08 13:44:03 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "apps4all",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/7E16nZcV",
      "expanded_url" : "http:\/\/forum.apps4all.ru",
      "display_url" : "forum.apps4all.ru"
    } ]
  },
  "geo" : { },
  "id_str" : "188210227722723328",
  "text" : "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u043F\u0435\u0440\u0432\u044B\u0439 \u0434\u0435\u043D\u044C \u0441\u0430\u043C\u0438-\u0437\u043D\u0430\u0435\u043C-\u0447\u0435\u0433\u043E \u0438 \u043C\u044B \u0432\u0441\u0435\u0439 \u0441\u0442\u0443\u0434\u0438\u0435\u0439 \u0432\u044B\u0431\u0440\u0430\u043B\u0438\u0441\u044C \u043D\u0430 \u041C\u0435\u0436\u0434\u0443\u043D\u0430\u0440\u043E\u0434\u043D\u044B\u0439 \u0444\u043E\u0440\u0443\u043C \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A\u043E\u0432 Apps4all #apps4all http:\/\/t.co\/7E16nZcV",
  "id" : 188210227722723328,
  "created_at" : "2012-04-06 10:23:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anton Gorbunov",
      "screen_name" : "iogr",
      "indices" : [ 0, 5 ],
      "id_str" : "64575784",
      "id" : 64575784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187887621366759424",
  "in_reply_to_user_id" : 64575784,
  "text" : "@iogr: \u0420\u0430\u0437\u0433\u043E\u0432\u043E\u0440 \u0441 \u0431\u044B\u0432\u0448\u0435\u0439 \u043F\u043E\u0445\u043E\u0436 \u043D\u0430 \u0441\u0442\u0430\u0440\u044B\u0439 \u043C\u0430\u0442\u0435\u0440\u044B\u0439 \u0432\u0435\u0441\u0442\u0435\u0440\u043D - \u0443\u0431\u0438\u0432\u0430\u044E\u0442 \u0432\u0441\u0435\u0445, \u0438 \u0432 \u0440\u0430\u043D\u044B \u0437\u0430\u0434\u0443\u0432\u0430\u0435\u0442 \u0440\u0430\u0441\u043A\u0430\u043B\u0435\u043D\u043D\u0443\u044E \u043F\u044B\u043B\u044C \u0441 \u0441\u0443\u0445\u0438\u043C \u043F\u0435\u0441\u043A\u043E\u043C.",
  "id" : 187887621366759424,
  "created_at" : "2012-04-05 13:01:14 +0000",
  "in_reply_to_screen_name" : "iogr",
  "in_reply_to_user_id_str" : "64575784",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187862186536865792",
  "text" : "\u043F\u0441\u0438\u0445\u043E\u0441\u043E\u043C\u0430\u0442\u0438\u043A\u0430",
  "id" : 187862186536865792,
  "created_at" : "2012-04-05 11:20:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckmybrain",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187830394807271424",
  "text" : "\u0417\u0430\u0432\u044F\u0437\u0430\u043B \u0448\u0430\u0440\u0444 \u0441 7 \u043F\u043E\u043F\u044B\u0442\u043A\u0438 - \u043D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E \u0440\u0430\u0441\u0447\u0438\u0442\u044B\u0432\u0430\u043B \u0438\u043A\u0441\u044B \u0438 \u0432\u0435\u043B\u0438\u0447\u0438\u043D\u044B \u0438\u0437\u0433\u0438\u0431\u043E\u0432 \u0442\u0440\u0435\u0445 \u043A\u0440\u0438\u0432\u044B\u0445 \u0431\u0435\u0437\u044C\u0435 #fuckmybrain",
  "id" : 187830394807271424,
  "created_at" : "2012-04-05 09:13:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fuckmybrain",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "187827921602355202",
  "text" : "#fuckmybrain",
  "id" : 187827921602355202,
  "created_at" : "2012-04-05 09:04:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u041C\u043E\u0441\u043A\u0432\u0430_\u0421\u0438\u0442\u0438",
      "indices" : [ 52, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "186902850385870848",
  "text" : "\u0424\u0435\u0434\u0435\u0440\u0430\u0446\u0438\u044F: \u043B\u0443\u0442, \u0440\u0435\u0439\u0434 \u0438\u043B\u0438 occupy, \u0447\u0442\u043E\u0431\u044B \u043D\u0435 \u043F\u043E\u0433\u043E\u0440\u0435\u0442\u044C? #\u041C\u043E\u0441\u043A\u0432\u0430_\u0421\u0438\u0442\u0438",
  "id" : 186902850385870848,
  "created_at" : "2012-04-02 19:48:06 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 42, 53 ],
      "id_str" : "804341497441255424",
      "id" : 804341497441255424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/P9JrxFxE",
      "expanded_url" : "http:\/\/4sq.com\/H6FfXn",
      "display_url" : "4sq.com\/H6FfXn"
    } ]
  },
  "geo" : { },
  "id_str" : "186476344404750336",
  "text" : "I just unlocked the \u201CRed Square\u201D badge on @foursquare! Bring on the borscht! http:\/\/t.co\/P9JrxFxE",
  "id" : 186476344404750336,
  "created_at" : "2012-04-01 15:33:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]