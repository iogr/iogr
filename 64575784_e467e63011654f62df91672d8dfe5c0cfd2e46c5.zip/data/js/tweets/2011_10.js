Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u043E\u0441\u043A\u0430 \u0421\u043F\u0438\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F",
      "screen_name" : "deadboard",
      "indices" : [ 3, 13 ],
      "id_str" : "378041676",
      "id" : 378041676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121880774235533312",
  "text" : "RT @deadboard: \u0411\u041E\u0413 (\u05D9\u05D4\u05D5\u05D4) \u043F\u0435\u0440\u0435\u0434\u0430\u0435\u0442: \u0432\u0447\u0435\u0440\u0430 \u0434\u0436\u043E\u0431\u0441\u0430 \u0447\u043F\u043E\u043A\u043D\u0443\u043B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121880578348949505",
    "text" : "\u0411\u041E\u0413 (\u05D9\u05D4\u05D5\u05D4) \u043F\u0435\u0440\u0435\u0434\u0430\u0435\u0442: \u0432\u0447\u0435\u0440\u0430 \u0434\u0436\u043E\u0431\u0441\u0430 \u0447\u043F\u043E\u043A\u043D\u0443\u043B",
    "id" : 121880578348949505,
    "created_at" : "2011-10-06 09:32:48 +0000",
    "user" : {
      "name" : "\u0414\u043E\u0441\u043A\u0430 \u0421\u043F\u0438\u0440\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0430\u044F",
      "screen_name" : "deadboard",
      "protected" : false,
      "id_str" : "378041676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1555917242\/vanga1_normal.jpg",
      "id" : 378041676,
      "verified" : false
    }
  },
  "id" : 121880774235533312,
  "created_at" : "2011-10-06 09:33:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120983921444929536",
  "text" : "\"How am I immature? Intellectually, emotionally, and sexually. Yeah, but in what other ways?\"",
  "id" : 120983921444929536,
  "created_at" : "2011-10-03 22:09:49 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120869022769221633",
  "text" : "\u041F\u0440\u0438\u0448\u0435\u043B \u043D\u0430 \u043F\u0435\u0440\u0432\u043E\u0435 \u0437\u0430\u043D\u044F\u0442\u0438\u0435 \u0432 \u0432\u044B\u0448\u043A\u0443 - \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u0430\u044F \u043C\u0430\u0442\u0435\u043C\u0430\u0442\u0438\u043A\u0430. \u041A\u043E\u043D\u0442\u0438\u043D\u0433\u0435\u043D\u0442 \u043E\u0442 30 \u043E\u043A\u0430\u0437\u0430\u043B\u0441\u044F.",
  "id" : 120869022769221633,
  "created_at" : "2011-10-03 14:33:15 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]