Grailbird.data.tweets_2014_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "550069743898869760",
  "text" : "\u0441\u043D\u0430\u0447\u0430\u043B\u0430 \u044F \u0443\u0437\u043D\u0430\u043B \u043F\u0440\u043E \u0421\u043C\u0435\u0440\u0442\u044C \u0430\u0432\u0442\u043E\u0440\u0430, \u0430 \u043F\u043E\u0442\u043E\u043C \u043A\u0442\u043E-\u0442\u043E \u043F\u0440\u043E\u0431\u043E\u043B\u0442\u0430\u043B\u0441\u044F \u0438 \u043F\u0440\u043E \u0421\u0430\u043D\u0442\u0443",
  "id" : 550069743898869760,
  "created_at" : "2014-12-30 23:23:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549457429160017920",
  "text" : "\u0448\u0435\u043F\u0442\u0430\u043B \u044F \u0441\u0442\u0440\u0438\u043F\u0442\u0438\u0437\u0435\u0440\u0448\u0435 \u043D\u0430 \u043A\u043E\u0440\u043F\u043E\u0440\u0430\u0442\u0438\u0432\u0435 \u0441\u0435\u0442\u0438 \u0444\u0438\u0442\u043D\u0435\u0441-\u043A\u043B\u0443\u0431\u043E\u0432 \u0437\u0435\u0431\u0440\u0430",
  "id" : 549457429160017920,
  "created_at" : "2014-12-29 06:50:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "549457002112745473",
  "text" : "\u043D\u0435 \u0441\u043E\u043C\u043D\u0435\u0432\u0430\u0439\u0441\u044F, \u0447\u0442\u043E \u0442\u0432\u043E\u0439 parole \u043F\u043E\u043F\u0430\u043B \u0432 \u0447\u0443\u0436\u043E\u0439 \u043F\u043E\u0447\u0442\u043E\u0432\u044B\u0439 \u044F\u0449\u0438\u043A, \u0434\u0430\u0436\u0435 \u0435\u0441\u043B\u0438 \u044F\u0449\u0438\u043A \u044D\u0442\u043E\u0442 \u0432\u043E \u043C\u043D\u0435 \u0441\u0430\u043C\u043E\u043C - \u0430\u0434\u0440\u0435\u0441\u0430\u0446\u0438\u044F \u043D\u0435 \u043F\u0440\u0435\u0434\u043F\u0438\u0441\u0430\u043D\u0430 \u0447\u043B \u043F\u043E\u043C\u0438\u043C\u043E \u043C\u043E\u0435\u0433\u043E \u0438\u043C\u0435\u043D\u0438",
  "id" : 549457002112745473,
  "created_at" : "2014-12-29 06:48:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0418\u043B\u044C\u044F \u041A\u0430\u0439\u0444\u043E\u0436\u043E\u0440",
      "screen_name" : "igap",
      "indices" : [ 0, 5 ],
      "id_str" : "17988848",
      "id" : 17988848
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "549439596392898563",
  "geo" : { },
  "id_str" : "549440216625213440",
  "in_reply_to_user_id" : 17988848,
  "text" : "@igap \u043E\u0442 \u0448\u043B\u0435\u043C\u0430\u0437\u043B\u0430 \u0434\u043E \u043C\u0435\u0448\u0443\u0433\u0430 - \u0440\u0443\u043A\u043E\u0439 \u043F\u043E\u0434\u0430\u0442\u044C )",
  "id" : 549440216625213440,
  "in_reply_to_status_id" : 549439596392898563,
  "created_at" : "2014-12-29 05:42:10 +0000",
  "in_reply_to_screen_name" : "igap",
  "in_reply_to_user_id_str" : "17988848",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547896443080417280",
  "text" : "unit 3: nginx config, unicorn, g\u0337o\u0337l\u0337a\u0337n\u0337g\u0337 =&gt; ruby on rails basic apps revisited: \u2611",
  "id" : 547896443080417280,
  "created_at" : "2014-12-24 23:27:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547811044337664000",
  "text" : "\u044F \u0442\u0449\u0430\u0442\u0435\u043B\u044C\u043D\u043E \u0441\u043E\u0431\u0440\u0430\u043B \u0432\u0441\u0435 \u043E\u0441\u043A\u043E\u043B\u043A\u0438 \u0441\u0442\u043E\u043B\u043A\u043D\u043E\u0432\u0435\u043D\u0438\u0439 \u0441 \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C\u044E, \u0438 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u043D\u044B\u0439 \u043E\u0431\u0440\u0430\u0437 \u0443\u0434\u0430\u0440\u0438\u043B \u043F\u043E \u043C\u043D\u0435 \u0448\u0440\u0430\u043F\u043D\u0435\u043B\u044C\u044E \u043F\u0440\u0438\u043C\u0438\u0442\u0438\u0432\u043D\u044B\u0445 \u0447\u0443\u0432\u0441\u0442\u0432 \u0438 \u0440\u0430\u0437\u043E\u0447\u0430\u0440\u043E\u0432\u0430\u043D\u0438\u044F",
  "id" : 547811044337664000,
  "created_at" : "2014-12-24 17:48:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547469054295179264",
  "text" : "\u0414\u043E\u0440\u043E\u0433\u043E\u0439 Santa Claus, \u0432\u044B \u0436\u0435 - \u0414\u041C, \u043D\u0430 \u041D\u043E\u0432\u044B\u0439 \u0433\u043E\u0434 \u044F \u0445\u043E\u0447\u0443 \u0437\u0435\u0440\u043A\u0430\u043B\u043A\u0443, imac, \u0431\u044B\u0442\u044C \u0433\u0435\u043D\u0435\u0440\u0430\u043B\u044C\u043D\u044B\u043C \u0441\u0435\u043A\u0440\u0435\u0442\u0430\u0440\u0435\u043C \u0421\u0435\u0432\u0435\u0440\u043D\u043E\u0439 \u041A\u043E\u0440\u0435\u0438 \u0438 \u0432 \u043A\u0430\u0444\u0435 \u0410\u0440\u043E\u043C\u0430 \u0432 \u0422\u0435\u043B\u044C-\u0410\u0432\u0438\u0432\u0435!",
  "id" : 547469054295179264,
  "created_at" : "2014-12-23 19:09:28 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547455976253968385",
  "text" : "\u0436\u0430\u043B\u044C,\u0447\u0442\u043E \u0432 \u0432\u043E\u0434\u043E\u0432\u043E\u0440\u043E\u0442\u0435 \u043A\u0440\u0443\u0448\u0435\u043D\u0438\u044F \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0445 \u043D\u0430\u0434\u0435\u0436\u0434 \u0438 \u044D\u043F\u043E\u0441\u0430 \u0431\u0435\u0437\u0440\u0430\u0437\u043B\u0438\u0447\u0438\u044F \u043E\u043D\u0430 \u043E\u043A\u0430\u0437\u0430\u043B\u0430\u0441\u044C \u0442\u043E\u0439 \u0433\u0435\u0440\u0434\u043E\u0439,\u0447\u0442\u043E \u0445\u043B\u043E\u043F\u043D\u0443\u043B\u0430 \u0441 \u0434\u0435\u0448\u0435\u0432\u044B\u043C \u0432\u0438\u0441\u043A\u0438 \u043C\u043E\u0435 \u043B\u0435\u0434\u044F\u043D\u043E\u0435 \u0441\u0435\u0440\u0434\u0446\u0435",
  "id" : 547455976253968385,
  "created_at" : "2014-12-23 18:17:30 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547154615855480832",
  "text" : "\u0422\u0440\u0438 \u043A\u0440\u043E\u043D\u044B \u0434\u043B\u044F \u043C\u043E\u0440\u044F\u043A\u0430, \u0442\u0440\u0438 \u0433\u0440\u0443\u0441\u0442\u043D\u044B\u0445 \u0442\u0438\u0433\u0440\u0430 - \u0442\u0440\u0438 \u0436\u0438\u0437\u043D\u0438 \u0438 \u043B\u0438\u0448\u044C \u043E\u0434\u043D\u0430 \u0441\u043C\u0435\u0440\u0442\u044C",
  "id" : 547154615855480832,
  "created_at" : "2014-12-22 22:20:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "547154191211581440",
  "text" : "Les trois couronnes du matelot, tres tristes tigres - trois vies et une seule mort",
  "id" : 547154191211581440,
  "created_at" : "2014-12-22 22:18:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "546011956139003904",
  "text" : "weekend playlist: Tom Waits, Daniel Kahn and soundtracks of Jarmusch\u2019s Broken Flowers and Only lovers left alive x100",
  "id" : 546011956139003904,
  "created_at" : "2014-12-19 18:39:29 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "545659851943473152",
  "text" : "\u0420\u0430\u0441\u0441\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043B \u0440\u0443\u043A\u0430\u043C\u0438 \u0447\u0435\u0442\u044B\u0440\u0435 \u0433\u0440\u0443\u043F\u043F\u044B \u043F\u043E 20 \u043A\u0430\u0440\u0442\u043E\u0447\u0435\u043A \u0434\u0432\u043E\u0439\u043D\u043E\u0439 \u0441\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u043E\u0439 - \u0440\u044F\u0434\u0430\u043C\u0438 \u0438 bucket sort. \u041F\u043E\u0434\u043D\u0438\u043C\u0430\u044E \u0433\u043B\u0430\u0437\u0430 \u0438 \u0437\u0430\u043C\u0435\u0447\u0430\u044E holyshit facials",
  "id" : 545659851943473152,
  "created_at" : "2014-12-18 19:20:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LASERKRAFTWERKWORD",
      "screen_name" : "laserkraftword",
      "indices" : [ 0, 15 ],
      "id_str" : "2830411367",
      "id" : 2830411367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "545121848477106176",
  "geo" : { },
  "id_str" : "545181075350491136",
  "in_reply_to_user_id" : 2830411367,
  "text" : "@laserkraftword LASERKRAFTWERKMITZVAHTANK",
  "id" : 545181075350491136,
  "in_reply_to_status_id" : 545121848477106176,
  "created_at" : "2014-12-17 11:37:51 +0000",
  "in_reply_to_screen_name" : "laserkraftword",
  "in_reply_to_user_id_str" : "2830411367",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543465394649174016",
  "text" : "\u0412\u0430\u0441 \u0443\u0436\u0435 \u043D\u0438\u0447\u0442\u043E \u043D\u0435 \u0441\u043F\u0430\u0441\u0435\u0442, \u0432\u0430\u043C \u0432\u0441\u0435\u0433\u0434\u0430 \u0431\u0443\u0434\u0435\u0442 \u043C\u0430\u043B\u043E \u0442\u043E\u0433\u043E, \u0447\u0442\u043E \u0435\u0441\u0442\u044C.",
  "id" : 543465394649174016,
  "created_at" : "2014-12-12 18:00:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543465237962563584",
  "text" : "\u0412\u0441\u0435 \u0440\u0435\u0448\u0430\u0435\u0442\u0441\u044F \u0432 \u043F\u0435\u0440\u0438\u043E\u0434 \u043E\u0442\u0440\u043E\u0447\u0435\u0441\u0442\u0432\u0430. \u0415\u0441\u043B\u0438 \u0443 \u0432\u0430\u0441 \u0441\u043B\u043E\u0436\u0438\u043B\u043E\u0441\u044C \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435 \u043E \u043B\u044E\u0431\u0432\u0438, \u0445\u043E\u0442\u044C \u0441\u043A\u043E\u043B\u044C\u043A\u043E-\u043D\u0438\u0431\u0443\u0434\u044C \u0431\u043B\u0430\u0433\u043E\u0440\u043E\u0434\u043D\u043E\u0435 \u0438 \u0432\u043E\u0437\u0432\u044B\u0448\u0435\u043D\u043D\u043E\u0435, \u0432\u044B \u043F\u0440\u043E\u043F\u0430\u043B\u0438.",
  "id" : 543465237962563584,
  "created_at" : "2014-12-12 17:59:44 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543463948121415680",
  "text" : "\u0437\u0430\u043A\u043E\u043D\u0447\u0443 Prototype 466 \u0447\u0435\u0440\u0435\u0437 \u043F\u043E\u043B\u0433\u043E\u0434\u0430, \u0442\u0430\u043A\u0438\u0435 \u0434\u0435\u043B\u0430",
  "id" : 543463948121415680,
  "created_at" : "2014-12-12 17:54:36 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543453142986555392",
  "text" : "(\u043A\u0435\u043D) \u0433\u0443\u0440\u0443 \u043C\u0430\u0440\u043A\u0435\u0442\u0438\u043D\u0433\u0430 \u043D\u0430 \u0437\u0430\u043C\u0435\u0442\u043A\u0443: \u0432\u044B\u0431\u0438\u0432\u0448\u0438\u0439\u0441\u044F \u0438\u0437 \u0431\u0440\u044E\u043A \u0446\u0438\u0446\u0438\u0442 \u0443\u0432\u0435\u043B\u0438\u0447\u0438\u0432\u0430\u0435\u0442 engagement \u0430\u0443\u0434\u0438\u0442\u043E\u0440\u0438\u0438 \u043D\u0430 90%.",
  "id" : 543453142986555392,
  "created_at" : "2014-12-12 17:11:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "543130607606587392",
  "text" : "\u0434\u043E \u043D\u0435\u0434\u0430\u0432\u043D\u0435\u0433\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u043D\u0435 \u0443\u0441\u0442\u0430\u0432\u0430\u043B \u043F\u043E\u0432\u0442\u043E\u0440\u044F\u0442\u044C, \u0447\u0442\u043E \u044F \u043D\u0435 \u0438\u043D\u0442\u0440\u043E\u0432\u0435\u0440\u0442, \u0430 \u043F\u0440\u043E\u0441\u0442\u043E \u043C\u0443\u0434\u0430\u043A \u0437\u0430\u0448\u0443\u0433\u0430\u043D\u043D\u044B\u0439",
  "id" : 543130607606587392,
  "created_at" : "2014-12-11 19:50:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541652574299226112",
  "text" : "\u0410\u0440\u0438\u0430\u0434\u043D\u0430 \u0410\u0440\u0435\u043D\u0434\u0442",
  "id" : 541652574299226112,
  "created_at" : "2014-12-07 17:56:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gameiversary",
      "screen_name" : "Gameiversary",
      "indices" : [ 3, 16 ],
      "id_str" : "2491898208",
      "id" : 2491898208
    }, {
      "name" : "id Software",
      "screen_name" : "idSoftware",
      "indices" : [ 78, 89 ],
      "id_str" : "76774950",
      "id" : 76774950
    }, {
      "name" : "John Carmack",
      "screen_name" : "ID_AA_Carmack",
      "indices" : [ 90, 104 ],
      "id_str" : "175624200",
      "id" : 175624200
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Gameiversary\/status\/539857805130231808\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/V8AVn5QhlF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B33rK8SCMAABpMq.jpg",
      "id_str" : "539846103567314944",
      "id" : 539846103567314944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B33rK8SCMAABpMq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/V8AVn5QhlF"
    } ],
    "hashtags" : [ {
      "text" : "Quake",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541322118311325696",
  "text" : "RT @Gameiversary: Today marks the 15th anniversary of Quake III Arena! #Quake @idSoftware @ID_AA_Carmack http:\/\/t.co\/V8AVn5QhlF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "id Software",
        "screen_name" : "idSoftware",
        "indices" : [ 60, 71 ],
        "id_str" : "76774950",
        "id" : 76774950
      }, {
        "name" : "John Carmack",
        "screen_name" : "ID_AA_Carmack",
        "indices" : [ 72, 86 ],
        "id_str" : "175624200",
        "id" : 175624200
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Gameiversary\/status\/539857805130231808\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/V8AVn5QhlF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B33rK8SCMAABpMq.jpg",
        "id_str" : "539846103567314944",
        "id" : 539846103567314944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B33rK8SCMAABpMq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/V8AVn5QhlF"
      } ],
      "hashtags" : [ {
        "text" : "Quake",
        "indices" : [ 53, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "539857805130231808",
    "text" : "Today marks the 15th anniversary of Quake III Arena! #Quake @idSoftware @ID_AA_Carmack http:\/\/t.co\/V8AVn5QhlF",
    "id" : 539857805130231808,
    "created_at" : "2014-12-02 19:05:05 +0000",
    "user" : {
      "name" : "Gameiversary",
      "screen_name" : "Gameiversary",
      "protected" : false,
      "id_str" : "2491898208",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/465953539638824960\/1ym2-NOS_normal.jpeg",
      "id" : 2491898208,
      "verified" : false
    }
  },
  "id" : 541322118311325696,
  "created_at" : "2014-12-06 20:03:44 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541043543054491649",
  "text" : "which is kinda derived from an insight that i like david cronenberg, but not even close to how much i adore teriyaki",
  "id" : 541043543054491649,
  "created_at" : "2014-12-06 01:36:47 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "541040620174057472",
  "text" : "in some scattering swirl dreaming about pornactress whos name is Tyranny Europe and a guy Teriyakiberg with somewhat called the Teriyakirama",
  "id" : 541040620174057472,
  "created_at" : "2014-12-06 01:25:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "digitaloctober",
      "indices" : [ 52, 67 ]
    }, {
      "text" : "GSEA2014",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "GSEA",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "DigitalOctober",
      "indices" : [ 84, 99 ]
    }, {
      "text" : "gsearu",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/pXunuDaZRx",
      "expanded_url" : "http:\/\/PM-Tech.ru",
      "display_url" : "PM-Tech.ru"
    } ]
  },
  "geo" : { },
  "id_str" : "540468248563957760",
  "text" : "http:\/\/t.co\/pXunuDaZRx \u0412\u0435\u0431-\u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u0438 Hardcore IT #digitaloctober #GSEA2014 #GSEA #DigitalOctober #gsearu",
  "id" : 540468248563957760,
  "created_at" : "2014-12-04 11:30:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "540246738091921408",
  "text" : "\u00AB\u0442\u0430\u043A \u043D\u0430 Christmas \u0437\u0435\u0440\u043D\u0430\u0445?\u00BB, \u044F \u0435\u0435 \u043D\u0435 \u0441\u043B\u044B\u0448\u0430\u043B. \u0437\u0430\u0441\u0442\u0440\u044F\u043B \u0432 \u0442\u0435\u043F\u043B\u044B\u0445 \u0433\u043B\u0430\u0437\u0430\u0445 \u0434\u0435\u0432\u0443\u0448\u043A\u0438 \u0437\u0430 \u043A\u0430\u0441\u0441\u043E\u0439. \u0437\u0430 \u0441\u0435\u043A\u0441\u0443\u0430\u043B\u044C\u043D\u0443\u044E \u0441\u043C\u0435\u0440\u0442\u044C \u044F \u0440\u0430\u0441\u043F\u043B\u0430\u0442\u0438\u043B\u0441\u044F \u043A\u0430\u0440\u0442\u043E\u0439 Mastercard",
  "id" : 540246738091921408,
  "created_at" : "2014-12-03 20:50:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539863981176135681",
  "text" : "\u0433\u0434\u0435 \u0432 \u043D\u0430\u0448\u0435 \u0432\u0440\u0435\u043C\u044F \u043D\u0430\u0439\u0442\u0438 \u0444\u0443\u0442\u0431\u043E\u043B\u043A\u0443 \u0431\u0435\u0437 \u041A\u0430\u0441\u0442\u0435\u043B\u0443\u0447\u0447\u0438 \u0438\u043B\u0438 \u043F\u043E\u0441\u0442-\u0434\u0440\u0430\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0442\u0435\u0430\u0442\u0440 \u0431\u0435\u0437 \u041F\u0443\u0442\u0438\u043D\u0430?",
  "id" : 539863981176135681,
  "created_at" : "2014-12-02 19:29:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "539863677365932033",
  "text" : "\u043E\u0442 \u0431\u0440\u044E\u043D\u0435\u0442\u043E\u043A \u043E\u0436\u0438\u0432\u0430\u044E\u0442 \u0431\u0443\u043C\u0430\u0436\u043D\u044B\u0435 \u0442\u0438\u0433\u0440\u044B angstneurose",
  "id" : 539863677365932033,
  "created_at" : "2014-12-02 19:28:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]