Grailbird.data.tweets_2016_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/t2vYCvHxfK",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=KvCmale1oDE&feature=share",
      "display_url" : "youtube.com\/watch?v=KvCmal\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "811285518164094982",
  "text" : "Dancing with Rabbi Yitzi Hurwitz https:\/\/t.co\/t2vYCvHxfK",
  "id" : 811285518164094982,
  "created_at" : "2016-12-20 19:01:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]