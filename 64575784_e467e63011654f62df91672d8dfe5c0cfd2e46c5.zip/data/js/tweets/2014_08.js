Grailbird.data.tweets_2014_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Web App\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501406702785536000",
  "text" : "\u041F\u043E\u043A\u0430 \u0437\u043B\u043E\u0431\u043D\u044B\u0439 \u043F\u0438\u0442\u0431\u0443\u043B\u044C \u0425\u0435\u0440\u0441\u0442 \u0441\u0438\u0434\u0438\u0442 \u0432 \u0442\u0435\u043C\u043D\u043E\u043C \u0434\u0432\u043E\u0440\u0446\u0435 \u0441\u0432\u043E\u0435\u0439 \u043D\u0435\u043D\u0430\u0432\u0438\u0441\u0442\u0438, \u00AB\u0417\u0430\u043A \u0413\u0430\u043B\u0438\u0444\u0430\u043D\u0430\u043A\u0438\u0441\u00BB \u0432\u043D\u043E\u0432\u044C \u0432\u043E\u0437\u043D\u0438\u043A\u0430\u0435\u0442 \u043A\u0430\u043A \u0438\u043C\u044F \u043F\u043E\u0434\u043B\u0438\u043D\u043D\u043E\u0439 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B",
  "id" : 501406702785536000,
  "created_at" : "2014-08-18 16:34:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/CzJC7Ugu8f",
      "expanded_url" : "https:\/\/www.dropbox.com\/s\/suo36c1815jyva5\/%D0%A1%D0%BA%D1%80%D0%B8%D0%BD%D1%88%D0%BE%D1%82%202014-08-14%2000.37.35.png",
      "display_url" : "dropbox.com\/s\/suo36c1815jy\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499658117312155649",
  "text" : "https:\/\/t.co\/CzJC7Ugu8f feel sorry for Gottfrid Warg and Peter Sunde. Every state is a concentration camp.",
  "id" : 499658117312155649,
  "created_at" : "2014-08-13 20:45:53 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495558238369484800",
  "text" : "\u0420\u0430\u0439\u043C\u043E\u043D \u0420\u0430\u0434\u0438\u0433\u0435 \u0443\u043C\u0435\u0440 \u0432 20 \u043B\u0435\u0442, \u0416\u0430\u043D \u0420\u0435\u043D\u0435 \u042E\u0433\u043D\u0435\u043D - \u0432 26. For whom the bell tolls",
  "id" : 495558238369484800,
  "created_at" : "2014-08-02 13:14:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]