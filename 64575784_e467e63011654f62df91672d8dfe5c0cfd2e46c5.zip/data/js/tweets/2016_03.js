Grailbird.data.tweets_2016_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/NPLWidv9Qo",
      "expanded_url" : "http:\/\/www.litres.ru\/simon-libertin\/prototype466",
      "display_url" : "litres.ru\/simon-libertin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "715425937794408448",
  "text" : "\u0421\u0438\u043C\u043E\u043D \u041B\u0438\u0431\u0435\u0440\u0442\u0438\u043D \"Prototype466. \u0420\u043E\u043C\u0430\u043D \u043E \u0441\u043E\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E\u043C \u0438\u0441\u043A\u0443\u0441\u0441\u0442\u0432\u0435\", \u0441\u043A\u0430\u0447\u0430\u0442\u044C epub, pdf. https:\/\/t.co\/NPLWidv9Qo",
  "id" : 715425937794408448,
  "created_at" : "2016-03-31 06:30:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "714079391035338752",
  "text" : "Lil Wayne \/\/",
  "id" : 714079391035338752,
  "created_at" : "2016-03-27 13:19:28 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711915050001440768",
  "text" : "John Coltrane",
  "id" : 711915050001440768,
  "created_at" : "2016-03-21 13:59:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "711611512180310016",
  "text" : "PJ Harvey",
  "id" : 711611512180310016,
  "created_at" : "2016-03-20 17:53:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "709542491993804801",
  "text" : "\u2026\u0435\u0441\u043B\u0438 \u043D\u0435\u0441\u043F\u0440\u0430\u0432\u0435\u0434\u043B\u0438\u0432\u043E\u0441\u0442\u044C \u043D\u0435 \u0437\u0430\u043C\u043E\u0440\u0430\u0447\u0438\u0432\u0430\u0435\u0442\u0441\u044F \u043C\u0430\u0442\u0440\u0438\u0446\u0435\u0439 \u043A\u0430\u043F\u0438\u0442\u0430\u043B\u0430 \u0432\u043E\u043E\u0431\u0449\u0435, \u0442\u043E \u0437\u0430\u0447\u0435\u043C \u0440\u0430\u0441\u043F\u0438\u043D\u0430\u0442\u044C\u0441\u044F \u043F\u0435\u0440\u0435\u0434 \u0442\u0432\u043E\u0435\u0439 \u0438\u043B\u043B\u044E\u0437\u0438\u0435\u0439 - \u0432 \u0447\u0430\u0441\u0442\u043D\u043E\u0441\u0442\u0438\u2026",
  "id" : 709542491993804801,
  "created_at" : "2016-03-15 00:51:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "705398360572764160",
  "text" : "\u0417\u0430 \u0431\u043E\u0440\u0442\u043E\u043C \u043F\u043E\u0434 valse indiff\u00E9rence \u041C\u0443\u0440\u0435\u043D\u044B \u0432\u0437\u043B\u0435\u0442\u0430\u043B\u0438 \u0410\u043F\u0435\u043D\u043D\u0438\u043D\u044B \u0438\u0437 \u0441\u0442\u0438\u0445\u043E\u0432 \u0434\u043E\u0447\u0435\u0440\u0438. \u0413\u0435\u0432\u044E\u0440\u0446\u0442\u0440\u0430\u043C\u0438\u043D\u0435\u0440 \u0434\u043B\u044F \u041A\u0430\u043D\u0434\u0438,\u0447\u0438\u043A\u0435\u043D \u0444\u043B\u043E\u0440\u0435\u043D\u0442\u0438\u043D\u0430 \u0434\u043B\u044F \u041D\u0438\u043A\u043E\u043B\u044C, \u043F\u043E\u0432\u0442\u043E\u0440\u0438\u043B \u044F",
  "id" : 705398360572764160,
  "created_at" : "2016-03-03 14:24:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]