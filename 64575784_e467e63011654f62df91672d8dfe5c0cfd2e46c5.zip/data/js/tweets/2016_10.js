Grailbird.data.tweets_2016_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/ogzLTVHWeR",
      "expanded_url" : "https:\/\/youtu.be\/EyMjb83A1GQ",
      "display_url" : "youtu.be\/EyMjb83A1GQ"
    } ]
  },
  "geo" : { },
  "id_str" : "789058744269344768",
  "text" : "\u0421\u043C\u0435\u0445 - \u043F\u0440\u043E\u0434\u043B\u0435\u0432\u0430\u0435\u0442 \u0433\u043E\u0434\u044B. https:\/\/t.co\/ogzLTVHWeR \u041A\u0430\u043B\u0435\u043D\u043A\u043E\u0432\u0438\u0447 \u043F\u0440\u043E \u043E\u043F\u0442\u0438\u043C\u0430\u043B\u044C\u043D\u044B\u0435 \u0440\u0438\u0441\u043A\u0438 \u0432 \u0442\u0440\u0435\u0439\u0434\u0438\u043D\u0433\u0435. 4 \u0433\u043E\u0434\u0430 \u0441\u043F\u0443\u0441\u0442\u044F",
  "id" : 789058744269344768,
  "created_at" : "2016-10-20 11:00:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "787987961900040192",
  "text" : "Kelley Polar",
  "id" : 787987961900040192,
  "created_at" : "2016-10-17 12:05:44 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "783022160503836672",
  "text" : "\u05D4\u05DB\u05DC \u05D9\u05D4\u05D9\u05D4 \u05D1\u05E1\u05D3\u05E8\n\u05D5\u05E9\u05E7\u05D3 \u05E4\u05E8\u05D7\u05D9\n\u05DC\u05E8\u05D0\u05E9!",
  "id" : 783022160503836672,
  "created_at" : "2016-10-03 19:13:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]