Grailbird.data.tweets_2011_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0645\u0628\u0627\u0631\u0643",
      "screen_name" : "tuta_m",
      "indices" : [ 0, 7 ],
      "id_str" : "714041724",
      "id" : 714041724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108930318010040320",
  "text" : "@tuta_m \u043F\u043E\u043B\u0438\u0442\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0444\u0440\u0438\u043A, wut? \u0445\u043E\u0442\u044F \u0443 \u043C\u0435\u043D\u044F \u043D\u0430 \u043A\u0443\u0440\u0441\u0435 \u043E\u0434\u0438\u043D \u0431\u044B\u043B \u043C\u0431",
  "id" : 108930318010040320,
  "created_at" : "2011-08-31 15:53:06 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108587163519692800",
  "text" : "\u0430 \u0446\u0435\u043B\u044C \u043A \u043E\u043A\u0442\u044F\u0431\u0440\u044E - \u0432\u0441\u0435 \u0431\u0440\u043E\u0441\u0438\u0442\u044C \u0438 \u043D\u0430\u0447\u0430\u0442\u044C \u0436\u0438\u0442\u044C \u0441 \u043D\u0435\u0440\u0434\u0430\u043C\u0438 \u0432 \u0442\u0440\u0435\u0439\u0434\u0440\u0443\u043C\u0435 :I",
  "id" : 108587163519692800,
  "created_at" : "2011-08-30 17:09:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "108582586665811968",
  "text" : "Wut, \u043D\u0435\u0441\u043C\u043E\u0442\u0440\u044F \u043D\u0430 facepalmus aeterni, \u0440\u0430\u0431\u043E\u0442\u0443 \u0432 \u043C\u0438\u043D\u044D\u043A\u043E\u043D\u043E\u043C\u0435 \u0441 9-19, \u0430 \u0442\u0430\u043A\u0436\u0435 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0443 \u0444\u0438\u0442\u043D\u0435\u0441\u0430 \u0432\u043C\u0435\u0441\u0442\u0435 \u0441 \u0434\u0436\u043E\u0431\u0441\u043E\u043C, \u0432\u0441\u0435 \u0432\u0440\u0435\u043C\u044F - like thunderstruck",
  "id" : 108582586665811968,
  "created_at" : "2011-08-30 16:51:20 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/rJftVY1",
      "expanded_url" : "http:\/\/smart-lab.ru\/blog\/14878.php",
      "display_url" : "smart-lab.ru\/blog\/14878.php"
    }, {
      "indices" : [ 22, 41 ],
      "url" : "http:\/\/t.co\/LjlIcG4",
      "expanded_url" : "http:\/\/en.m.wikipedia.org\/wiki\/Special:Search?search=Duck+duck+goose",
      "display_url" : "en.m.wikipedia.org\/wiki\/Special:S\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "108176767189127168",
  "text" : "http:\/\/t.co\/rJftVY1 = http:\/\/t.co\/LjlIcG4 :)",
  "id" : 108176767189127168,
  "created_at" : "2011-08-29 13:58:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "107855717754605568",
  "text" : "When grope blindly along fRts which the temper you cannot too highly honor",
  "id" : 107855717754605568,
  "created_at" : "2011-08-28 16:43:01 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101584976834854913",
  "text" : "... so a daring man proclaimed \"Well, here goes nothing!\" And nothing happened.",
  "id" : 101584976834854913,
  "created_at" : "2011-08-11 09:25:20 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "101583375189544961",
  "text" : "Nada dollars and dick for cents",
  "id" : 101583375189544961,
  "created_at" : "2011-08-11 09:18:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "100890237223452672",
  "text" : "\u0418\u043D\u0434\u0435\u043A\u0441 \u041C\u041C\u0412\u0411 \u043D\u0430 \u0432\u043D\u0435\u0448\u043D\u0435\u043C \u043D\u0435\u0433\u0430\u0442\u0438\u0432\u043D\u043E\u043C \u0444\u043E\u043D\u0435 \u0448\u0430\u0442\u043D\u0443\u043B\u0441\u044F \u0432 \u043F\u0440\u0435\u0434\u0435\u043B\u0430\u0445 \u043D\u0435\u0434\u0435\u043B\u044C\u043D\u043E\u0439 \u043D\u043E\u0440\u043C\u044B, \u0430 \u0437\u043D\u0430\u0447\u0438\u0442 - \u0432\u0435\u0447\u0435\u0440 \u044F \u043F\u0440\u043E\u0432\u0435\u0434\u0443 \u0437\u0430 \u0433\u0440\u0430\u0444\u0438\u043A\u0430\u043C\u0438 \u0438 \u0441\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u0438\u0435\u043C \u043F\u043E\u0440\u0442\u0444\u0435\u043B\u044F.",
  "id" : 100890237223452672,
  "created_at" : "2011-08-09 11:24:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "99028495962869760",
  "text" : "\u0420\u0432\u044B \u0438 \u043D\u0435\u0440\u0432\u044B \u041C\u0438\u043D\u0435\u0440\u0432\u044B",
  "id" : 99028495962869760,
  "created_at" : "2011-08-04 08:06:47 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "98853774361235457",
  "text" : "Here again the testimony corroborates - \u043D\u0430\u043A\u0438\u0434\u0430\u043B\u0441\u044F \u0438 \u043F\u0438\u0448\u0443 \u0432 \u0442\u0432\u0438\u0442\u0442\u0435\u0440",
  "id" : 98853774361235457,
  "created_at" : "2011-08-03 20:32:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]