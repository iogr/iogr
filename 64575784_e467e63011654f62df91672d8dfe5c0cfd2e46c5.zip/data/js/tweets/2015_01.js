Grailbird.data.tweets_2015_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Louise Hines",
      "screen_name" : "louisehines1992",
      "indices" : [ 0, 16 ],
      "id_str" : "2853272775",
      "id" : 2853272775
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "559735389292748801",
  "geo" : { },
  "id_str" : "559874273339514882",
  "in_reply_to_user_id" : 2853272775,
  "text" : "@louisehines1992 \u043F\u0440\u0435\u0441\u0442\u0430\u0440\u0435\u043B\u044B\u043C \u0437\u0430\u0439\u0446\u0435\u043C \u044F \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u0443\u044E\u0441\u044C",
  "id" : 559874273339514882,
  "in_reply_to_status_id" : 559735389292748801,
  "created_at" : "2015-01-27 00:43:23 +0000",
  "in_reply_to_screen_name" : "louisehines1992",
  "in_reply_to_user_id_str" : "2853272775",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "559874008272076800",
  "text" : "For whom the balls tolls",
  "id" : 559874008272076800,
  "created_at" : "2015-01-27 00:42:20 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556549074045140992",
  "text" : "\u0421\u0440\u0430\u0437\u0443 \u043F\u043E\u0441\u043B\u0435 \u043F\u0435\u0440\u0432\u044B\u0445 \u0441\u043B\u043E\u0432 \u044F \u0440\u0430\u0437\u0440\u0435\u0437\u0430\u043B \u043A\u043D\u0438\u0433\u0438 \u041A\u0430\u0440\u043B\u0430 \u0428\u043C\u0438\u0442\u0442\u0430 \u043A\u0443\u0445\u043E\u043D\u043D\u044B\u043C\u0438 \u043D\u043E\u0436\u043D\u0438\u0446\u0430\u043C\u0438 \u0434\u043B\u044F \u043A\u0443\u0440\u0438\u0446\u044B \u0438 \u043F\u043E \u0447\u0430\u0441\u0442\u044F\u043C \u0441\u043C\u044B\u0432\u0430\u043B \u0438\u0445 \u0432 \u0443\u043D\u0438\u0442\u0430\u0437,\u0437\u0430\u0442\u0435\u043C \u0432\u044B\u0431\u0440\u0430\u0441\u044B\u0432\u0430\u043B \u043D\u043E\u0436\u043D\u0438\u0446\u044B",
  "id" : 556549074045140992,
  "created_at" : "2015-01-17 20:30:14 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556518877971361792",
  "text" : "\u0432\u0441\u0435\u0433\u043E-\u0442\u043E \u0438 \u043C\u043E\u0433\u0443\u0442, \u0447\u0442\u043E \u043D\u0430\u043F\u0443\u0441\u0442\u0438\u0442\u044C \u043D\u0430 \u0441\u0435\u0431\u044F \u043F\u0435\u0447\u0430\u043B\u044C\u043D\u044B\u0439 \u0432\u0438\u0434. \u041D\u0430 \u0441\u0430\u043C\u043E\u043C \u0434\u0435\u043B\u0435, \u0432\u0441\u0435 \u044D\u0442\u0438 \u0447\u0435\u043B\u043E\u0432\u0435\u0447\u0435\u0441\u043A\u0438\u0435 \u0432\u0437\u0430\u0438\u043C\u043E\u043E\u0442\u043D\u043E\u0448\u0435\u043D\u0438\u044F - \u043F\u043E\u043B\u043D\u0430\u044F \u0447\u0443\u0448\u044C",
  "id" : 556518877971361792,
  "created_at" : "2015-01-17 18:30:14 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556518481282478080",
  "text" : "\u0412\u0441\u0435\u0433\u0434\u0430 \u0432 \u0441\u0432\u043E\u0435\u0439 \u0436\u0438\u0437\u043D\u0438 \u044F \u0432\u044B\u0441\u043A\u0430\u0437\u044B\u0432\u0430\u043B \u0434\u0440\u0443\u0433\u0438\u043C \u043C\u0435\u043D\u044C\u0448\u0435, \u0447\u0435\u043C \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u0447\u0443\u0432\u0441\u0442\u0432\u043E\u0432\u0430\u043B, \u043F\u043E\u0442\u043E\u043C\u0443 \u0447\u0442\u043E \u043F\u0435\u0440\u0435\u0434 \u043D\u0430\u0441\u0442\u043E\u044F\u0449\u0435\u0439 \u043E\u0442\u043A\u0440\u043E\u0432\u0435\u043D\u043D\u043E\u0441\u0442\u044C\u044E \u043B\u044E\u0434\u0438",
  "id" : 556518481282478080,
  "created_at" : "2015-01-17 18:28:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/IzAqY2MxuX",
      "expanded_url" : "http:\/\/fake-friends.com",
      "display_url" : "fake-friends.com"
    } ]
  },
  "geo" : { },
  "id_str" : "556517979710844929",
  "text" : "http:\/\/t.co\/IzAqY2MxuX \u0432\u0442\u043E\u0440\u043E\u0439 \u043F\u043E \u043A\u0440\u0443\u0442\u043E\u0441\u0442\u0438 \u043B\u0430\u0439\u0444\u0445\u0430\u043A \u0441\u0440\u0430\u0437\u0443 \u043F\u043E\u0441\u043B\u0435 \u0441\u0435\u043A\u0441\u0430 \u0437\u0430 \u0434\u0435\u043D\u044C\u0433\u0438",
  "id" : 556517979710844929,
  "created_at" : "2015-01-17 18:26:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "556166009003208704",
  "text" : "weekend playlist: Tan Dun &amp; Wu-tang",
  "id" : 556166009003208704,
  "created_at" : "2015-01-16 19:08:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "554560950804561921",
  "text" : "je suis PJ Harvey, elle est un joyau",
  "id" : 554560950804561921,
  "created_at" : "2015-01-12 08:50:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553273272369156096",
  "text" : "\u041E\u0431\u044B\u0447\u043D\u044B\u0439 \u0434\u0435\u043D\u044C, \u0432 \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u044F \u043D\u0430\u043A\u0443\u0440\u0438\u043B\u0441\u044F \u0438 \u043F\u043E\u0434 \u0437\u0430\u0432\u044F\u0437\u043A\u0443 \u043D\u0430\u043A\u0438\u0434\u0430\u043B\u0441\u044F \u0433\u043B\u0438\u043D\u0442\u0432\u0435\u0439\u043D\u0430, \u043F\u0440\u043E\u0441\u043B\u0443\u0448\u0438\u0432\u0430\u044F \u0430\u0443\u0434\u0438\u043E-\u0432\u0435\u0440\u0441\u0438\u044E \u00AB\u041F\u0443\u0442\u0435\u0448\u0435\u0441\u0442\u0432\u0438\u044F \u043D\u0430 \u043A\u0440\u0430\u0439 \u043D\u043E\u0447\u0438\u00BB \u0421\u0435\u043B\u0438\u043D\u0430",
  "id" : 553273272369156096,
  "created_at" : "2015-01-08 19:33:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "553271674251264000",
  "text" : "\u043B\u0430\u0434\u043D\u043E, \u043F\u0440\u0438\u0434\u0435\u0442\u0441\u044F \u0434\u043E\u0443\u0447\u0438\u0442\u044C \u0444\u0440\u0430\u043D\u0446\u0443\u0437\u0441\u043A\u0438\u0439, \u0447\u0442\u043E\u0431\u044B \u0447\u0438\u0442\u0430\u0442\u044C \u0413\u043B\u044E\u043A\u0441\u043C\u0430\u043D\u043D\u0430",
  "id" : 553271674251264000,
  "created_at" : "2015-01-08 19:27:01 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]