Grailbird.data.tweets_2013_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/MintYsUW",
      "expanded_url" : "http:\/\/www.ambal.ru\/52889597555.jpg",
      "display_url" : "ambal.ru\/52889597555.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "290041519577112576",
  "text" : "http:\/\/t.co\/MintYsUW",
  "id" : 290041519577112576,
  "created_at" : "2013-01-12 10:24:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]