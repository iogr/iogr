Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 72 ],
      "url" : "http:\/\/t.co\/l5XtE5v",
      "expanded_url" : "http:\/\/vimeo.com\/25401444",
      "display_url" : "vimeo.com\/25401444"
    } ]
  },
  "geo" : { },
  "id_str" : "85463744976654336",
  "text" : "Watch Markus Kayser - Solar Sinter Project on Vimeo! http:\/\/t.co\/l5XtE5v",
  "id" : 85463744976654336,
  "created_at" : "2011-06-27 21:45:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85430382467624960",
  "text" : "\u0412 \u0436\u0438\u0437\u043D\u0438 \u0441\u0442\u0430\u043B\u043E \u043E\u0447\u0435\u043D\u044C \u043C\u0430\u043B\u043E \u043C\u0443\u0437\u044B\u043A\u0438, \u043D\u043E \u0441\u0435\u0433\u043E\u0434\u043D\u044F \u0432\u0435\u0447\u0435\u0440\u043E\u043C \u044F \u043E\u0442\u043A\u0440\u044B\u043B \u0434\u043B\u044F \u0441\u0435\u0431\u044F Black Wreath \u0441 \u0430\u043B\u044C\u0431\u043E\u043C\u043E\u043C A Pyre Of Lost Dreams. \u0443\u043F\u043E\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439 doom metal",
  "id" : 85430382467624960,
  "created_at" : "2011-06-27 19:32:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84639732432244736",
  "text" : "\u041E\u0437\u043D\u0430\u043A\u043E\u043C\u0438\u043B\u0441\u044F \u0441 Qquik - \u0441\u043A\u0430\u043B\u044C\u043F\u0435\u0440\u0441\u043A\u0438\u043C \u043F\u0440\u0438\u0432\u043E\u0434\u043E\u043C \u0434\u043B\u044F \u043A\u0432\u0438\u043A\u0430, \u043F\u043E\u043B\u0435\u0437\u043D\u044B\u0439, \u043D\u043E \u043D\u0435\u043F\u043E\u043D\u044F\u0442\u043D\u043E, \u0431\u044B\u043B\u0438 \u043B\u0438 \u0432\u0435\u0440\u0441\u0438\u0438 \u043F\u043E\u0441\u043B\u0435 \u0438\u0437\u043C \u0440\u0430\u0437\u043C\u0435\u0440\u0430 \u043B\u043E\u0442\u0430 \u043D\u0430 \u043C\u043C\u0432\u0431.",
  "id" : 84639732432244736,
  "created_at" : "2011-06-25 15:10:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http:\/\/t.co\/MqMHKST",
      "expanded_url" : "http:\/\/bit.ly\/kOivXS",
      "display_url" : "bit.ly\/kOivXS"
    } ]
  },
  "geo" : { },
  "id_str" : "84407807054577664",
  "text" : "- \u043D\u044B\u043D\u0435 \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u043F\u0430\u0440\u0430\u043B\u0438\u0437\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u043F\u0441\u0438\u0445-\u0437\u0430\u0434\u0440\u043E\u0442, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u0443\u0436\u0435 \u0432 17 \u043B\u0435\u0442 \u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u043B \u042D\u0422\u041E http:\/\/t.co\/MqMHKST \u0431\u0435\u0441\u0441\u043C\u044B\u0441\u043B\u0435\u043D\u043D\u043E \u043F\u044B\u0442\u0430\u0442\u044C\u0441\u044F \u0432\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u0435\u0441\u0442\u0438 )",
  "id" : 84407807054577664,
  "created_at" : "2011-06-24 23:49:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84407337581944832",
  "text" : "\u0432\u0441\u0435 \u043F\u043E\u0442\u043E\u043C\u0443, \u0447\u0442\u043E \u0443 oz \u043D\u0430 \u0431\u044D\u043A\u0440\u0433\u0430\u0443\u043D\u0434\u0435 \u043E\u043D \u0441\u0430\u043C, \u0430 \u0443 atangela Jason Becker",
  "id" : 84407337581944832,
  "created_at" : "2011-06-24 23:47:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 127 ],
      "url" : "http:\/\/t.co\/xHPRepm",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/atangela#p\/u\/4\/XSzTWEM8-tw",
      "display_url" : "youtube.com\/user\/atangela#\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "84404036018778112",
  "text" : "\u0430 \u044F\u043F\u043E\u043D\u0435\u0446 atangela \u0432\u043E\u0442 \u0443\u0436\u0435 \u043C\u043D\u043E\u0433\u043E \u043B\u0435\u0442 \u043E\u0447 \u0447\u0438\u0441\u0442\u043E \u0438 \u0441 \u0447\u0443\u0432\u0441\u0442\u0432\u043E\u043C \u0440\u0430\u0437\u044B\u0433\u0440\u044B\u0432\u0430\u0435\u0442 \u043E\u0434\u043D\u0443 \u0437\u0430 \u0434\u0440\u0443\u0433\u043E\u0439 \u043A\u043E\u043C\u043F\u043E\u0437\u0438\u0446\u0438\u0438 \u043C\u0430\u043B\u043C\u0441\u0442\u0438\u043D\u0430 - http:\/\/t.co\/xHPRepm",
  "id" : 84404036018778112,
  "created_at" : "2011-06-24 23:34:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 33 ],
      "url" : "http:\/\/t.co\/S6XP7x5",
      "expanded_url" : "http:\/\/www.youtube.com\/user\/ozielzinhofficial#p\/u\/21\/wJlJLn5HZxo",
      "display_url" : "youtube.com\/user\/ozielzinh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "84402838515617793",
  "text" : "Oziel Zinho - http:\/\/t.co\/S6XP7x5 \u0438\u0433\u0440\u0430\u0435\u0442 \u0438\u0441\u043A\u043B\u044E\u0447\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043D\u0430 \u043A\u0430\u0441\u0442\u043E\u043C \u0437\u0432\u0443\u0447\u043A\u0430\u0445 \u0438 \u0433\u0438\u0442\u0430\u0440\u0430\u0445 \u0441\u043E \u0441\u0442\u0440\u0430\u043D\u043D\u044B\u043C \u0441\u0443\u0441\u0442\u0435\u0439\u043D\u043E\u043C",
  "id" : 84402838515617793,
  "created_at" : "2011-06-24 23:29:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84402108262133760",
  "text" : "\u041A\u043E\u0433\u0434\u0430-\u0442\u043E \u0432\u0441\u0442\u0440\u0435\u0442\u0438\u043B \u043D\u0430 youtube \u0434\u0432\u0443\u0445 \u043D\u0438\u043A\u043E\u043C\u0443 \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u044B\u0445, \u043D\u043E \u043A\u043B\u0430\u0441\u0441\u043D\u044B\u0445 \u0433\u0438\u0442\u0430\u0440\u0438\u0441\u0442\u0430. \u043F\u0440\u043E\u0448\u043B\u043E \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043B\u0435\u0442, \u043E\u0434\u0438\u043D \u043F\u0430\u0440\u0435\u043D\u044C \u0441\u0442\u0430\u043B \u0438\u0437\u0432\u0435\u0441\u0442\u0435\u043D, \u0430 \u0434\u0440\u0443\u0433\u043E\u0439 - \u043D\u0435\u0442",
  "id" : 84402108262133760,
  "created_at" : "2011-06-24 23:26:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84214345852141568",
  "text" : "\u041F\u043E\u0434\u043E\u0437\u0440\u0435\u0432\u0430\u044E, \u0447\u0442\u043E \u043F\u043E\u0440\u0430 \u0432\u043D\u043E\u0441\u0438\u0442\u044C \u0432 todo \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u0435 \u0430\u0442\u0442\u0435\u0441\u0442\u0430\u0442\u0430 \u0424\u0421\u0424\u0420, \u0445\u043E\u0442\u044F \u0431\u044B \u043F\u0435\u0440\u0432\u043E\u0439 \u0441\u0435\u0440\u0438\u0438",
  "id" : 84214345852141568,
  "created_at" : "2011-06-24 11:00:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84211743680761856",
  "text" : "\u0422\u043E\u043B\u044C\u043A\u043E \u043D\u0435\u0434\u0435\u043B\u044E \u043D\u0430\u0437\u0430\u0434 \u0432\u0435\u0440\u043D\u0443\u043B\u0438 \u0437\u0430\u043D\u044F\u0442\u044B\u0435 \u043D\u0430 \u0434\u0432\u0430 \u043C\u0435\u0441\u044F\u0446\u0430 $3k, \u043A\u0430\u043A \u0432\u0447\u0435\u0440\u0430 \u0434\u0443\u0440\u043E\u0432 \u043F\u0440\u0438\u0441\u043B\u0430\u043B \u043F\u0435\u0440\u0432\u044B\u0439 \u0441\u043A\u0440\u043E\u043C\u043D\u044B\u0439 \u0437\u0430\u043A\u0430\u0437 \u043D\u0430 21 k. \u0413\u0434\u0435 \u0431\u0440\u0430\u0442\u044C \u0434\u0435\u043D\u044C\u0433\u0438? :\\",
  "id" : 84211743680761856,
  "created_at" : "2011-06-24 10:50:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84210445715636224",
  "text" : "\u0423\u0442\u0440\u043E\u043C \u043F\u043E\u043B\u0443\u0447\u0438\u043B \u043F\u043E\u0441\u044B\u043B\u043A\u0443 \u0441 \u043D\u043E\u0432\u044B\u043C \u043B\u0443\u043A\u043E\u043C.",
  "id" : 84210445715636224,
  "created_at" : "2011-06-24 10:45:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "84209430002020353",
  "text" : "\u0418\u0424\u041A \u041C\u0435\u0442\u0440\u043E\u043F\u043E\u043B\u044C = kinda wow! \u0416\u0430\u043B\u044C, \u0447\u0442\u043E \u0420\u0443\u0431\u0435\u043D\u0448\u0442\u0435\u0439\u043D\u0430 \u043D\u0435 \u0432\u0441\u0442\u0440\u0435\u0442\u0438\u043B )",
  "id" : 84209430002020353,
  "created_at" : "2011-06-24 10:41:07 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83872885676056576",
  "text" : "\u041C\u043E\u0438 \u043F\u0440\u0430 \u0431\u044B\u043B\u0438 \u0445\u0430\u0441\u0438\u0434\u0430\u043C\u0438, \u0430 \u044F \u043A\u0440\u043E\u043C\u0435 \u0448\u043C\u0430 \u0438 \u0447\u0430\u0441\u0442\u0438 \u05DB\u05DC \u05E0\u05D3\u05E8\u05D9 \u0441 \u0443\u0441\u0442 \u0431\u0430\u0431\u0443\u0448\u043A\u0438 \u0431\u043E\u043B\u044C\u0448\u0435 \u043F\u043E\u0447\u0442\u0438 \u043D\u0438\u0447\u0435\u0433\u043E \u043D\u0435 \u0437\u043D\u0430\u044E )",
  "id" : 83872885676056576,
  "created_at" : "2011-06-23 12:23:48 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anton Nossik",
      "screen_name" : "dolboed",
      "indices" : [ 3, 11 ],
      "id_str" : "5526282",
      "id" : 5526282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83870295961776128",
  "text" : "RT @dolboed: \u041F\u0440\u043E\u0444. \u0421\u0442\u0438\u0432\u0435\u043D \u041A\u043E\u044D\u043D: \u043F\u043E\u043B\u043E\u0432\u0438\u043D\u0430 \u0430\u043C\u0435\u0440\u0438\u043A\u0430\u043D\u0441\u043A\u0438\u0445 \u0435\u0432\u0440\u0435\u0435\u0432 \u0432\u0441\u0442\u0443\u043F\u0430\u0435\u0442 \u0432 \u0441\u043C\u0435\u0448\u0430\u043D\u043D\u044B\u0435 \u0431\u0440\u0430\u043A\u0438. \u0418\u0437 \u0432\u043D\u0443\u043A\u043E\u0432 \u0435\u0432\u0440\u0435\u0435\u043C \u0431\u0443\u0434\u0435\u0442 \u043E\u0449\u0443\u0449\u0430\u0442\u044C \u0441\u0435\u0431\u044F \u043A\u0430\u0436\u0434\u044B\u0439 10\u0439",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 31.7868572875, 35.2024452325 ]
    },
    "id_str" : "83865398835019776",
    "text" : "\u041F\u0440\u043E\u0444. \u0421\u0442\u0438\u0432\u0435\u043D \u041A\u043E\u044D\u043D: \u043F\u043E\u043B\u043E\u0432\u0438\u043D\u0430 \u0430\u043C\u0435\u0440\u0438\u043A\u0430\u043D\u0441\u043A\u0438\u0445 \u0435\u0432\u0440\u0435\u0435\u0432 \u0432\u0441\u0442\u0443\u043F\u0430\u0435\u0442 \u0432 \u0441\u043C\u0435\u0448\u0430\u043D\u043D\u044B\u0435 \u0431\u0440\u0430\u043A\u0438. \u0418\u0437 \u0432\u043D\u0443\u043A\u043E\u0432 \u0435\u0432\u0440\u0435\u0435\u043C \u0431\u0443\u0434\u0435\u0442 \u043E\u0449\u0443\u0449\u0430\u0442\u044C \u0441\u0435\u0431\u044F \u043A\u0430\u0436\u0434\u044B\u0439 10\u0439",
    "id" : 83865398835019776,
    "created_at" : "2011-06-23 11:54:03 +0000",
    "user" : {
      "name" : "Anton Nossik",
      "screen_name" : "dolboed",
      "protected" : false,
      "id_str" : "5526282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479230324438994945\/k5o-GOI6_normal.jpeg",
      "id" : 5526282,
      "verified" : false
    }
  },
  "id" : 83870295961776128,
  "created_at" : "2011-06-23 12:13:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83399255536058368",
  "text" : "ok, ashes to ashes, fun to funky, \u043A\u0430\u043A \u0433\u043E\u0432\u043E\u0440\u044F\u0442 \u0445\u0430\u0441\u0438\u0434\u044B. \u043F\u043E\u0435\u0445\u0430\u043B \u043E\u0431\u0441\u0443\u0436\u0434\u0430\u0442\u044C \u0430\u043F\u0442\u0435\u043A\u0443 \u043A \u0433\u043B\u0430\u0432\u043D\u043E\u043C\u0443 \u043C\u043E\u0441\u043A\u043E\u0432\u0441\u043A\u043E\u043C\u0443 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0443 \u0441\u043F\u043E\u0440\u0442\u043F\u0438\u0442\u0430.",
  "id" : 83399255536058368,
  "created_at" : "2011-06-22 05:01:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83397027861508097",
  "text" : "\u041F\u043B\u0430\u043C\u044F \u0443\u0433\u0430\u0440\u0430 \u0437\u0430\u0431\u0440\u0430\u043B\u043E \u043B\u044E\u0434\u0435\u0439, \u0432\u0440\u0435\u043C\u0435\u043D\u0430 \u043D\u0435 \u0432\u0435\u0440\u043D\u0443\u0442\u044C, \u0438 \u0441 \u042E\u043B\u0435\u0439 \u0442\u0435\u043F\u0435\u0440\u044C \u0443\u0436\u0435 \u043D\u0438\u043A\u043E\u0433\u0434\u0430 \u043D\u0435 \u0432\u0441\u0442\u0440\u0435\u0447\u0443\u0441\u044C. \u0445\u043E\u0442\u044F \u043D\u0430\u043A\u0430\u0442\u0438\u0442\u044C \u0438 \u043E\u0431 \u043E\u0431\u043E\u0434 \u043F\u043E\u0441\u0442\u0443\u0447\u0430\u0442\u044C \u0432\u0441\u0435\u0433\u0434\u0430 \u043C\u043E\u0436\u043D\u043E )",
  "id" : 83397027861508097,
  "created_at" : "2011-06-22 04:52:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 117 ],
      "url" : "http:\/\/t.co\/V3QGu0b",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=tD5i5laNH9M",
      "display_url" : "youtube.com\/watch?v=tD5i5l\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "83395254513958912",
  "text" : "\u041C\u0430\u043A\u044C\u044E\u044D\u043D \u043F\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u043E\u0432\u0430\u043B - \u0443\u0442\u0440\u043E\u043C \u043D\u0430\u0445\u043B\u044B\u043D\u0443\u043B\u0430 \u0442\u043E\u0441\u043A\u0430. \u0437\u0430\u0442\u043E, \u044D\u0442\u043E \u0441\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u0441\u0432\u043E\u0435\u0433\u043E, \u043A\u0440\u043E\u0432\u043D\u043E\u0433\u043E \u043F\u043E\u0440\u0430\u0436\u0435\u043D\u0438\u044F. http:\/\/t.co\/V3QGu0b",
  "id" : 83395254513958912,
  "created_at" : "2011-06-22 04:45:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/tM4KT6L",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=vpCjSJVxTFU",
      "display_url" : "youtube.com\/watch?v=vpCjSJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "82919570586861568",
  "text" : "http:\/\/t.co\/tM4KT6L \u0438\u043D\u0442\u0435\u0440\u0432\u044C\u044E team russia \u0441 dh2011 - jibo, cooller, evil, mikess. \u043A\u0430\u0436\u0434\u044B\u0439 \u0438\u0433\u0440\u0430\u0435\u0442 \u0432 quake \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 vq3 \u0444\u0438\u0437\u0438\u043A\u0435 \u0431\u043E\u043B\u044C\u0448\u0435 10 \u043B\u0435\u0442 )",
  "id" : 82919570586861568,
  "created_at" : "2011-06-20 21:15:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 95 ],
      "url" : "http:\/\/t.co\/2tONVmg",
      "expanded_url" : "http:\/\/www.dejurka.ru\/wp-content\/uploads\/2008\/05\/clip-image0148.jpg",
      "display_url" : "dejurka.ru\/wp-content\/upl\u2026"
    }, {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/S738tFa",
      "expanded_url" : "http:\/\/fc04.deviantart.net\/fs71\/f\/2011\/038\/4\/f\/st_johns_worth_pixel_by_aropeofsand-d390g23.png",
      "display_url" : "fc04.deviantart.net\/fs71\/f\/2011\/03\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81813329785528320",
  "text" : "\u043F\u043E\u0441\u043A\u043E\u043B\u044C\u043A\u0443 \u044F \u0432\u044B\u0440\u043E\u0441 \u043D\u0430 Zak McKracken, \u0442\u043E \u043F\u0440\u043E\u0441\u0442\u043E \u043E\u0431\u043E\u0436\u0430\u044E pixel art: \u0441\u043E\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u044B\u0439 http:\/\/t.co\/2tONVmg \u043C\u0435\u043D\u044C\u0448\u0435, \u0447\u0435\u043C \u0440\u0435\u0442\u0440\u043E http:\/\/t.co\/S738tFa",
  "id" : 81813329785528320,
  "created_at" : "2011-06-17 19:59:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81763206057562112",
  "text" : "\u0443\u0441\u043B\u0443\u0433\u0438 \u0434\u043E\u0432\u0435\u0440\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u0438 \u043A\u043E\u043D\u0441\u0443\u043B\u044C\u0442\u0430\u0446\u0438\u043E\u043D\u043D\u043E\u0433\u043E \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u044F \u043D\u0430 \u0431\u0430\u0437\u0435 \u043F\u043E\u0440\u0442\u0444\u0435\u043B\u0435\u0439 \u043D\u0430 NYSE. \u0438\u0437 \u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0438\u0438 \u043F\u043E\u043D\u044F\u043B, \u0447\u0442\u043E \u043E\u043D\u0438 \u043D\u0435 \u0437\u0430\u0440\u0430\u0431\u0430\u0442\u044B\u0432\u0430\u044E\u0442 \u043A\u043B\u0438\u0435\u043D\u0442\u0430\u043C)",
  "id" : 81763206057562112,
  "created_at" : "2011-06-17 16:40:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81762102179667968",
  "text" : "\u041D\u0430 12 \u044D\u0442\u0430\u0436\u0435 \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u0437\u0434\u0430\u043D\u0438\u044F \u043C\u043E\u0441\u043A\u0432\u0430-\u0441\u0438\u0442\u0438 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u043B\u0438\u0446\u0435\u043D\u0437\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u0430\u044F \u0431\u0440\u043E\u043A\u0435\u0440\u0441\u043A\u0430\u044F \u0438, \u043E\u0434\u043D\u043E\u0432\u0440\u0435\u043C\u0435\u043D\u043D\u043E, \u0438\u043D\u0432\u0435\u0441\u0442\u0438\u0446\u0438\u043E\u043D\u043D\u0430\u044F \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u044F, \u0442\u0430\u043A \u0441\u043A\u0430\u0437\u0430\u0442\u044C, \u043F\u0440\u043E\u0434\u0430\u044E\u0449\u0430\u044F",
  "id" : 81762102179667968,
  "created_at" : "2011-06-17 16:36:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/jfhDGRH",
      "expanded_url" : "http:\/\/fincake.ru\/d",
      "display_url" : "fincake.ru\/d"
    } ]
  },
  "geo" : { },
  "id_str" : "81391790246203393",
  "text" : "http:\/\/t.co\/jfhDGRH  \u044D\u0442\u043E \u0436\u0435 \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0435 \u0432 \u0420\u043E\u0441\u0441\u0438\u0438 \u0438\u0437\u0434\u0430\u043D\u0438\u0435, \u043F\u043E\u0441\u0432\u044F\u0449\u0435\u043D\u043D\u043E\u0435 \u0438\u043D\u0432\u0435\u0441\u0442\u0438\u0446\u0438\u044F\u043C \u043D\u0430 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u044B\u0445 \u0440\u044B\u043D\u043A\u0430\u0445 \u0438 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0439 \u0431\u0438\u0440\u0436\u0435\u0432\u043E\u0439 \u0438\u0433\u0440\u0435. damn",
  "id" : 81391790246203393,
  "created_at" : "2011-06-16 16:04:49 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81390480864198657",
  "text" : "\u043F\u043E\u043B\u0433\u043E\u0434\u0430 \u043D\u0430\u0437\u0430\u0434 \u0436\u0443\u0440\u043D\u0430\u043B \u0424\u0438\u043D\u0430\u043D\u0441 \u0440\u0435\u0437\u043A\u043E \u0441\u0442\u0430\u043B \u0447\u0438\u0442\u0430\u0431\u0435\u043B\u044C\u043D\u044B\u043C, \u043D\u0435 \u0443\u0434\u0438\u0432\u043B\u0435\u043D, \u0447\u0442\u043E \u0435\u0433\u043E \u0437\u0430\u043A\u0440\u044B\u0432\u0430\u044E\u0442. \u041D\u0435\u043F\u043E\u043D\u044F\u0442\u043D\u043E \u043A\u0430\u043A D' \u0435\u0449\u0435 \u043F\u0440\u043E\u0434\u0430\u0435\u0442\u0441\u044F, \u043B\u0443\u0447\u0448\u0438\u0439 \u0442\u0440\u0435\u0439\u0434\u0435\u0440\u0441\u043A\u0438\u0439 \u0436\u0443\u0440\u043D\u0430\u043B",
  "id" : 81390480864198657,
  "created_at" : "2011-06-16 15:59:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81389360456544274",
  "text" : "btw, \u043D\u0430 \u0441\u044A\u0435\u0437\u0434\u0430\u0445 \u0438 \u0434\u0440\u0443\u0433\u0438\u0445 \u0438\u0432\u0435\u043D\u0442\u0430\u0445 \u0420\u0421\u041F\u041F \u0432\u0441\u0435\u0433\u0434\u0430 \u043F\u0440\u0438\u0441\u0443\u0442\u0441\u0442\u0432\u0443\u0435\u0442 \u043F\u0430\u0440\u0430 \u0437\u043D\u0430\u043A\u043E\u043C\u044B\u0445 \u0441 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0442\u043E\u0440\u0430\u043C\u0438 \u0442\u0440\u0435\u0439\u0434\u0435\u0440\u043E\u0432, \u0434\u0435\u0440\u0436\u0430\u0449\u0438\u0445 \u0440\u0443\u043A\u0443 \u043D\u0430 \u043F\u0443\u043B\u044C\u0441\u0435. \u0437\u043D\u0430\u043A\u043E\u043C \u0441 \u043E\u0434\u043D\u0438\u043C.",
  "id" : 81389360456544274,
  "created_at" : "2011-06-16 15:55:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81343616907350017",
  "text" : "\u0421\u0447\u0430\u0441\u0442\u044C\u0435 = 1. Fixed income $10 k. 2. \u0412\u043A\u043B\u0430\u0434\u044B\u0432\u0430\u0442\u044C \u0434\u0443\u0448\u0443 \u0432 \u0438\u043D\u0442\u0435\u0440\u043D\u0435\u0442 \u0430\u043F\u0442\u0435\u043A\u0443. 3. \u0421\u043E\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u0441\u0442\u0443\u0434\u0438\u044E \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0439 \u0441 1 \u0434\u0438\u0437\u0430\u0439\u043D\u0435\u0440\u043E\u043C \u0438 1 \u043A\u043E\u0434\u0435\u0440\u043E\u043C.",
  "id" : 81343616907350017,
  "created_at" : "2011-06-16 12:53:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81341551032279040",
  "text" : "\u0417\u043D\u0430\u043A\u043E\u043C\u044B\u0439 Nico \u0435\u0434\u0435\u0442 \u0437\u0440\u0438\u0442\u0435\u043B\u0435\u043C \u0442\u0435\u043F\u0435\u0440\u044C \u0438 \u0432 \u0428\u0432\u0435\u0446\u0438\u044E \u043D\u0430 Dreamhack Summer 2011 \u043F\u043E Quakelive duel, tdm \u0438 ffa: http:\/\/bit.ly\/jxroOd \u0432\u043E\u0442 \u043B\u0430\u043A\u0438\u0434\u0430\u043A )",
  "id" : 81341551032279040,
  "created_at" : "2011-06-16 12:45:11 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81338886218989568",
  "text" : "\u0432\u0441\u0435-\u0442\u0430\u043A\u0438 \u0437\u0430 \u0441\u043F\u0438\u043D\u043E\u0439 \u0443\u0436\u0435 \u0434\u0432\u0430 \u0433\u043E\u0434\u0430 \u0437\u0430\u043D\u044F\u0442\u0438\u0439 \u0442\u0435\u0445 \u0430\u043D\u0430\u043B\u0438\u0437\u043E\u043C, \u0430 \u044D\u0442\u043E, \u043F\u043E\u0436\u0430\u043B\u0443\u0439, \u0441\u0430\u043C\u044B\u0435 \u043A\u0432\u0430\u043B\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u0437\u043D\u0430\u043D\u0438\u044F \u0438\u0437 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0445 \u0432\u043D\u0435 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u043E\u0439 \u0442\u0443\u0441\u043E\u0432\u043A\u0438.",
  "id" : 81338886218989568,
  "created_at" : "2011-06-16 12:34:36 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81337522457812992",
  "text" : "\u0421\u0435\u0433\u043E\u0434\u043D\u044F \u0432\u0430\u0436\u043D\u044B\u0439 \u0434\u0435\u043D\u044C, \u044F \u043F\u043E\u043D\u044F\u043B, \u0447\u0442\u043E \u0444\u043E\u043D\u0434\u043E\u0432\u044B\u0435 \u0440\u044B\u043D\u043A\u0438 \u043C\u043E\u044F \u0441\u0442\u0440\u0430\u0441\u0442\u044C. \u0417\u043D\u0430\u0447\u0438\u0442, \u0431\u0443\u0434\u0443 \u0440\u0430\u0437\u0432\u0438\u0432\u0430\u0442\u044C\u0441\u044F \u0432 \u044D\u0442\u043E\u0439 \u043E\u0431\u043B\u0430\u0441\u0442\u0438.  \u0412\u043E\u043F\u0440\u043E\u0441 \u0432 \u043D\u0430\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0438\u0438,",
  "id" : 81337522457812992,
  "created_at" : "2011-06-16 12:29:11 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 34 ],
      "url" : "http:\/\/t.co\/pPsVbWV",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=P-CTR5t7ph4",
      "display_url" : "youtube.com\/watch?v=P-CTR5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "81252430557351936",
  "text" : "current mood = http:\/\/t.co\/pPsVbWV",
  "id" : 81252430557351936,
  "created_at" : "2011-06-16 06:51:03 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81125625074688000",
  "text" : "\u041D\u0435 \u0431\u044B\u043B\u043E \u043D\u0438\u043A\u0430\u043A\u0438\u0445 \u0441\u043E\u043C\u043D\u0435\u043D\u0438\u0439, \u0447\u0442\u043E \"\u0421\u043E\u043B\u043D\u0435\u0447\u043D\u0430\u044F\" \u041C\u0430\u043A\u044C\u044E\u044D\u043D\u0430 \u0441 \u0435\u0435 \u043D\u0435\u0432\u0437\u0440\u0430\u0447\u043D\u043E\u0439 \u043E\u0431\u043B\u043E\u0436\u043A\u043E\u0439 - \u0442\u0435\u043A\u0441\u0442 \u0440\u0430\u0437\u043C\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u0438 \u0443\u043F\u043E\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0439. \u0415\u0434\u0432\u0430 \u043E\u0442\u043E\u0440\u0432\u0430\u043B\u0441\u044F for now.",
  "id" : 81125625074688000,
  "created_at" : "2011-06-15 22:27:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 78 ],
      "url" : "http:\/\/t.co\/q7B2R40",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=PeAr9V70jsg",
      "display_url" : "youtube.com\/watch?v=PeAr9V\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "79918593554399232",
  "text" : "\u0441\u0430\u043C\u043E\u0435 \u043D\u0435\u0432\u044B\u043D\u043E\u0441\u0438\u043C\u043E \u0437\u043B\u043E\u0432\u0435\u0449\u0435\u0435 \u0442\u0440\u0435\u0448-\u0445\u043E\u0440\u0440\u043E\u0440 \u043C\u0443\u0432\u0438 \u0432 \u0442\u0435\u043A\u0443\u0449\u0435\u043C \u0433\u043E\u0434\u0443: http:\/\/t.co\/q7B2R40",
  "id" : 79918593554399232,
  "created_at" : "2011-06-12 14:30:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79857140445089792",
  "text" : "Gmail \u043A\u043B\u0438\u0435\u043D\u0442\u044B \u043D\u0435 \u0441\u0447\u0438\u0442\u0430\u044E\u0442\u0441\u044F ofc",
  "id" : 79857140445089792,
  "created_at" : "2011-06-12 10:26:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "79854376809807872",
  "text" : "\u042F \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E \u043F\u043E\u043D\u0438\u043C\u0430\u044E, \u0447\u0442\u043E \u0432 \u0430\u043F\u0441\u0442\u043E\u0440\u0435 \u043D\u0435\u0442 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0439-\u043F\u043E\u0447\u0442\u043E\u0432\u044B\u0445 \u043A\u043B\u0438\u0435\u043D\u0442\u043E\u0432?",
  "id" : 79854376809807872,
  "created_at" : "2011-06-12 10:15:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78215351585869824",
  "text" : "\u0441\u043E\u0441\u0440\u0435\u0434\u043E\u0442\u043E\u0447\u0435\u043D\u043D\u043E \u043F\u0440\u043E\u043B\u0438\u0441\u0442\u0430\u043B \u043A\u043D\u0438\u0436\u043A\u0443 \u043F\u043E \u0445\u0442\u043C\u043B5 \u043E\u0442 O'Reilly. \u0442\u0435\u043A\u0443\u0449\u0438\u0445 \u044D\u043B\u0435\u043C\u0435\u043D\u0442\u043E\u0432 \u044F\u0432\u043D\u043E \u043D\u0435 \u0445\u0432\u0430\u0442\u0438\u0442, \u0447\u0442\u043E\u0431\u044B \u043B\u0438\u0448\u0438\u0442\u044C \u0444\u0438\u0448\u043A\u0438 jquery \u0436\u0438\u0437\u043D\u0438. perl next",
  "id" : 78215351585869824,
  "created_at" : "2011-06-07 21:42:47 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78176733202890752",
  "text" : "http:\/\/clck.ru\/ELop - \u0438\u0437 Zeitgeist (2007) http:\/\/bit.ly\/gBPe3D http:\/\/bit.ly\/dDZbwY - \u0430 \u044D\u0442\u0430 \u0443\u043D\u044B\u043B\u043E\u0441\u0442\u044C - \u0438\u0437 \u0441\u0438\u043D\u0433\u043B\u0430 :\\",
  "id" : 78176733202890752,
  "created_at" : "2011-06-07 19:09:20 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78173721751334912",
  "text" : "http:\/\/clck.ru\/ELpT - \u0438\u0437 \u0441\u0442\u0430\u0440\u043E\u0433\u043E, \u043A\u043E\u0433\u0434\u0430-\u0442\u043E \u0441\u043E\u0431\u0440\u0430\u043B \u0431\u043E\u043B\u044C\u0448\u0435 20 live \u0437\u0430\u043F\u0438\u0441\u0435\u0439 the aeroplane flies high.",
  "id" : 78173721751334912,
  "created_at" : "2011-06-07 18:57:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78171203554119680",
  "text" : "\u041C\u0430\u0448\u0435 \u043D\u0440\u0430\u0432\u0438\u0442\u0441\u044F Oasis, \u0430 \u044F \u043E\u0431\u043E\u0436\u0430\u044E The Smashing Pumpkins, \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u0441\u0438\u043D\u0433\u043B \u043A\u043E\u0442\u043E\u0440\u044B\u0445 \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E \u0441\u043B\u0438\u043B.",
  "id" : 78171203554119680,
  "created_at" : "2011-06-07 18:47:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78160749020712960",
  "text" : "\u0414\u0430\u0432\u043D\u043E \u0443 \u043C\u0435\u043D\u044F \u0441\u0442\u043E\u043B\u044C\u043A\u043E \u0445\u043E\u043B\u0438\u0448\u0438\u0442\u0430 \u0437\u0430 \u0434\u0435\u043D\u044C \u043D\u0435 \u0431\u044B\u043B\u043E, \u0430 \u0438\u0437 \u043B\u0443\u0442\u0430 \u0442\u043E\u043B\u044C\u043A\u043E \u0441\u0432\u0438\u0442\u043E\u043A. \u0421\u043A\u0435\u043B\u0435\u0442\u0443 \u043D\u0443\u0436\u043D\u043E \u043F\u0435\u0440\u0435\u0445\u043E\u0434\u0438\u0442\u044C \u043D\u0430 \u0434\u0440\u0443\u0433\u0443\u044E \u043C\u043C\u043E\u0440\u043F\u0433.",
  "id" : 78160749020712960,
  "created_at" : "2011-06-07 18:05:49 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77290684394115072",
  "text" : "Foxtrot uniform charlie kilo",
  "id" : 77290684394115072,
  "created_at" : "2011-06-05 08:28:29 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Gilbert",
      "screen_name" : "grumpygamer",
      "indices" : [ 0, 12 ],
      "id_str" : "27531390",
      "id" : 27531390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76755970415538176",
  "geo" : { },
  "id_str" : "76758428168630272",
  "in_reply_to_user_id" : 27531390,
  "text" : "@grumpygamer taking into account greek roots - aphotogenic or photo-a-genic?",
  "id" : 76758428168630272,
  "in_reply_to_status_id" : 76755970415538176,
  "created_at" : "2011-06-03 21:13:30 +0000",
  "in_reply_to_screen_name" : "grumpygamer",
  "in_reply_to_user_id_str" : "27531390",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]