Grailbird.data.tweets_2015_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "670701202712211457",
  "text" : "\u0424\u0430\u0441\u043E\u0432\u043A\u0430 \"\u0436\u0438\u0432\u044B\u0445 \u043A\u043E\u043D\u0444\u0435\u0442\" \u0432 \"\u0434\u0435\u0442\u0441\u043A\u043E\u0439\" \u0441\u0435\u0440\u0438\u0438 (\u0436\u0435\u043B\u0435 \u0438\u0437 \u0441\u043C\u043E\u0440\u043E\u0434\u0438\u043D\u044B \u0441 \u043A\u0435\u043D\u0433\u0443\u0440\u0443 \u043D\u0430 \u0443\u043F\u0430\u043A\u043E\u0432\u043A\u0435 \u0438 \u0434\u0440\u0443\u0433\u0438\u0435) - \u043E\u043D\u0430 \u043F\u0440\u043E\u0441\u0442\u043E \u043D\u0435\u0441\u043F\u0440\u0430\u0432\u0435\u0434\u043B\u0438\u0432\u0430",
  "id" : 670701202712211457,
  "created_at" : "2015-11-28 20:30:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668229792081268736",
  "text" : "Neutral Milk Hotel",
  "id" : 668229792081268736,
  "created_at" : "2015-11-22 00:49:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "668111663279771649",
  "text" : "Postmodern Jukebox",
  "id" : 668111663279771649,
  "created_at" : "2015-11-21 17:00:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "667109922086195201",
  "text" : "\u0420\u0430\u043D\u043E \u0438\u043B\u0438 \u043F\u043E\u0437\u0434\u043D\u043E \u043C\u044B \u0432\u0441\u0435 \u0432\u0437\u0440\u043E\u0441\u043B\u0435\u0435\u043C, \u0438 \u043D\u0435\u0438\u0437\u0431\u0435\u0436\u043D\u043E \u043D\u0430\u0441\u0442\u0430\u0435\u0442 \u0432\u0440\u0435\u043C\u044F \u0447\u0435\u0441\u0442\u043D\u043E \u043F\u0440\u0438\u0437\u043D\u0430\u0442\u044C\u0441\u044F \u0441\u0435\u0431\u0435: \u0433\u0440\u044B\u0437\u0438 \u0442\u044B \u0445\u0443\u0439, \u0447\u0435\u043B\u043E\u0432\u0435\u0447\u0435\u0441\u0442\u0432\u043E, \u0433\u0440\u044B\u0437\u0438, \u0435\u0431\u0430\u043D\u044B\u0439 \u0442\u044B \u0442\u043E\u043F\u0442\u044B\u0433\u0438\u043D",
  "id" : 667109922086195201,
  "created_at" : "2015-11-18 22:39:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "665937226598060032",
  "text" : "\u041F\u043B\u0435\u0432\u0430\u043B\u0438 \u043C\u044B \u043D\u0430 \u0441\u043C\u0435\u0440\u0442\u044C, \u0434\u0430",
  "id" : 665937226598060032,
  "created_at" : "2015-11-15 16:59:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "664784086729363457",
  "text" : "\u041A\u043E\u0433\u0434\u0430 \u044F \u0432 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435 \u0432\u0441\u0435\u0433\u043E \u044D\u0442\u043E\u0433\u043E \u0441\u043F\u0440\u043E\u0441\u0438\u043B \u043A\u0442\u043E \u0435\u0435 \u043F\u0430\u043F\u043E\u0447\u043A\u0430, \u043E\u043D\u0430 \u0432\u0434\u0440\u0443\u0433 \u043E\u0442\u0432\u0435\u0442\u0438\u043B\u0430, \u0447\u0442\u043E \u041B\u0435\u0432 \u0414\u0430\u0432\u0438\u0434\u043E\u0432\u0438\u0447 \u0417\u0438\u043B\u044C\u0431\u0435\u0440\u0448\u0442\u0435\u0439\u043D\u2026",
  "id" : 664784086729363457,
  "created_at" : "2015-11-12 12:37:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663935128893317120",
  "text" : "\u041F\u043E\u043B\u0443\u0447\u0438\u0432\u0448\u0438\u0439\u0441\u044F \u0443 \u0432\u0430\u0441 \u0447\u0435\u0440\u0435\u0437 \u0441\u0443\u0442\u043A\u0438 \u0430\u0440\u0442-\u043E\u0431\u044A\u0435\u043A\u0442 \u043B\u0438\u0448\u044C \u043A\u043E\u043C\u043F\u0438\u043B\u0438\u0440\u0443\u0435\u0442 \u0440\u0430\u0437\u0440\u043E\u0437\u043D\u0435\u043D\u043D\u044B\u0435 \u0430\u0440\u0442\u0435\u0444\u0430\u043A\u0442\u044B \u0432 \u0440\u0443\u043A\u043E\u0432\u043E\u0434\u0441\u0442\u0432\u043E \u043F\u043E \u0442\u043E\u043C\u0443 \u043A\u0430\u043A \u043E\u0441\u0442\u0430\u0432\u0430\u0442\u044C\u0441\u044F \u0436\u0438\u0432\u044B\u043C(\u0434\u043B\u044F \u043D\u0430\u0447\u0438\u043D\u0430\u044E\u0449\u0438\u0445)",
  "id" : 663935128893317120,
  "created_at" : "2015-11-10 04:24:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "663933476094271489",
  "text" : "\u041A\u0443\u043F\u0438\u0432 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0442\u043E\u0440 arduino (14+) \u0434\u043B\u044F \u0442\u0440\u043E\u043B\u043B\u0438\u043D\u0433\u0430 \u0434\u0438\u0441\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u043E-\u043E\u0440\u0438\u0435\u043D\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u043E\u043D\u0442\u043E\u043B\u043E\u0433\u0438\u0438 \u0438 \u0440\u0438\u0442\u0443\u0430\u043B\u043E\u0432 \u0442\u0430\u043A \u043D\u0430\u0437\u044B\u0432\u0430\u0435\u043C\u043E\u0439 \u0436\u0438\u0437\u043D\u0438 \u0447\u0443\u0432\u0441\u0442\u0432\u0443\u0435\u0448\u044C \u0441\u0435\u0431\u044F \u041B\u0435\u043E\u043D\u0430\u0440\u0434\u043E",
  "id" : 663933476094271489,
  "created_at" : "2015-11-10 04:17:30 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662662271550791680",
  "text" : "\u044F \u0435\u0434\u0443 \u0432 \u0446\u0435\u043D\u0442\u0440\n\u0432 \u0441\u043C\u0435\u0440\u0442\u0435\u043B\u044C\u043D\u043E \u0445\u043E\u043B\u043E\u0434\u043D\u044B\u0439 \u0446\u0435\u043D\u0442\u0440 \u0441\u043E\u043B\u043D\u0446\u0430\n\u043D\u0435 \u0437\u0430\u0431\u0443\u0434\u044C \u043F\u0430\u0441\u043F\u043E\u0440\u0442 \u0438 \u043C\u043E\u0438 \u0442\u0430\u0431\u043B\u0435\u0442\u043A\u0438",
  "id" : 662662271550791680,
  "created_at" : "2015-11-06 16:06:11 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "662055335709032448",
  "text" : "\u041F\u0440\u0438\u0434\u0443\u043C\u0430\u043B",
  "id" : 662055335709032448,
  "created_at" : "2015-11-04 23:54:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "661951426663460864",
  "text" : "\u0413\u0435\u0432\u044E\u0440\u0446\u0442\u0440\u0430\u043C\u0438\u043D\u0435\u0440 \u0434\u043B\u044F \u041A\u0430\u043D\u0434\u0438, \u0447\u0438\u043A\u0435\u043D \u0444\u043B\u043E\u0440\u0435\u043D\u0442\u0438\u043D\u0430 \u0434\u043B\u044F \u041D\u0438\u043A\u043E\u043B\u044C (\u0441\u043C\u043E\u0442\u0440\u0438, \u043D\u0435 \u043F\u0435\u0440\u0435\u043F\u0443\u0442\u0430\u0439)",
  "id" : 661951426663460864,
  "created_at" : "2015-11-04 17:01:33 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]