Grailbird.data.tweets_2014_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528237541611556864",
  "text" : "Caro Emerald",
  "id" : 528237541611556864,
  "created_at" : "2014-10-31 17:30:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527893150057381888",
  "text" : "\u0430\u0443\u0434\u0438\u043E\u0444\u0438\u043B\u0430\u043C \u043D\u0435 \u043D\u0430\u0439\u0442\u0438 \u044D\u0441\u0442\u0435\u0442\u0438\u0447\u043D\u043E\u0433\u043E \u0440\u0435\u0447\u0435\u0432\u043E\u0433\u043E \u043F\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u044F, \u0441\u043B\u044B\u0448\u0430\u043B \u043A\u0430\u043A \u043E\u0434\u043D\u0430 \u043F\u0440\u043E\u0438\u0437\u043D\u0435\u0441\u043B\u0430 \u00AB\u044F \u0432\u0435\u0434\u044C \u043D\u0435\u0441\u043B\u0443\u0447\u0430\u0439\u043D\u043E \u0442\u0435\u0431\u044F \u0432\u044B\u0431\u0440\u0430\u043B\u0430\u00BB,\u0438 \u044D\u0442\u043E \u0438\u0441\u043F\u0440\u0430\u0432\u0438\u043B\u043E \u0446\u0435\u043B\u0443\u044E \u043D\u0435\u0434\u0435\u043B\u044E",
  "id" : 527893150057381888,
  "created_at" : "2014-10-30 18:41:49 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "527885740156682240",
  "text" : "\u0422\u0440\u043E\u0446\u043A\u0438\u0441\u0442 - \u044D\u0442\u043E \u0442\u043E\u0442, \u043A\u043E\u043C\u0443 \u0434\u0435\u043A\u043B\u0430\u0440\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0444\u0430\u043D\u0442\u0430\u0441\u043C\u0430\u0433\u043E\u0440\u0438\u0447\u0435\u0441\u043A\u043E\u0435 \u0434\u043E\u043F\u0443\u0449\u0435\u043D\u0438\u0435 \u0442\u0440\u0443\u0434\u043D\u0435\u0439, \u0447\u0435\u043C \u0434\u0440\u0443\u0433\u0438\u043C \u043D\u043E\u0432\u044B\u043C \u0441\u0442\u0440\u0430\u043D\u043D\u044B\u043C.",
  "id" : 527885740156682240,
  "created_at" : "2014-10-30 18:12:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523846330863874048",
  "text" : "unit 2: nginx, nginx conf, sql conf: \u2611",
  "id" : 523846330863874048,
  "created_at" : "2014-10-19 14:41:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523490332592574465",
  "text" : "unit 1: ssh ,  nginx , martini golang : \u2611",
  "id" : 523490332592574465,
  "created_at" : "2014-10-18 15:06:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "523262022331666433",
  "text" : "\u0414\u0435\u043D\u044C \u043E\u0434\u043D\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u043E\u0439 - Aron Shlome Katz",
  "id" : 523262022331666433,
  "created_at" : "2014-10-17 23:59:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "digitalBranding",
      "indices" : [ 54, 70 ]
    }, {
      "text" : "Digital",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "DigitalOctober",
      "indices" : [ 80, 95 ]
    }, {
      "text" : "smm",
      "indices" : [ 96, 100 ]
    }, {
      "text" : "smo",
      "indices" : [ 101, 105 ]
    }, {
      "text" : "DigitalMarketing",
      "indices" : [ 106, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/DtYs3ee4cp",
      "expanded_url" : "http:\/\/Slovo.pw",
      "display_url" : "Slovo.pw"
    } ]
  },
  "geo" : { },
  "id_str" : "522735660109938689",
  "text" : "http:\/\/t.co\/DtYs3ee4cp  \u0421\u043E\u0437\u0434\u0430\u0435\u043C \u043A\u0430\u0447\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439 Digital. #digitalBranding #Digital #DigitalOctober #smm #smo #DigitalMarketing",
  "id" : 522735660109938689,
  "created_at" : "2014-10-16 13:07:47 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TimOfLegend &:Y\u007D",
      "screen_name" : "TimOfLegend",
      "indices" : [ 127, 139 ],
      "id_str" : "24585498",
      "id" : 24585498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/3z8qgzK0RF",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=s-LSMCYjHow#t=32",
      "display_url" : "youtube.com\/watch?v=s-LSMC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "518876973947711489",
  "text" : "http:\/\/t.co\/3z8qgzK0RF Tiam mi ekploris la unuan fojon. Shivers, been waiting for 15 years for that enormous serotonin release @TimOfLegend",
  "id" : 518876973947711489,
  "created_at" : "2014-10-05 21:34:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]