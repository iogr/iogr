Grailbird.data.tweets_2011_12 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153180079927726080",
  "geo" : { },
  "id_str" : "153215542998728704",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u0432\u0441\u0435, \u0447\u0442\u043E \u043D\u0435 \u0443\u0431\u0438\u0432\u0430\u0435\u0442, \u0434\u0435\u043B\u0430\u0435\u0442 \u043C\u0435\u043D\u044F \u0441\u043C\u0435\u0448\u043D\u0435\u0435 - \u043F\u043E\u044D\u0442\u043E\u043C\u0443 \u044F \u0442\u0430\u043A\u043E\u0439 \u0441\u043C\u0435\u0448\u043D\u043E\u0439. \u041D\u0435 \u0437\u043D\u0430\u044E \u0447\u0435\u0433\u043E \u0442\u044B \u0436\u0435\u043B\u0430\u0435\u0448\u044C. \u0412\u0435\u0441\u0435\u043B\u043E\u0433\u043E \u043F\u0440\u0430\u0437\u0434\u043D\u0438\u043A\u0430.",
  "id" : 153215542998728704,
  "in_reply_to_status_id" : 153180079927726080,
  "created_at" : "2011-12-31 20:46:46 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/aKvCsn4X",
      "expanded_url" : "http:\/\/vkontakte.ru\/wall6897102_74",
      "display_url" : "vkontakte.ru\/wall6897102_74"
    } ]
  },
  "geo" : { },
  "id_str" : "153003993260507137",
  "text" : "\u0423\u0431\u0438\u043B\u0441\u044F \u043D\u0430 \u0442\u0440\u0435\u043D\u0438\u0440\u043E\u0432\u043A\u0435, \u043F\u043E\u0436\u0435\u043B\u0430\u043B \u0441\u0435\u0431\u0435 http:\/\/t.co\/aKvCsn4X \u0438 \u043D\u0430\u0447\u0430\u043B \u0443\u0442\u0440\u043E \u0441 \"L\u2019insurrection Qui Vient\" \u0438 \u043A\u043D\u0438\u0436\u043A\u0438 \u041A\u0430\u0440\u043B\u0438\u043D\u0430",
  "id" : 153003993260507137,
  "created_at" : "2011-12-31 06:46:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152807703939514369",
  "text" : "\u0417\u0430\u043A\u0440\u044B\u043B \u044D\u0442\u0438 \u0434\u0435\u0441\u044F\u0442\u044C \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u043E\u0432. + 27 \u0442\u0440. \u0443\u0439\u0434\u0443\u0442 \u0432 \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u044B.",
  "id" : 152807703939514369,
  "created_at" : "2011-12-30 17:46:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152795945728356352",
  "text" : "\u0414\u0435\u043D\u044C\u0433\u0438, \u043C\u0430\u0448\u0438\u043D\u044B, \u0430\u043B\u043A\u043E\u0433\u043E\u043B\u044C, \u0442\u0435\u0441\u0442\u043E\u0441\u0442\u0435\u0440\u043E\u043D \u0438 \u0441\u043E\u0441\u0442\u044F\u0437\u0430\u043D\u0438\u044F \u0441\u043E\u0441\u0443\u0442 \u0432\u043C\u0435\u0441\u0442\u0435 \u0438 \u043F\u043E \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u0438 = \u043C\u0438\u043D\u0443\u0442\u043A\u0430  \u043C\u0443\u0436\u0441\u043A\u043E\u0433\u043E \u044D\u043B\u0438\u0442\u0438\u0437\u043C\u0430.",
  "id" : 152795945728356352,
  "created_at" : "2011-12-30 16:59:26 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152349568623837184",
  "text" : "\u041F\u0440\u0438\u0437\u043D\u0430\u043D\u0438\u0435, \u0447\u0442\u043E \u044F \u0441\u043A\u0430\u0447\u0430\u043B \u0434\u0432\u0430 \u043F\u0438\u043A\u0441\u0435\u043B\u044C\u043D\u044B\u0445 \u043A\u0432\u0435\u0441\u0442\u0430 \u0434\u043B\u044F \u041D\u0413, \u043F\u043E\u0445\u043E\u0436\u0435, \u0434\u0435\u0439\u0441\u0442\u0432\u0443\u0435\u0442 \u043A\u0430\u043A \u043A\u0440\u0430\u0441\u043D\u0430\u044F \u0442\u0440\u044F\u043F\u043A\u0430 - \u0443\u0436\u0435 \u0437\u0430\u0441\u044B\u043F\u0430\u043B\u0438 \u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0435\u043D\u0438\u044F\u043C\u0438.",
  "id" : 152349568623837184,
  "created_at" : "2011-12-29 11:25:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "152098278329155584",
  "text" : "\u0417\u0430\u0448\u0435\u043B \u0432 \u0437\u0430\u043B \u043D\u0430 \u0428\u0425, \u0441\u0435\u043B \u043D\u0430 \u043F\u0435\u0440\u0432\u044B\u0439 \u0440\u044F\u0434 \u0438 \u043F\u044F\u0442\u044C \u043C\u0438\u043D\u0443\u0442 \u0436\u0434\u0430\u043B \u0432 \u043F\u0443\u0441\u0442\u043E\u043C \u043A\u0438\u043D\u043E\u0442\u0435\u0430\u0442\u0440\u0435 - \u043A\u0430\u043A \u0432 \u0434\u0435\u0442\u0441\u0442\u0432\u0435. )",
  "id" : 152098278329155584,
  "created_at" : "2011-12-28 18:47:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151982612108410880",
  "text" : "\u041A\u043E\u0442\u043E\u0440\u043E\u0435 \u0431\u0443\u0434\u0435\u0442 \"\u0430\u043D\u0430\u0440\u0445\u0438\u0441\u0442\u0441\u043A\u0438\u043C\" \u0434\u043E \u043C\u043E\u043C\u0435\u043D\u0442\u0430 \u0430\u0440\u0442\u0438\u043A\u0443\u043B\u044F\u0446\u0438\u0438 \u043D\u0435\u043F\u0440\u0438\u044F\u0442\u0438\u044F \u0438 \u043E\u0442\u0441\u0442\u0430\u043B\u043E\u0441\u0442\u0438 \u041B\u0438\u0441\u0430\u043D\u0434\u0435\u0440\u0430 \u0421\u043F\u0443\u043D\u0435\u0440\u0430, \u0414\u0436\u043E\u0437\u0430\u0439\u0438 \u0423\u043E\u0440\u0435\u043D\u043D\u0430, \u0422\u0430\u043A\u043A\u0435\u0440\u0430 \u0438 \u0420\u0443\u0434\u043E\u043B\u044C\u0444\u0430 \u0420\u043E\u043A\u0435\u0440\u0430.",
  "id" : 151982612108410880,
  "created_at" : "2011-12-28 11:07:33 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151982044711358464",
  "text" : "SEESOOHRSSEISSOOOOOS \n\u041E\u0431\u044A\u044F\u0432\u043B\u044F\u044E \u043E\u0431 \u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u0438 \u0430\u043D\u0430\u0440\u0445\u0438\u0441\u0442\u0441\u043A\u043E\u0433\u043E \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u044F \"\u0423\u043B\u0438\u0446\u0430 \u0421\u0435\u0437\u0430\u043C\".",
  "id" : 151982044711358464,
  "created_at" : "2011-12-28 11:05:17 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/hOQAwQBP",
      "expanded_url" : "http:\/\/informer.rts.ru\/main\/graph\/issue\/RTS-3.12.gif",
      "display_url" : "informer.rts.ru\/main\/graph\/iss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "151950505457893376",
  "text" : "http:\/\/t.co\/hOQAwQBP So nu, tokeh don't ask me if I even wonder why - oy gewalt, a white fish isn't purple.",
  "id" : 151950505457893376,
  "created_at" : "2011-12-28 08:59:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151375337131999233",
  "text" : "\u041E\u0442\u0433\u0430\u0434\u0430\u0439 \u0437\u0430\u0433\u0430\u0434\u043A\u0443: \"\u041A\u0430\u043A \u043E\u0442\u043C\u0435\u0440\u0438\u0442\u044C \u043F\u043E\u043B\u0436\u0438\u0437\u043D\u0438?\" - \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0438\u043B \u043F\u0430\u0440\u0435\u043D\u044C \u0432 sb.",
  "id" : 151375337131999233,
  "created_at" : "2011-12-26 18:54:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "151273148455714816",
  "text" : "\u0420\u0430\u0437 \u0443\u0436 \u043C\u044B \u0424\u0435\u043D\u0438\u0438 \u0438 \u0438\u0440\u0440\u0435\u0434\u0435\u043D\u0442\u0438\u0441\u0442\u044B, \u0441\u0438\u0441\u0442\u043E\u043B\u044B \u0438 \u044D\u043F\u0438\u0441\u0442\u043E\u043B\u044B, \u043F\u0440\u043E\u0442\u0435\u043D\u0446\u0438\u0438 \u0438 \u0440\u0435\u0442\u0435\u043D\u0446\u0438\u0438 \u0430\u043F\u0441\u0442\u043E\u0440\u0430 - \u043F\u043E\u0447\u0435\u043C\u0443 \u043D\u0435\u043B\u044C\u0437\u044F \u0432\u0437\u044F\u0442\u044C 50% \u043F\u0440\u0435\u0434\u043E\u043F\u043B\u0430\u0442\u044B \u043E\u0442 \u0437\u0430\u043A\u0430\u0437\u0430?",
  "id" : 151273148455714816,
  "created_at" : "2011-12-26 12:08:23 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150607653582798848",
  "text" : "\u0412\u0441\u0435 \u0434\u0435\u0432\u0443\u0448\u043A\u0438 \u0441 \u043A\u0440\u043E\u0445\u043E\u0442\u043D\u044B\u043C \u043F\u043E\u0434\u0432\u0435\u0441\u043D\u044B\u043C \u043A\u043B\u044E\u0447\u0438\u043A\u043E\u043C \u043D\u0430 \u0433\u0440\u0443\u0434\u0438, \u043A\u043E\u0442\u043E\u0440\u044B\u0445 \u044F \u0432\u0441\u0442\u0440\u0435\u0442\u0438\u043B \u0437\u0430 \u0434\u0432\u0430 \u0434\u043D\u044F \u0431\u044B\u043B\u0438 \u043E\u0447. \u043A\u043B\u0430\u0441\u0441\u043D\u044B\u043C\u0438. \u0443\u043C\u043E\u043B\u044F\u044E \u0441\u0430\u0442\u0430\u043D\u0443 \u043B\u0438\u043C\u0438\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0438\u0445 \u043F\u0430\u0440\u0442\u0438\u044E",
  "id" : 150607653582798848,
  "created_at" : "2011-12-24 16:03:57 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/eBCqlGaS",
      "expanded_url" : "http:\/\/t0.gstatic.com\/images?q=tbn:ANd9GcSDaDJBLTEjl5J0Ti5jwWnOBmfkqN20tbbW2W9jZxKyaBRQdngZ0g",
      "display_url" : "t0.gstatic.com\/images?q=tbn:A\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "150552284491816960",
  "text" : "\u041C\u043E\u0436\u043D\u043E \u043B\u0438 \u0434\u0430\u0440\u0438\u0442\u044C \u0435\u0434\u0438\u043D\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0439 \u043F\u043E\u0434\u0440\u0443\u0436\u043A\u0435 \u043D\u0430 \u0434\u0440 \u043D\u0435\u043F\u043E\u0434\u0430\u0440\u0435\u043D\u043D\u044B\u0435 \u0431\u044B\u0432\u0448\u0435\u0439 \u0434\u0435\u0432\u0443\u0448\u043A\u0435 \u043D\u044F\u0448\u043A\u0438? http:\/\/t.co\/eBCqlGaS \u042F \u043D\u0435 \u0441\u0442\u0430\u043D\u0443 = Smeagol is detected",
  "id" : 150552284491816960,
  "created_at" : "2011-12-24 12:23:56 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/ClvuqUfH",
      "expanded_url" : "http:\/\/4sq.com\/rJMAsu",
      "display_url" : "4sq.com\/rJMAsu"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7532622477, 37.6483547688 ]
  },
  "id_str" : "150546270241554433",
  "text" : "\u041C\u0421\u0424\u041E \u044D\u043A\u0437\u0430\u043C\u0435\u043D (@ \u0412\u044B\u0441\u0448\u0430\u044F \u0448\u043A\u043E\u043B\u0430 \u044D\u043A\u043E\u043D\u043E\u043C\u0438\u043A\u0438 (\u041D\u0418\u0423 \u0412\u0428\u042D) w\/ 5 others) http:\/\/t.co\/ClvuqUfH",
  "id" : 150546270241554433,
  "created_at" : "2011-12-24 12:00:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/BXAJzEet",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=nFxuQ8UAp7M",
      "display_url" : "youtube.com\/watch?v=nFxuQ8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "150348977294950400",
  "text" : "\u041D\u0430\u043F\u043E\u043C\u043D\u0438\u043B \u043A\u043E\u043B\u043B\u0435\u0433\u0430\u043C, \u0447\u0442\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u0438\u0441\u043A\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u044C, \u043E\u043D\u0430 \u0436\u0435 \u0436\u0438\u0437\u043D\u044C \u043D\u0435 \u043F\u043E \u043B\u0436\u0438, \u0440\u0430\u0441\u0447\u0435\u0445\u043B\u044F\u0435\u0442 \u0431\u0438\u043E\u0441 \u043E\u0442 zoe. http:\/\/t.co\/BXAJzEet bb",
  "id" : 150348977294950400,
  "created_at" : "2011-12-23 22:56:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "150182800081944576",
  "text" : "= \u0411\u0415\u0417\u041D\u041E\u0413N\u041C",
  "id" : 150182800081944576,
  "created_at" : "2011-12-23 11:55:44 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/tJ9mLcrZ",
      "expanded_url" : "http:\/\/4sq.com\/sIPFpo",
      "display_url" : "4sq.com\/sIPFpo"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7679613665, 37.5997960567 ]
  },
  "id_str" : "150181268875780097",
  "text" : "\u0421\u043A\u043E\u043B\u044C\u043A\u043E \u043A\u043E\u0444\u0435\u0438\u043D\u0430 \u043F\u043E\u0442\u0440\u0435\u0431\u043B\u044F\u044E\u0442\\\u043E\u0442\u043F\u0443\u0441\u043A\u0430\u044E\u0442 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430\u043C sb? (@ Starbucks w\/ 3 others) [pic]: http:\/\/t.co\/tJ9mLcrZ",
  "id" : 150181268875780097,
  "created_at" : "2011-12-23 11:49:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/rNT98YFm",
      "expanded_url" : "http:\/\/slon.ru\/world\/publichnyy_kannibalizm_kak_torzhestvo_chelovecheskogo_razuma-727254.xhtml",
      "display_url" : "slon.ru\/world\/publichn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "149830657781145601",
  "text" : "Slon.ru: \u041F\u0443\u0431\u043B\u0438\u0447\u043D\u044B\u0439 \u043A\u0430\u043D\u043D\u0438\u0431\u0430\u043B\u0438\u0437\u043C \u043A\u0430\u043A \u0442\u043E\u0440\u0436\u0435\u0441\u0442\u0432\u043E \u0447\u0435\u043B\u043E\u0432\u0435\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0440\u0430\u0437\u0443\u043C\u0430 http:\/\/t.co\/rNT98YFm",
  "id" : 149830657781145601,
  "created_at" : "2011-12-22 12:36:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/GhwRSs61",
      "expanded_url" : "http:\/\/4sq.com\/ufFvgO",
      "display_url" : "4sq.com\/ufFvgO"
    } ]
  },
  "geo" : { },
  "id_str" : "149820529531027456",
  "text" : "\u0413\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u043E \u044F \u043D\u0435\u043D\u0430\u0432\u0438\u0436\u0443 \u0432\u043E \u0432\u0441\u0435\u0445 \u043F\u0440\u043E\u044F\u0432\u043B\u0435\u043D\u0438\u044F\u0445, \u043D\u043E \u0443 \u0440\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0438 \u0435\u0441\u0442\u044C \u043C\u043D\u0438\u043C\u044B\u0435 \u0447\u0435\u0440\u0442\u044B, \u0434\u0430\u044E\u0449\u0438\u0435 \u043D\u0430\u0434\u0435\u0436\u0434\u0443 (@ \u041A\u0430\u0444\u0435 \u0420\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0430*): http:\/\/t.co\/GhwRSs61",
  "id" : 149820529531027456,
  "created_at" : "2011-12-22 11:56:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149805612111372288",
  "text" : "\u041F\u043E\u0437\u0432\u043E\u043D\u0438\u043B\u0438 \u0438\u0437 \u043C\u0438\u043D\u0438\u0441\u0442\u0435\u0440\u0441\u0442\u0432\u0430 \u044D\u043A\u043E\u043D\u043E\u043C\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0440\u0430\u0437\u0432\u0438\u0442\u0438\u044F \u0438 \u0441\u043A\u0430\u0437\u0430\u043B\u0438, \u0447\u0442\u043E \u043E\u043D\u0438 \u043D\u0435 \u0432\u044B\u043F\u043B\u0430\u0442\u0438\u043B\u0438 \u043C\u043D\u0435 \u0447\u0430\u0441\u0442\u044C \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u044B 6 \u0442\u044B\u0441\u044F\u0447 324 \u0440\u0443\u0431\u043B\u044F MRKGNEO",
  "id" : 149805612111372288,
  "created_at" : "2011-12-22 10:56:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149797994940731392",
  "text" : "\u0420\u044F\u0434\u043E\u043C \u0412\u0430\u0434\u0438\u043C \u0414\u044B\u043C\u043E\u0432 \u0432\u0434\u043E\u0445\u043D\u043E\u0432\u0435\u043D\u043D\u043E \u043E\u0431\u0449\u0430\u0435\u0442\u0441\u044F \u0441 \u043C\u043E\u043B\u043E\u0434\u0435\u0436\u044C\u044E (\u043C\u0431 \u0441 \u043F\u0440\u043E\u0434\u0430\u0432\u0446\u0430\u043C\u0438).",
  "id" : 149797994940731392,
  "created_at" : "2011-12-22 10:26:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149783029739556864",
  "text" : "hopefully yet rather bound merely to a virtu",
  "id" : 149783029739556864,
  "created_at" : "2011-12-22 09:27:11 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149407022918549504",
  "text" : "421",
  "id" : 149407022918549504,
  "created_at" : "2011-12-21 08:33:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/Pycv9RxL",
      "expanded_url" : "http:\/\/www.adamatomic.com\/fathom\/",
      "display_url" : "adamatomic.com\/fathom\/"
    } ]
  },
  "geo" : { },
  "id_str" : "149270892847972352",
  "text" : "http:\/\/t.co\/Pycv9RxL flixel as3, flex builder",
  "id" : 149270892847972352,
  "created_at" : "2011-12-20 23:32:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/8sXqLl83",
      "expanded_url" : "http:\/\/4sq.com\/v0eDGz",
      "display_url" : "4sq.com\/v0eDGz"
    } ]
  },
  "geo" : { },
  "id_str" : "149079288933658625",
  "text" : "From a boolean logic standpoint, before you had coffee were you tiresomely strogged? (@ \u041A\u0430\u0444\u0435 \u0420\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0430* w\/ 2 others) http:\/\/t.co\/8sXqLl83",
  "id" : 149079288933658625,
  "created_at" : "2011-12-20 10:50:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "149074705234673664",
  "text" : "\u0412\u0430\u043A\u0430\u043D\u0441\u0438\u0438 \u0441\u043E\u0441\u0442\u0430\u0432\u043B\u0435\u043D\u044B, \u043F\u043E\u043C\u0435\u0449\u0435\u043D\u0438\u044F \u0433\u043E\u0442\u043E\u0432\u044B, \u0441\u0430\u0439\u0442 \u0441\u0434\u0435\u043B\u0430\u043D \u0438, \u043F\u043E\u0445\u043E\u0436\u0435, \u043D\u0430\u043F\u0440\u043E\u0441\u0438\u043B\u0441\u044F \u0437\u0430\u043A\u0430\u0437 (\u0410\u0441\u0430\u0444), \u043D\u043E \u0434\u043E\u043C\u0435\u043D \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0438\u0442\u0441\u044F \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u0441\u0443\u0442\u043E\u043A.",
  "id" : 149074705234673664,
  "created_at" : "2011-12-20 10:32:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrey Vinokurov",
      "screen_name" : "Yuusou1989",
      "indices" : [ 0, 11 ],
      "id_str" : "255977897",
      "id" : 255977897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148850493563748352",
  "geo" : { },
  "id_str" : "148851938128183296",
  "in_reply_to_user_id" : 255977897,
  "text" : "@Yuusou1989 \u0443\u0436 \u0435\u0441\u043B\u0438 \u0442\u044B \u043F\u0440\u0430\u0432, \u0442\u043E \u0442\u044B \u043F\u0440\u0430\u0432 )",
  "id" : 148851938128183296,
  "in_reply_to_status_id" : 148850493563748352,
  "created_at" : "2011-12-19 19:47:22 +0000",
  "in_reply_to_screen_name" : "Yuusou1989",
  "in_reply_to_user_id_str" : "255977897",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrey Vinokurov",
      "screen_name" : "Yuusou1989",
      "indices" : [ 0, 11 ],
      "id_str" : "255977897",
      "id" : 255977897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148848323028197376",
  "geo" : { },
  "id_str" : "148849366357131265",
  "in_reply_to_user_id" : 255977897,
  "text" : "@Yuusou1989  \u043E\u0442 \u043F\u0440\u0438\u0440\u043E\u0434\u044B \u0434\u043E\u0431\u0440\u044B\u0439, \u043F\u0440\u043E\u0441\u0442\u043E \u0438\u043D\u043E\u0433\u0434\u0430 \u0431\u0440\u0443\u0442\u0430\u043B\u044C\u043D\u043E\u0435 \u043B\u0438\u0446\u043E \u0437\u0430\u0431\u044B\u0432\u0430\u044E \u0432\u044B\u043A\u043B\u044E\u0447\u0438\u0442\u044C :) \u043D\u0443 \u0438 \u044F \u0442\u0443\u0442 \u0441\u043B\u0430\u0436\u0430\u043B, \u043D\u0430\u0434\u043E \u0431\u044B\u043B\u043E \u0441 \u0448\u0443\u0442\u043E\u043A \u043D\u0430\u0447\u0438\u043D\u0430\u0442\u044C, \u043A\u043E\u043D\u0435\u0447\u043D\u043E",
  "id" : 148849366357131265,
  "in_reply_to_status_id" : 148848323028197376,
  "created_at" : "2011-12-19 19:37:09 +0000",
  "in_reply_to_screen_name" : "Yuusou1989",
  "in_reply_to_user_id_str" : "255977897",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrey Vinokurov",
      "screen_name" : "Yuusou1989",
      "indices" : [ 0, 11 ],
      "id_str" : "255977897",
      "id" : 255977897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "148839716194750465",
  "geo" : { },
  "id_str" : "148847768486678528",
  "in_reply_to_user_id" : 255977897,
  "text" : "@Yuusou1989 \u0414\u0430 \u044F \u0437\u043D\u0430\u044E. + \u043E\u043D\u0430 \u043D\u0430\u0432\u0435\u0440\u043D\u044F\u043A\u0430 \u0437\u0430\u043C\u0443\u0436\u0435\u043C \u0432 \u0435\u0435 \u0432\u043E\u0437\u0440\u0430\u0441\u0442\u0435, \u0441 \u0442\u0440\u0435\u0445 \u043C\u0435\u0442\u0440\u043E\u0432 \u043A\u0430\u0437\u0430\u043B\u0430\u0441\u044C \u043C\u043E\u043B\u043E\u0436\u0435 )",
  "id" : 148847768486678528,
  "in_reply_to_status_id" : 148839716194750465,
  "created_at" : "2011-12-19 19:30:48 +0000",
  "in_reply_to_screen_name" : "Yuusou1989",
  "in_reply_to_user_id_str" : "255977897",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/RA3lzhiB",
      "expanded_url" : "http:\/\/www.monicamagni.com\/",
      "display_url" : "monicamagni.com"
    } ]
  },
  "geo" : { },
  "id_str" : "148554366570344448",
  "text" : "\u0438 \u0437\u0432\u0435\u0437\u0434\u043D\u044B\u0439 \u0437\u0430\u043C\u0435\u0442\u0438\u043B \u044F \u0441\u0432\u0435\u0442 \u0438\u0437-\u043F\u043E\u0434 \u0440\u0435\u0441\u043D\u0438\u0446; \u043E\u0447\u0435\u043D\u044C \u043A\u0440\u0430\u0441\u0438\u0432\u0430\u044F \u043C\u043E\u0434\u0435\u043B\u044C \u0443 http:\/\/t.co\/RA3lzhiB . \u0438 \u043F\u043B\u0430\u0442\u044C\u044F \u043F\u0440\u0438\u044F\u0442\u043D\u044B\u0435, imho.",
  "id" : 148554366570344448,
  "created_at" : "2011-12-19 00:04:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/fDPTGzzY",
      "expanded_url" : "http:\/\/img.ly\/bCXQ",
      "display_url" : "img.ly\/bCXQ"
    }, {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/1w7e9kCs",
      "expanded_url" : "http:\/\/img.ly\/bCXS",
      "display_url" : "img.ly\/bCXS"
    } ]
  },
  "geo" : { },
  "id_str" : "148378220901842945",
  "text" : "http:\/\/t.co\/fDPTGzzY http:\/\/t.co\/1w7e9kCs",
  "id" : 148378220901842945,
  "created_at" : "2011-12-18 12:24:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "148194310720983040",
  "text" : "\u041E\u0431\u0445\u043E\u0434 \u0431\u043E\u043B\u044C\u0448\u0438\u0445 \u0438 \u043C\u0430\u043B\u044B\u0445 \u0431\u0430\u0440\u043E\u0432 \u0437\u0430\u0432\u0435\u0440\u0448\u0430\u0435\u0442\u0441\u044F \u0441\u0435\u0439\u0447\u0430\u0441 \u0432 \u0448\u0438\u043A\u0430\u0440\u043D\u043E\u0439 \u043A\u0432\u0430\u0440\u0442\u0438\u0440\u0435 \u0432 30 \u0448\u0430\u0433\u0430\u0445 \u043E\u0442 \u043F\u043E\u0434\u044A\u0435\u0437\u0434\u0430 \u041C\u0430\u0448\u0438. \u0421\u043E\u0432\u043F\u0430\u0434\u0435\u043D\u0438\u044F.",
  "id" : 148194310720983040,
  "created_at" : "2011-12-18 00:14:11 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/KzzZ2ltq",
      "expanded_url" : "http:\/\/4sq.com\/usEamm",
      "display_url" : "4sq.com\/usEamm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7632534224, 37.6069307327 ]
  },
  "id_str" : "148119401550450688",
  "text" : "All this time I've had automisspel turned on. (@ \u041F\u0438\u0446\u0446\u0430 \u042D\u043A\u0441\u043F\u0440\u0435\u0441\u0441 \/ Pizza Express w\/ 11 others) http:\/\/t.co\/KzzZ2ltq",
  "id" : 148119401550450688,
  "created_at" : "2011-12-17 19:16:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instantheartrate",
      "indices" : [ 84, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/bp3EeeXB",
      "expanded_url" : "http:\/\/goo.gl\/4x4uz",
      "display_url" : "goo.gl\/4x4uz"
    } ]
  },
  "geo" : { },
  "id_str" : "148015500667002881",
  "text" : "\u0414\u043E\u0441\u0438\u0436\u0438\u0432\u0430\u044E \u0443\u0447\u0435\u0442 \u0438 \u043E\u0442\u0447\u0435\u0442\u043D\u043E\u0441\u0442\u044C \u043D\u0430 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u043E\u043C \u0440\u044B\u043D\u043A\u0435 \u041C\u0421\u0424\u041E \u0432 \u0412\u0428\u042D. My heart rate is 77bpm. #instantheartrate http:\/\/t.co\/bp3EeeXB",
  "id" : 148015500667002881,
  "created_at" : "2011-12-17 12:23:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147984741025579008",
  "text" : "\u042F \u0431\u0443\u0434\u0443 \u043F\u043E\u043C\u043E\u0433\u0430\u0442\u044C \u0441 \u043A\u043E\u0434\u043E\u043C \u0432\u043E flex, \u041F\u0430\u0432\u043B\u0438\u043A - \u0441 \u0434\u0438\u0437\u0430\u0439\u043D\u043E\u043C. \u041E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u043F\u0440\u0438\u0432\u0438\u0442\u044C \u0435\u043C\u0443 \u0433\u0435\u0439\u043C\u0434\u0435\u0432 \u0447\u0443\u0432\u0441\u0442\u0432\u043E \u0432\u043A\u0443\u0441\u0430. Signo vinces11",
  "id" : 147984741025579008,
  "created_at" : "2011-12-17 10:21:26 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "147980169104211968",
  "text" : "\u0421 \u043F\u043E\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u0438\u043A\u0430 \u043D\u0430\u0447\u0438\u043D\u0430\u044E \u043F\u043E\u0438\u0441\u043A \u043A\u043E\u0434\u0435\u0440\u0430 \u0438 \u0434\u0438\u0437\u0430\u0439\u043D\u0435\u0440\u0430 \u0432 app \u0441\u0442\u0443\u0434\u0438\u044E \u0441 \u043A\u043E\u0434\u043E\u0432\u044B\u043C \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435\u043C Quotum.",
  "id" : 147980169104211968,
  "created_at" : "2011-12-17 10:03:16 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/Ezg8WcKp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=annJJOGyT2o",
      "display_url" : "youtube.com\/watch?v=annJJO\u2026"
    }, {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/VwlieZwd",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=4TXoGjYO7TY",
      "display_url" : "youtube.com\/watch?v=4TXoGj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "146484454528008193",
  "text" : "\u0441\u0430\u043C\u043E\u0435 \u0432\u0440\u0435\u043C\u044F \u043D\u0430\u0441\u043B\u0430\u0434\u0438\u0442\u044C\u0441\u044F \u043E\u0434\u043D\u0438\u043C \u0438\u0437 \u0433\u043B\u0430\u0432\u043D\u044B\u0445 \u043C\u0443\u0437\u044B\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u044F\u0432\u043B\u0435\u043D\u0438\u0439 - \u0413\u0415\u0419-\u0414\u0418\u0421\u041A\u041E. http:\/\/t.co\/Ezg8WcKp http:\/\/t.co\/VwlieZwd",
  "id" : 146484454528008193,
  "created_at" : "2011-12-13 06:59:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146483355901374464",
  "text" : "\u0432 \u0441\u0438\u043B\u0443 \u0442\u043E\u0433\u043E, \u0447\u0442\u043E \u0443 \u043C\u0435\u043D\u044F \u043D\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u0438\u0441\u043B\u0435\u043A\u0441\u0438\u044F, \u043D\u043E \u044F \u0435\u0449\u0435 \u0438 \u0434\u0435\u0431\u0438\u043B, \u0430\u043D\u0433\u043B \u043B\u0438\u0442\u0435\u0440\u0430\u0442\u0443\u0440\u0430 - \u0432\u0441\u0435\u0433\u0434\u0430 \u0431\u0443\u0434\u0435\u0442 \u043B\u0443\u0447\u0448\u0435\u0439 \u043F\u043E\u0434\u0440\u0443\u0433\u043E\u0439",
  "id" : 146483355901374464,
  "created_at" : "2011-12-13 06:55:28 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Fry",
      "screen_name" : "stephenfry",
      "indices" : [ 22, 33 ],
      "id_str" : "15439395",
      "id" : 15439395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146482316645109760",
  "text" : "\u041F\u0435\u0440\u0435\u0432\u043E\u0434 \u0430\u0432\u0442\u043E\u0431\u0438\u043E\u0433\u0440\u0430\u0444\u0438\u0439 @stephenfry \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u0438\u0439 \u043E\u0442\u0431\u0440\u0430\u0441\u044B\u0432\u0430\u0435\u0442 \u043F\u043E\u043B\u043E\u0432\u0438\u043D\u0443 \u0448\u0435\u043A\u0441\u043F\u0438\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u044F, \u0430 \u043F\u0438\u0442\u043E\u043D\u043E\u0432 - \u043C\u043E\u0436\u0435\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u0443\u043A\u0440\u0435\u043F\u0438\u0442\u044C \u043F\u0430\u0440\u043E\u043A\u0441\u0438\u0437\u043C\u043E\u043C \u0418\u043E\u043D\u0435\u0441\u043A\u043E",
  "id" : 146482316645109760,
  "created_at" : "2011-12-13 06:51:20 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146012887134113793",
  "text" : "\u0422\u0435\u043F\u0435\u0440\u044C \u0432\u0435\u0440\u043D\u0443\u043B \u0438 \u0434\u0437\u0435\u043D-\u0441\u043F\u043E\u043A\u043E\u0439\u0441\u0442\u0432\u0438\u0435. \u041F\u043E\u043B\u043E\u0432\u0438\u043D\u0430 \u0447\u0435\u0442\u0432\u0435\u0440\u0442\u043E\u0433\u043E \u0443\u0442\u0440\u0430 \u043F\u043E\u043D\u0435\u0434\u0435\u043B\u044C\u043D\u0438\u043A\u0430, \u043D\u043E \u0443\u0436\u0435 \u0448\u0435\u0441\u0442\u044C \u0447\u0430\u0441\u043E\u0432 \u0432 \u043E\u0444\u0438\u0441\u0435, surely it's a paradox )",
  "id" : 146012887134113793,
  "created_at" : "2011-12-11 23:45:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "146009659717853184",
  "text" : "\u041E\u043A\u0430\u0437\u0430\u043B\u043E\u0441\u044C, \u0447\u0442\u043E \u0437\u0430 \u0442\u0440\u0438 \u043C\u0435\u0441\u044F\u0446\u0430 \u044F \u0432\u043D\u043E\u0432\u044C \u043F\u043E\u0441\u0442\u0430\u0432\u0438\u043B \u0433\u043E\u043B\u043E\u0441, \u0440\u0430\u0441\u043A\u0430\u0447\u0430\u043B \u0440\u0443\u043A\u0438, \u0442\u0435\u0441\u0442\u043E\u0441\u0442\u0435\u0440\u043E\u043D, \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u0443\u044E \u0440\u0430\u0431\u043E\u0442\u0443 \u0438 \u0437\u0430\u0440\u0430\u0431\u043E\u0442\u0430\u043B \u0442\u0440\u0435\u0439\u0434\u0438\u043D\u0433\u043E\u043C \u0434\u0435\u043D\u044C\u0433\u0438 \u043D\u0430 \u0436\u0438\u0437\u043D\u044C.",
  "id" : 146009659717853184,
  "created_at" : "2011-12-11 23:33:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0447",
      "screen_name" : "informcentr",
      "indices" : [ 0, 12 ],
      "id_str" : "137856929",
      "id" : 137856929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145602067178856448",
  "geo" : { },
  "id_str" : "145608073879355392",
  "in_reply_to_user_id" : 137856929,
  "text" : "@informcentr \u043E\u043A, \u0441\u043F\u0430\u0441\u0438\u0431\u043E \u0437\u0430 \u0438\u043D\u0444\u043E\u0440\u043C. ) \u0437\u0430\u0439\u043C\u0443\u0441\u044C",
  "id" : 145608073879355392,
  "in_reply_to_status_id" : 145602067178856448,
  "created_at" : "2011-12-10 20:57:24 +0000",
  "in_reply_to_screen_name" : "informcentr",
  "in_reply_to_user_id_str" : "137856929",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0447",
      "screen_name" : "informcentr",
      "indices" : [ 0, 12 ],
      "id_str" : "137856929",
      "id" : 137856929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "145600871189848064",
  "geo" : { },
  "id_str" : "145601479913373696",
  "in_reply_to_user_id" : 137856929,
  "text" : "@informcentr \u0434\u0430, \u0430 \u043E\u0442\u0442\u0443\u0434\u0430 \u043D\u0435\u043B\u044C\u0437\u044F? \u044F \u0432\u043E\u043E\u0431\u0449\u0435 \u0441 \u043F\u0440\u043E\u0446\u0435\u0434\u0443\u0440\u043E\u0439 \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0430 \u043F\u043E\u043A\u0430 \u043D\u0435 \u0437\u043D\u0430\u043A\u043E\u043C, \u043D\u043E \u0437\u0434\u0440\u0430\u0432\u044B\u0439 \u0441\u043C\u044B\u0441\u043B \u043F\u043E\u0434\u0441\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442, \u0447\u0442\u043E \u043F\u043E\u0434\u043E\u0431\u043D\u0430\u044F \u0434\u043E\u043B\u0436\u043D\u0430 \u0431\u044B\u0442\u044C",
  "id" : 145601479913373696,
  "in_reply_to_status_id" : 145600871189848064,
  "created_at" : "2011-12-10 20:31:12 +0000",
  "in_reply_to_screen_name" : "informcentr",
  "in_reply_to_user_id_str" : "137856929",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145593563890196480",
  "text" : "breaking news: \u0430 \u043D\u0435 \u043F\u0435\u0440\u0435\u0432\u0435\u0441\u0442\u0438\u0441\u044C \u043B\u0438 \u043C\u043D\u0435 \u0432 \u0430\u0441\u043F\u0443 \u043D\u0430 \u0424\u0424?",
  "id" : 145593563890196480,
  "created_at" : "2011-12-10 19:59:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "145593465244352512",
  "text" : "\u043D\u0435 \u043C\u043E\u0433\u0443 \u0431\u044B\u0442\u044C \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u044B\u043C \u0432 \u0441\u0432\u043E\u0435\u043C \u043D\u0435\u043F\u0440\u0438\u044F\u0442\u0438\u0438 \u0434\u0432\u0438\u0436\u0435\u043D\u0438\u044F \u043C\u0430\u0440\u0448\u0440\u0443\u0442\u0430\u043C\u0438, \u043E\u0447\u0435\u0440\u0447\u0435\u043D\u043D\u044B\u043C\u0438 \u043F\u043E\u043B\u0438\u0446\u0435\u0439\u0441\u043A\u0438\u043C\u0438 \u0442\u0435\u043B\u0430\u043C\u0438",
  "id" : 145593465244352512,
  "created_at" : "2011-12-10 19:59:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupykremlin",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144806554674274304",
  "text" : "\u043F\u043E\u043D\u044F\u0442\u043D\u043E, \u0447\u0442\u043E \u043F\u043B\u043E\u0449\u0430\u0434\u044C \u0431\u0443\u0434\u0435\u0442 \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u043F\u0435\u0440\u0435\u043A\u0440\u044B\u0442\u0430. #occupykremlin",
  "id" : 144806554674274304,
  "created_at" : "2011-12-08 15:52:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.instantheartrate.com\" rel=\"nofollow\"\u003EInstant Heart Rate\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144549615000240128",
  "text" : "My Heart Rate is 62.",
  "id" : 144549615000240128,
  "created_at" : "2011-12-07 22:51:28 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "144546653318295553",
  "text" : "\u043E\u0431 \u0443\u0441\u043F\u0435\u0445\u0430\u0445 \u043A\u0430\u0440\u0434\u0438\u043E\u0442\u0435\u0440\u0430\u043F\u0438\u0438: \u043F\u043E\u0442\u0440\u0443\u0434\u0438\u043B\u0441\u044F \u0437\u0430\u0431\u044B\u0442\u044C \u0438\u043C\u044F, \u043D\u043E\u043C\u0435\u0440 \u0438 \u043D\u0438\u043A\u043D\u0435\u0439\u043C, \u0443\u0434\u0430\u043B\u0438\u043B \u0438\u0437 \u0432\u043E\u0441\u043F\u043E\u043C\u0438\u043D\u0430\u043D\u0438\u0439 \u0438 \u043E\u0431\u0435\u0437\u0431\u043E\u043B\u0438\u043B.",
  "id" : 144546653318295553,
  "created_at" : "2011-12-07 22:39:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 136 ],
      "url" : "http:\/\/t.co\/yaC9hOz",
      "expanded_url" : "http:\/\/4sq.com\/w1bQMO",
      "display_url" : "4sq.com\/w1bQMO"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7721195777, 37.5929617882 ]
  },
  "id_str" : "144348505664786432",
  "text" : "You say, \"Do you want a cup of coffee?\" and she says, \"Yeah, okay.\" Then sex is on, yes? Doesn't always work, though http:\/\/t.co\/yaC9hOz",
  "id" : 144348505664786432,
  "created_at" : "2011-12-07 09:32:20 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "144155192093446145",
  "geo" : { },
  "id_str" : "144313492399325184",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u043D\u0430 \u0432\u044B\u0445\u043E\u0434\u043D\u044B\u0445 \u043F\u0440\u0438\u0441\u043D\u0438\u043B\u043E\u0441\u044C \u043E\u0437\u0435\u0440\u043E, \u0434\u043B\u0438\u043D\u043D\u044B\u0435 \u0441\u044A\u0435\u0434\u043E\u0431\u043D\u044B\u0435 \u043B\u0438\u0441\u0442\u044C\u044F \u0438 \u0442\u0432\u043E\u0439 \u0433\u043E\u043B\u043E\u0441, \u0440\u0430\u0441\u0441\u043A\u0430\u0437\u044B\u0432\u0430\u044E\u0449\u0438\u0439 \u043E \u0431\u0430\u0431\u0443\u0448\u043A\u0435. :|",
  "id" : 144313492399325184,
  "in_reply_to_status_id" : 144155192093446145,
  "created_at" : "2011-12-07 07:13:12 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 134 ],
      "url" : "http:\/\/t.co\/HwM9mb4",
      "expanded_url" : "http:\/\/4sq.com\/vGJHfN",
      "display_url" : "4sq.com\/vGJHfN"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.801768, 37.531735 ]
  },
  "id_str" : "143692352580616192",
  "text" : "\u0412\u044B\u043F\u0435\u0441\u0442\u043E\u0432\u0430\u043B \u0432\u0441\u0435\u043C \u043B\u0435\u043C\u043C\u0438\u043D\u0433\u0430\u043C \u0441\u0432\u043E\u0439 \u0443\u043D\u044B\u043B\u044B\u0439 \u043E\u0441\u0442\u0440\u043E\u0432\u043D\u043E\u0439 \u0442\u0440\u0430\u0433\u0438\u0437\u043C, \u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u0432\u044B\u043F\u043E\u0432\u0435\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C. (@ \u0413\u0430\u043B\u0435\u0440\u0435\u044F \u0410\u044D\u0440\u043E\u043F\u043E\u0440\u0442 w\/ 3 others) http:\/\/t.co\/HwM9mb4",
  "id" : 143692352580616192,
  "created_at" : "2011-12-05 14:05:01 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 56 ],
      "url" : "http:\/\/t.co\/aqOcmtp",
      "expanded_url" : "http:\/\/cgsh.ru\/tee4.png",
      "display_url" : "cgsh.ru\/tee4.png"
    }, {
      "indices" : [ 63, 82 ],
      "url" : "http:\/\/t.co\/xHfXlWK",
      "expanded_url" : "http:\/\/cgsh.ru\/tee4b.png",
      "display_url" : "cgsh.ru\/tee4b.png"
    } ]
  },
  "geo" : { },
  "id_str" : "143428379306246144",
  "text" : "\u0441\u0435\u0433\u043E\u0434\u043D\u044F \u0445\u043E\u0434\u0438\u043B \u0432 diy \u0444\u0443\u0442\u0431\u043E\u043B\u043A\u0435: front: http:\/\/t.co\/aqOcmtp back: http:\/\/t.co\/xHfXlWK",
  "id" : 143428379306246144,
  "created_at" : "2011-12-04 20:36:05 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]