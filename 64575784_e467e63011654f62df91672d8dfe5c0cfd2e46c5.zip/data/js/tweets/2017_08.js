Grailbird.data.tweets_2017_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/W57KlpAcdK",
      "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Fast_inverse_square_root",
      "display_url" : "en.wikipedia.org\/wiki\/Fast_inve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "900279069102747648",
  "text" : "https:\/\/t.co\/W57KlpAcdK",
  "id" : 900279069102747648,
  "created_at" : "2017-08-23 08:50:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/Zui6qSXU8T",
      "expanded_url" : "https:\/\/shz.am\/t44491547",
      "display_url" : "shz.am\/t44491547"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.742153, 37.583057 ]
  },
  "id_str" : "900088475214635013",
  "text" : "Louie Austen - Rain https:\/\/t.co\/Zui6qSXU8T",
  "id" : 900088475214635013,
  "created_at" : "2017-08-22 20:13:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Q38RGmTdww",
      "expanded_url" : "https:\/\/habr.ru\/p\/334394",
      "display_url" : "habr.ru\/p\/334394"
    } ]
  },
  "geo" : { },
  "id_str" : "899620177599451136",
  "text" : "https:\/\/t.co\/Q38RGmTdww",
  "id" : 899620177599451136,
  "created_at" : "2017-08-21 13:12:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/vBtu4Uky64",
      "expanded_url" : "https:\/\/shz.am\/t6013705",
      "display_url" : "shz.am\/t6013705"
    } ]
  },
  "geo" : { },
  "id_str" : "897910487198969856",
  "text" : "The Turtles - You Showed Me https:\/\/t.co\/vBtu4Uky64",
  "id" : 897910487198969856,
  "created_at" : "2017-08-16 19:58:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/bAAbqdr2OX",
      "expanded_url" : "https:\/\/shz.am\/t270856820",
      "display_url" : "shz.am\/t270856820"
    } ]
  },
  "geo" : { },
  "id_str" : "896791261776150530",
  "text" : "Descemer Bueno &amp; Issac Delgado - La Vida Es Buena https:\/\/t.co\/bAAbqdr2OX",
  "id" : 896791261776150530,
  "created_at" : "2017-08-13 17:51:13 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MessageToVoyager",
      "indices" : [ 98, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "894474430361067520",
  "text" : "Hello, my name is Anton Gorbunov and I have stroke&amp;paralysis at my 28. what more can be said? #MessageToVoyager",
  "id" : 894474430361067520,
  "created_at" : "2017-08-07 08:24:57 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]