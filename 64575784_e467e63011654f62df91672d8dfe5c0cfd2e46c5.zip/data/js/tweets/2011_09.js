Grailbird.data.tweets_2011_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114835570345263104",
  "text" : "\u0421\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0441 \u0441\u0430\u0439\u0442\u0430 reiss.ru : IP \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u0442\u0435\u043B\u044F: * \u0418\u043C\u044F: * E-mail: * I want to buy this domain  &lt;&lt; echo meh, okey.jpg",
  "id" : 114835570345263104,
  "created_at" : "2011-09-16 22:58:28 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114827716477456384",
  "text" : "\u043F\u043E\u044D\u0442\u043E\u043C\u0443 \u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0430\u044E \u043D\u0430\u0433\u0432\u0430\u043B\u044C\u043D\u043E\u0433\u043E, \u0445\u0438\u043C\u043A\u0438\u043D\u0441\u043A\u0438\u0439 \u043B\u0435\u0441\u0431\u043E\u0441 \u0438 \u0441\u0442\u0440\u0430\u0442\u0435\u0433\u0438\u044E 23 \u0432 \u0437\u0434\u0430\u043D\u0438\u0435 \u0444\u043E\u043D\u0434\u0430 \u043F\u0430\u0442\u0440\u0438\u043E\u0442\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u043A\u0438\u043D\u043E )",
  "id" : 114827716477456384,
  "created_at" : "2011-09-16 22:27:15 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "114824126849495041",
  "text" : "\u043F\u043E\u0441\u043B\u0435 \u043B\u0435\u043A\u0446\u0438\u0438 \u043F\u043E \u043C\u0430\u0442\u0430\u043D\u0443. \u0432 \u041D\u041C\u0423, \u0434\u0432\u0430 \u0447\u0430\u0441\u0430 \u043E\u0431\u0449\u0430\u043B\u0441\u044F \u0432 \u043E\u0444\u0438\u0441\u0435 \u043D\u0430 \u043C\u0430\u044F\u043A\u043E\u0432\u0441\u043A\u043E\u0439, \u0433\u0434\u0435 \u043A\u0440\u0443\u0433\u043B\u044B\u0435 \u0441\u0443\u0442\u043A\u0438 \u043F\u0438\u0448\u0443\u0442\u0441\u044F \u043A\u0430\u043C\u0435\u043D\u0442\u044B \u0437\u0430 \u043F\u0440\u0430\u0432\u044F\u0449\u0438\u0439 \u0440\u0435\u0436\u0438\u043C. kinda bizarre",
  "id" : 114824126849495041,
  "created_at" : "2011-09-16 22:12:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "113366518263320576",
  "text" : "\u0445\u043E\u0442\u044C \u0438 \u0437\u0430\u0431\u044B\u043B \u043F\u043E\u043D\u044F\u0442\u0438\u0435 \u043D\u0435\u0443\u0434\u0430\u0447\u0438 \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043A \u0441\u0435\u0431\u0435 - \u0434\u0435\u043D\u044C \u0431\u044B\u043B, \u043E\u0442\u043A\u0440\u043E\u0432\u0435\u043D\u043D\u043E \u0433\u043E\u0432\u043E\u0440\u044F, \u043D\u0438 \u043A \u0447\u0435\u0440\u0442\u0443 :\\",
  "id" : 113366518263320576,
  "created_at" : "2011-09-12 21:40:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 30 ],
      "url" : "http:\/\/t.co\/kZ7ocyd",
      "expanded_url" : "http:\/\/www.pixeljoint.com\/files\/icons\/full\/isocastle.png",
      "display_url" : "pixeljoint.com\/files\/icons\/fu\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "112988944668442624",
  "text" : "iso castle http:\/\/t.co\/kZ7ocyd",
  "id" : 112988944668442624,
  "created_at" : "2011-09-11 20:40:38 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 76 ],
      "url" : "http:\/\/t.co\/AzaW800",
      "expanded_url" : "http:\/\/instagr.am\/p\/MuJNe\/",
      "display_url" : "instagr.am\/p\/MuJNe\/"
    } ]
  },
  "geo" : { },
  "id_str" : "112644980132167681",
  "text" : "Simon the Sorcerer II: Lion, the Wizard and the Wardrobe http:\/\/t.co\/AzaW800 AS 1995, \u043D\u0430\u0437\u0432. \u043F\u0430\u0440\u043E\u0434\u0438\u0440\u0443\u0435\u0442 \u043A\u043D\u0438\u0433\u0443 \u041A\u043B\u0430\u0439\u0432\u0430 \u041B\u044C\u044E\u0438\u0441\u0430",
  "id" : 112644980132167681,
  "created_at" : "2011-09-10 21:53:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 55 ],
      "url" : "http:\/\/t.co\/Qx5udUJ",
      "expanded_url" : "http:\/\/instagr.am\/p\/MshVZ\/",
      "display_url" : "instagr.am\/p\/MshVZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "112629608209330176",
  "text" : "\u0437\u0430\u043F\u043E\u0437\u0434\u0430\u043B\u0430\u044F \u0444\u043E\u0442\u043A\u0430 \u0441 \u0432\u0435\u0433\u0430\u043D\u0441\u043A\u0438\u043C \u0443\u0436\u0438\u043D\u043E\u043C http:\/\/t.co\/Qx5udUJ",
  "id" : 112629608209330176,
  "created_at" : "2011-09-10 20:52:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/bHB8Mjc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=KhINU1ldZ-4",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    }, {
      "indices" : [ 27, 46 ],
      "url" : "http:\/\/t.co\/me8alAg",
      "expanded_url" : "http:\/\/smart-lab.ru\/uploads\/images\/00\/03\/11\/2011\/09\/05\/86e36d.png",
      "display_url" : "smart-lab.ru\/uploads\/images\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "112523615811022848",
  "text" : "http:\/\/t.co\/bHB8Mjc gj wp, http:\/\/t.co\/me8alAg \u043F\u0430\u0442\u0442\u0435\u0440\u043D\u044B \u0413\u0430\u0440\u0442\u043B\u0438, \u0433\u043E\u0432\u043E\u0440\u0438\u0442\u0435? ;)",
  "id" : 112523615811022848,
  "created_at" : "2011-09-10 13:51:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112475956672864256",
  "text" : "\u0441\u0442\u0430\u0441 \u043C\u0438\u0445\u0430\u0439\u043B\u043E\u0432 \u0438 \u043E\u0445\u043B\u043E\u0431\u044B\u0441\u0442\u0438\u043D - \u0434\u043B\u044F \u043C\u0435\u043D\u044F \u044D\u0442\u043E \u0434\u0432\u0430 \u043F\u0440\u043E\u0431\u0435\u043B\u0430, \u0442.\u0435. \" \" \u0438 \" \", \u043D\u0435\u0438\u0437\u0432\u0435\u0441\u0442\u043D\u043E \u043D\u0430\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043D\u0435\u0440\u0430\u0437\u0440\u044B\u0432\u043D\u044B\u0445.",
  "id" : 112475956672864256,
  "created_at" : "2011-09-10 10:42:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "112473997240832000",
  "text" : "pathetic logic spamer, as a rule, he just never touches anything more sophisticated and delicate than himself",
  "id" : 112473997240832000,
  "created_at" : "2011-09-10 10:34:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111868381346529282",
  "text" : "\u0430 \u0441 \u041F\u043E\u043B\u043E\u043C \u0414\u0436\u0430\u043C\u0430\u0442\u0442\u0438, \u0438\u0433\u0440\u0430\u044E\u0449\u0438\u043C \u0435\u0433\u043E \u0432 TBTF - \u043E\u0431\u0435\u0434\u0430\u043B \u0432 \u0437\u0434\u0430\u043D\u0438\u0438 \u0424\u0420\u0421, \u0433\u0434\u0435 \u0443\u0437\u043D\u0430\u043B \u0442\u0430\u043A\u0436\u0435, \u0447\u0442\u043E \u0435\u0433\u043E \u043E\u0442\u0435\u0446 \u0431\u044B\u043B \u043F\u0440\u0435\u0437\u0438\u0434\u0435\u043D\u0442\u043E\u043C \u0413\u043B\u0430\u0432\u043D\u043E\u0439 \u043B\u0438\u0433\u0438 \u0431\u0435\u0439\u0441\u0431\u043E\u043B\u0430.",
  "id" : 111868381346529282,
  "created_at" : "2011-09-08 18:27:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "111867310414888962",
  "text" : "\u0411\u0435\u0440\u043D\u0430\u043D\u043A\u0435 \u043D\u0430 \u0438\u0440\u043E\u043D\u0438\u0447\u043D\u044B\u0439 \u0432\u043E\u043F\u0440\u043E\u0441 \u043F\u0440\u043E \u0444\u0438\u043B\u044C\u043C Too big to fail, \u0441\u043A\u0430\u0437\u0430\u043B, \u0447\u0442\u043E \u0444\u0438\u043B\u044C\u043C\u0430 \u043D\u0435 \u0432\u0438\u0434\u0435\u043B, \u0437\u0430\u0442\u043E \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u043B \u0432\u0441\u0435 \u0441\u043E\u0431\u044B\u0442\u0438\u044F \u0432 \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438 )",
  "id" : 111867310414888962,
  "created_at" : "2011-09-08 18:23:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/VAdRH23",
      "expanded_url" : "http:\/\/www.cnbc.com\/id\/24596546",
      "display_url" : "cnbc.com\/id\/24596546"
    } ]
  },
  "geo" : { },
  "id_str" : "111863132657430529",
  "text" : "http:\/\/t.co\/VAdRH23 \u0442\u0440\u0430\u043D\u0441\u043B\u044F\u0446\u0438\u044F \u0432\u044B\u0441\u0442\u0443\u043F\u043B\u0435\u043D\u0438\u044F \u0411\u0435\u043D\u0430 \u0411\u0435\u0440\u043D\u0430\u043D\u043A\u0435",
  "id" : 111863132657430529,
  "created_at" : "2011-09-08 18:07:03 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110804272899301376",
  "geo" : { },
  "id_str" : "110807182638972928",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u0441\u043A\u0430\u0447\u0430\u043B, \u0437\u0430\u0432\u0442\u0440\u0430 \u0437\u0430\u0440\u0443\u0431\u043B\u044E\u0441\u044C \u0434\u0432\u0430 \u043D\u0430 \u0434\u0432\u0430 \u0441 \u0443\u043C\u043F\u0430-\u043B\u0443\u043C\u043F\u0430\u043C\u0438 \u043D\u0430 \u0440\u0430\u0431\u043E\u0442\u0435",
  "id" : 110807182638972928,
  "in_reply_to_status_id" : 110804272899301376,
  "created_at" : "2011-09-05 20:11:05 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110790835913760768",
  "geo" : { },
  "id_str" : "110801348152401920",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u0432\u0441\u0435 \u0441\u043C\u0435\u044F\u043B\u0438\u0441\u044C \u0442\u043A \u043A\u0443\u043F\u0435\u0446 \u0438 \u043F\u0443\u0442\u0435\u0448\u0435\u0441\u0442\u0432\u0435\u043D\u043D\u0438\u043A \u043C\u0430\u0440\u043A\u043E \u043F\u043E\u043B\u043E \u043F\u043E\u043A\u0430\u0437\u0430\u043D \u0432\u043C\u0435\u0441\u0442\u0435 \u0441 \u043C\u0430\u0442\u0435\u0440\u044B\u043C \u043F\u0438\u0440\u0430\u0442\u043E\u043C \u0444\u0440\u044D\u043D\u0441\u0438\u0441\u043E\u043C \u0434\u0440\u0435\u0439\u043A\u043E\u043C, \u0445\u043E\u0442\u044F \u043E\u043D\u0438 \u0438 \u0436\u0438\u043B\u0438 \u0432 \u0440\u0430\u0437\u043D\u044B\u0435 \u044D\u043F\u043E\u0445\u0438?",
  "id" : 110801348152401920,
  "in_reply_to_status_id" : 110790835913760768,
  "created_at" : "2011-09-05 19:47:54 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110796304027881473",
  "text" : "\u041F\u043E\u043A\u0430 \u041B\u0435\u0439\u043D \u0441 \u0434\u0440\u0443\u0433\u043E\u043C \u043D\u0430\u0438\u0432\u043D\u043E \u0432\u044B\u0442\u0430\u0441\u043A\u0438\u0432\u0430\u043B\u0438 \u0437\u0430 \u0441\u0432\u043E\u0438 \u0434\u0435\u043D\u044C\u0433\u0438 Trader monthly, \u0433\u0435\u0440\u043E\u0438 WS \u0442\u0440\u0430\u0442.\u0441\u0442\u043E\u043C\u0438\u043B\u043B\u0438\u043E\u043D\u043D\u044B\u0435 \u043A\u0440\u0435\u0434\u0438\u0442\u044B \u043F\u043E\u0434 \u0438\u043F\u043E\u0442\u0435\u0447\u043D\u044B\u0439 \u043C\u0443\u0441\u043E\u0440 \u0438 \u043A\u043E\u043C\u0438\u0441\u0441\u0438\u0438 2+20",
  "id" : 110796304027881473,
  "created_at" : "2011-09-05 19:27:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110794386924765185",
  "text" : "(\u0432 \u0442\u043E \u0432\u0440\u0435\u043C\u044F \u043A\u0430\u043A \u0432 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u0435: My Misadventures in the Decade WS Went Insane). \u041A\u043D\u0438\u0433\u0430 \u0437\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0435\u0442\u0441\u044F \u0433\u043B\u0443\u0445\u0438\u043C \u0432\u0437\u0440\u044B\u0432\u043E\u043C \u0447\u0438\u0441\u0442\u043E\u0433\u043E \u043D\u0435\u0433\u0430\u0442\u0438\u0432\u0430, \u043E\u0446\u0435\u043D\u0438\u043B.",
  "id" : 110794386924765185,
  "created_at" : "2011-09-05 19:20:14 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110791533938212864",
  "text" : "\u0417\u0430 \u0442\u0440\u0438 \u0434\u043E\u043B\u0433\u0438\u0445 \u0431\u0435\u0441\u0441\u043E\u043D\u043D\u044B\u0445 \u0432\u0435\u0447\u0435\u0440\u0430 \u043F\u0440\u043E\u0447\u0435\u043B \u0434\u043E \u043A\u043E\u0440\u043A\u0438 \u043A\u043D\u0438\u0433\u0443 - \u0420\u044D\u043D\u0434\u0430\u043B\u043B \u041B\u0435\u0439\u043D \"\u041D\u0443\u043B\u0435\u0432\u044B\u0435 \u0438\u043B\u0438 \u0414\u0435\u0441\u044F\u0442\u044C \u043B\u0435\u0442 \u0431\u0435\u0437\u0443\u043C\u0438\u044F \u0423\u043E\u043B\u043B-\u0441\u0442\u0440\u0438\u0442 \u0433\u043B\u0430\u0437\u0430\u043C\u0438 \u043E\u0447\u0435\u0432\u0438\u0434\u0446\u0430\"",
  "id" : 110791533938212864,
  "created_at" : "2011-09-05 19:08:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110402816538972161",
  "text" : "\u0447\u0442\u043E I wonder if \u0432\u044B\u043F\u0443\u0441\u0442\u044F\u0442 \u043A \u0413\u043B\u0430\u0432\u043D\u043E\u043C\u0443 \u0417\u0434\u0430\u043D\u0438\u044E \u0434\u0435\u043B\u0435\u0433\u0430\u0446\u0438\u044E \u0442\u0440\u0435\u043D\u043E\u0436\u043D\u0438\u043A\u043E\u0432 \u043D\u0430 \u043B\u0430\u0437\u0435\u0440\u043D\u043E\u0435 \u0448\u043E\u0443 \u0438\u043B\u0438 \u0441\u043F\u0440\u0430\u0432\u044F\u0442\u0441\u044F \u0440\u0443\u0447\u043D\u044B\u043C\u0438 \u0431\u043B\u0430\u0441\u0442\u0435\u0440\u0430\u043C\u0438 \u0438\u0437 star trek?",
  "id" : 110402816538972161,
  "created_at" : "2011-09-04 17:24:17 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110402604672094208",
  "text" : "\u041C\u0435\u0442\u0440\u043E \u0442\u0430\u043A \u0437\u0430\u0431\u0438\u0442\u043E \u043C\u043E\u0441\u043A\u0432\u0438\u0447\u0430\u043C\u0438,",
  "id" : 110402604672094208,
  "created_at" : "2011-09-04 17:23:26 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "110393650860666882",
  "text" : "\u0414\u0432\u0430 \u043A\u0435\u0439\u0441\u0430: 1. \u0437\u0430\u0432\u0442\u0440\u0430 \u0434\u043E\u043B\u0436\u0435\u043D \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0434\u043E 19, \u0430 \u0432 17 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u0432 \u043D\u043C\u0443 2. \u0435\u0441\u0442\u044C \u043C\u0435\u0441\u0442\u043E \u0432 \u0434\u0438\u043B\u0438\u043D\u0433\u043E\u0432\u043E\u043C \u0437\u0430\u043B\u0435 \u0434\u043E nyse \u0441 \u043F\u0440\u043E\u043F, \u043D\u043E \u043D\u0435 \u043D\u0430 \u0447\u0442\u043E \u0442\u043E\u0440\u0433\u043E\u0432\u0430\u0442\u044C",
  "id" : 110393650860666882,
  "created_at" : "2011-09-04 16:47:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0421\u0435\u0440\u0433\u0435\u0439 \u041C\u0438\u043D\u0430\u0435\u0432",
      "screen_name" : "SergeiMinaev",
      "indices" : [ 0, 13 ],
      "id_str" : "52230224",
      "id" : 52230224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "110357240401244161",
  "geo" : { },
  "id_str" : "110384022756134912",
  "in_reply_to_user_id" : 52230224,
  "text" : "@SergeiMinaev \u0445\u043E\u0442\u0435\u043B \u0431\u044B \u0443\u0432\u0438\u0434\u0435\u0442\u044C \u0421\u043E\u0440\u043E\u043A\u0438\u043D\u0430 \u0438 \u041F\u0435\u043F\u043F\u0435\u0440\u0448\u0442\u0435\u0439\u043D\u0430",
  "id" : 110384022756134912,
  "in_reply_to_status_id" : 110357240401244161,
  "created_at" : "2011-09-04 16:09:36 +0000",
  "in_reply_to_screen_name" : "SergeiMinaev",
  "in_reply_to_user_id_str" : "52230224",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "109739738851835904",
  "text" : "\u043F\u0440\u0438\u0447\u0435\u043C \u043D\u0430 yt \u0437\u0430\u043C\u0435\u0447\u0435\u043D\u044B \u043F\u0440\u043E\u0447\u0438\u0435 \u0430\u043B\u044C\u0442\u0435\u0440\u043D\u0430\u0442\u0438\u0432\u043D\u044B\u0435 \u0441\u0440\u0435\u0437\u044B \u0433\u0435\u0439\u043C\u043F\u043B\u0435\u044F stacking, \u0432 \u0442\u0447 hack&slash. got to make gf sequel, lah-de-dah basterds :\\",
  "id" : 109739738851835904,
  "created_at" : "2011-09-02 21:29:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TimOfLegend &:Y\u007D",
      "screen_name" : "TimOfLegend",
      "indices" : [ 47, 59 ],
      "id_str" : "24585498",
      "id" : 24585498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 80 ],
      "url" : "http:\/\/t.co\/ETkEjPM",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=gddBHzy5ByU",
      "display_url" : "youtube.com\/watch?v=gddBHz\u2026"
    }, {
      "indices" : [ 103, 122 ],
      "url" : "http:\/\/t.co\/umRSKcH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=AiH1bjc6xDI",
      "display_url" : "youtube.com\/watch?v=AiH1bj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "109734358386081793",
  "text" : "\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442\u0441\u044F, \u043E\u0434\u043D\u0430 \u0438\u0437 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0445 deranged \u0438\u0433\u0440 \u043E\u0442 @TimOfLegend (http:\/\/t.co\/ETkEjPM) - \u043F\u0440\u043E \u0436\u0438\u0437\u043D\u044C \u043C\u0430\u0442\u0440\u0435\u0448\u0435\u043A http:\/\/t.co\/umRSKcH",
  "id" : 109734358386081793,
  "created_at" : "2011-09-02 21:08:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lou",
      "screen_name" : "lyubov_orlova",
      "indices" : [ 0, 14 ],
      "id_str" : "24216913",
      "id" : 24216913
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "109661176773869569",
  "geo" : { },
  "id_str" : "109670837002584064",
  "in_reply_to_user_id" : 24216913,
  "text" : "@lyubov_orlova \u043F\u043E\u0436\u0430\u0440\u044E rib eye \u0435\u0439, strip loin \u0441\u0435\u0431\u0435, \u043A\u0443\u043F\u043B\u044E \u0432\u0441\u0435 \u0432\u0438\u0434\u044B \u0442\u0440\u0430\u0432, \u0441\u0430\u043B\u0430\u0442\u0430 \u0438 \u043E\u0440\u0435\u0445\u0438. \u041A\u043E\u0433\u0434\u0430 \u043E\u043D\u0430 \u0432\u043E \u043C\u043D\u0435 \u0440\u0430\u0437\u043E\u0447\u0430\u0440\u0443\u0435\u0442\u0441\u044F, \u043E\u0442\u0434\u0430\u043C \u0435\u0439 \u0441\u0443\u0448\u0438.",
  "id" : 109670837002584064,
  "in_reply_to_status_id" : 109661176773869569,
  "created_at" : "2011-09-02 16:55:39 +0000",
  "in_reply_to_screen_name" : "lyubov_orlova",
  "in_reply_to_user_id_str" : "24216913",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]