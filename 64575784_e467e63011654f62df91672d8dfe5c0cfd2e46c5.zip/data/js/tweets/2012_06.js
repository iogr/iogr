Grailbird.data.tweets_2012_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "218679685951930368",
  "text" : "Guatemala Antigua",
  "id" : 218679685951930368,
  "created_at" : "2012-06-29 12:17:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217276082209046528",
  "text" : "\u041C\u043D\u0435 \u043E\u0447\u0435\u043D\u044C \u043D\u0440\u0430\u0432\u0438\u0442\u0441\u044F \u043A\u043E\u043C\u0435\u0434\u0438\u0439\u043D\u044B\u0439 \u043F\u0440\u0438\u0435\u043C, \u0441\u0432\u044F\u0437\u0430\u043D\u043D\u044B\u0439 \u0441 \u0441\u0430\u043C\u043E\u0443\u043D\u0438\u0447\u0438\u0436\u0435\u043D\u0438\u0435\u043C, \u043D\u043E \u043E\u043D \u0443 \u043C\u0435\u043D\u044F \u043F\u043B\u043E\u0445\u043E \u043F\u043E\u043B\u0443\u0447\u0430\u0435\u0442\u0441\u044F.",
  "id" : 217276082209046528,
  "created_at" : "2012-06-25 15:20:29 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "217230099362226176",
  "text" : "\u042F \u0445\u043E\u0447\u0443 \u0436\u0438\u0442\u044C \u0431\u0435\u0437 \u0433\u043E\u0441\u0443\u0434\u0430\u0440\u0441\u0442\u0432\u0430 \u0432 \u043B\u044E\u0431\u044B\u0445 \u0435\u0433\u043E \u043F\u0440\u043E\u044F\u0432\u043B\u0435\u043D\u0438\u044F\u0445 \u0438 \u044F \u043D\u0435 \u0445\u043E\u0447\u0443, \u0447\u0442\u043E\u0431\u044B \u043B\u044E\u0434\u0438 \u0432\u0430\u0440\u0438\u043B\u0438\u0441\u044C \u0432 \u0447\u0430\u043D\u0430\u0445 \u0441 \u043C\u0430\u0441\u043B\u043E\u043C \u0440\u0430\u0434\u0438 \u0440\u0435\u0437\u0430\u043D\u043D\u043E\u0439 \u0431\u0443\u043C\u0430\u0433\u0438.",
  "id" : 217230099362226176,
  "created_at" : "2012-06-25 12:17:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/O8GFevXk",
      "expanded_url" : "http:\/\/instagr.am\/p\/MRJuPIK9A8\/",
      "display_url" : "instagr.am\/p\/MRJuPIK9A8\/"
    } ]
  },
  "geo" : { },
  "id_str" : "216972921032290305",
  "text" : "Just posted a photo http:\/\/t.co\/O8GFevXk",
  "id" : 216972921032290305,
  "created_at" : "2012-06-24 19:15:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 52, 63 ],
      "id_str" : "804341497441255424",
      "id" : 804341497441255424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/Q85qguTq",
      "expanded_url" : "http:\/\/4sq.com\/KswMie",
      "display_url" : "4sq.com\/KswMie"
    } ]
  },
  "geo" : { },
  "id_str" : "211892642508845058",
  "text" : "I just reached Level 4 of the \"Fresh Brew\" badge on @foursquare. I\u2019ve checked in at 15 different coffee shops! http:\/\/t.co\/Q85qguTq",
  "id" : 211892642508845058,
  "created_at" : "2012-06-10 18:48:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/M6bYFxYl",
      "expanded_url" : "http:\/\/instagr.am\/p\/LsEE8Yq9Ps\/",
      "display_url" : "instagr.am\/p\/LsEE8Yq9Ps\/"
    } ]
  },
  "geo" : { },
  "id_str" : "211757640370495488",
  "text" : "Challenge day  http:\/\/t.co\/M6bYFxYl",
  "id" : 211757640370495488,
  "created_at" : "2012-06-10 09:52:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0432\u0441\u0435\u0433\u0434\u0430 \u0442\u0430\u043A \u0434\u0435\u043B\u0430\u044E!",
      "screen_name" : "romandos",
      "indices" : [ 0, 9 ],
      "id_str" : "75751947",
      "id" : 75751947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "209024273430487041",
  "geo" : { },
  "id_str" : "209028417193119744",
  "in_reply_to_user_id" : 75751947,
  "text" : "@romandos \u0420\u043E\u043C\u0430\u043D, \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u043E \u0442\u0432\u043E\u0435 \u043C\u043D\u0435\u043D\u0438\u0435 \u043A\u0430\u043A \u044E\u0437\u0435\u0440\u0430 \u043C\u043E\u0431\u0438\u043B\u044C\u043D\u044B\u0445 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0439. \u0434\u0430\u0439 \u043F\u043E\u0447\u0442\u0443, \u0441\u043F\u0440\u043E\u0448\u0443 \u043F\u0440\u043E\u0441\u0442\u043E \u043C\u043D\u0435\u043D\u0438\u0435",
  "id" : 209028417193119744,
  "in_reply_to_status_id" : 209024273430487041,
  "created_at" : "2012-06-02 21:07:12 +0000",
  "in_reply_to_screen_name" : "romandos",
  "in_reply_to_user_id_str" : "75751947",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/the-eatery\/id468299990?mt=8&uo=4\" rel=\"nofollow\"\u003EThe Eatery on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 103 ],
      "url" : "https:\/\/t.co\/t5oNCycx",
      "expanded_url" : "https:\/\/eatery.massivehealth.com\/foods\/2fc921f7-da0b-44ea-a754-3afa490149e6",
      "display_url" : "eatery.massivehealth.com\/foods\/2fc921f7\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "208545224270680064",
  "text" : "Just ate this at Cafe Brocard. Shivers. You don't want to see how healthy it was. https:\/\/t.co\/t5oNCycx",
  "id" : 208545224270680064,
  "created_at" : "2012-06-01 13:07:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]