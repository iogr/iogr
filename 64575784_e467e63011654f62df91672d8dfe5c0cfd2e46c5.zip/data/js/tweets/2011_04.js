Grailbird.data.tweets_2011_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64270194662572032",
  "text" : "\u0410\u043A\u0430\u0434\u0435\u043C\u0438\u043A\u0438 \u0438\u0441\u0441\u043B\u0435\u0434\u0443\u044E\u0442 \u0444\u043E\u0440\u043C\u0430\u043B\u044C\u043D\u044B\u0435 \u0441\u0442\u043E\u0440\u043E\u043D\u044B \u0448\u0443\u0442\u043A\u0438: http:\/\/bit.ly\/jgnbcx \u041A\u0430\u043C\u0435\u0434\u0438\u043A\u043B\u0430\u0431\u0443 \u043D\u0443\u0436\u043D\u043E \u0431\u043E\u043B\u044C\u0448\u0435 P(s \u2208 Se) = P(s \u2208 Sb).",
  "id" : 64270194662572032,
  "created_at" : "2011-04-30 10:09:43 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60755255079608322",
  "text" : "\u0424\u0435\u043D\u0438\u043B\u0430\u043B\u0430\u043D\u0438\u043D, \u043F\u043E\u0434\u043E\u0437\u0440\u0435\u0432\u0430\u044E, \u0432 \u043D\u0430\u043B\u0438\u0447\u0438\u0438",
  "id" : 60755255079608322,
  "created_at" : "2011-04-20 17:22:36 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60754851390431232",
  "text" : "\u0422\u0440\u0435\u0431\u0443\u044E\u0442\u0441\u044F 02, H2N\u2013CH(R)\u2013COOH, L-1(3,4-\u0414\u0438\u043E\u043A\u0441\u0438\u0444\u0435\u043D\u0438\u043B)-2-\u043C\u0435\u0442\u0438\u043B\u0430\u043C\u0438\u043D\u043E\u044D\u0442\u0430\u043D\u043E\u043B, \u0438 \u043F\u043E\u043C\u0435\u043D\u044C\u0448\u0435  1,3,7-\u0442\u0440\u0438\u043C\u0435\u0442\u0438\u043B\u043A\u0441\u0430\u043D\u0442\u0438\u043D\u0430",
  "id" : 60754851390431232,
  "created_at" : "2011-04-20 17:21:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria",
      "screen_name" : "pervomaj",
      "indices" : [ 0, 9 ],
      "id_str" : "46336383",
      "id" : 46336383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60341336137666560",
  "geo" : { },
  "id_str" : "60753478695395328",
  "in_reply_to_user_id" : 46336383,
  "text" : "@pervomaj \u0441\u043F\u0430 )",
  "id" : 60753478695395328,
  "in_reply_to_status_id" : 60341336137666560,
  "created_at" : "2011-04-20 17:15:32 +0000",
  "in_reply_to_screen_name" : "pervomaj",
  "in_reply_to_user_id_str" : "46336383",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60379856214560768",
  "geo" : { },
  "id_str" : "60753328044376064",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u044B - \u0432\u043E\u0442 \u0447\u0442\u043E \u0441\u043A\u0443\u0447\u043D\u043E",
  "id" : 60753328044376064,
  "in_reply_to_status_id" : 60379856214560768,
  "created_at" : "2011-04-20 17:14:56 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u043D\u043E\u0437\u0430\u0432\u0440-\u0444\u0438\u043B\u043E\u0441\u043E\u0444.",
      "screen_name" : "dinophilosopher",
      "indices" : [ 0, 16 ],
      "id_str" : "280893780",
      "id" : 280893780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60420700682457088",
  "geo" : { },
  "id_str" : "60426318277378048",
  "in_reply_to_user_id" : 280893780,
  "text" : "@dinophilosopher \u0435\u0433\u043E \u043C\u0430\u0442\u044C \u0442\u043E\u0436\u0435 \u0431\u044B\u043B\u0430 \u0437\u0430\u0447\u0430\u0442\u0430 \u043D\u0435\u043F\u043E\u0440\u043E\u0447\u043D\u043E, btw",
  "id" : 60426318277378048,
  "in_reply_to_status_id" : 60420700682457088,
  "created_at" : "2011-04-19 19:35:31 +0000",
  "in_reply_to_screen_name" : "dinophilosopher",
  "in_reply_to_user_id_str" : "280893780",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "60340714122395649",
  "geo" : { },
  "id_str" : "60369520317046784",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u0442\u0430\u043A \u0442\u043E\u0447\u043D\u043E",
  "id" : 60369520317046784,
  "in_reply_to_status_id" : 60340714122395649,
  "created_at" : "2011-04-19 15:49:49 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 3, 9 ],
      "id_str" : "80279354",
      "id" : 80279354
    }, {
      "name" : "Maria",
      "screen_name" : "pervomaj",
      "indices" : [ 11, 20 ],
      "id_str" : "46336383",
      "id" : 46336383
    }, {
      "name" : "Anton Gorbunov",
      "screen_name" : "iogr",
      "indices" : [ 21, 26 ],
      "id_str" : "64575784",
      "id" : 64575784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "60369381884051456",
  "text" : "RT @ftimn: @pervomaj @iogr \/ \u043E, \u0432\u0435\u043B\u0438\u043A\u0438\u0439 \u041C\u0435\u0440\u043B\u0438\u043D, \u043F\u0443\u0441\u0442\u044C \u043C\u043D\u0435 \u043D\u0435 \u043F\u043E\u043F\u0430\u0434\u0435\u0442 \u0437\u0430 \u0431\u043E\u043B\u0442\u043B\u0438\u0432\u043E\u0441\u0442\u044C! xDxD \u0437\u043D\u0430\u0447\u0438\u0442 \u0441 \u0440\u043E\u043C\u043E\u043C \u0440\u0435\u0448\u0435\u043D\u043E. \u043F\u044C\u0435\u043C )",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobileways.de\/gravity\" rel=\"nofollow\"\u003EGravity\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maria",
        "screen_name" : "pervomaj",
        "indices" : [ 0, 9 ],
        "id_str" : "46336383",
        "id" : 46336383
      }, {
        "name" : "Anton Gorbunov",
        "screen_name" : "iogr",
        "indices" : [ 10, 15 ],
        "id_str" : "64575784",
        "id" : 64575784
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "60325890713862145",
    "geo" : { },
    "id_str" : "60340714122395649",
    "in_reply_to_user_id" : 46336383,
    "text" : "@pervomaj @iogr \/ \u043E, \u0432\u0435\u043B\u0438\u043A\u0438\u0439 \u041C\u0435\u0440\u043B\u0438\u043D, \u043F\u0443\u0441\u0442\u044C \u043C\u043D\u0435 \u043D\u0435 \u043F\u043E\u043F\u0430\u0434\u0435\u0442 \u0437\u0430 \u0431\u043E\u043B\u0442\u043B\u0438\u0432\u043E\u0441\u0442\u044C! xDxD \u0437\u043D\u0430\u0447\u0438\u0442 \u0441 \u0440\u043E\u043C\u043E\u043C \u0440\u0435\u0448\u0435\u043D\u043E. \u043F\u044C\u0435\u043C )",
    "id" : 60340714122395649,
    "in_reply_to_status_id" : 60325890713862145,
    "created_at" : "2011-04-19 13:55:21 +0000",
    "in_reply_to_screen_name" : "pervomaj",
    "in_reply_to_user_id_str" : "46336383",
    "user" : {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "protected" : false,
      "id_str" : "80279354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/846620214389346308\/B01T88Md_normal.jpg",
      "id" : 80279354,
      "verified" : false
    }
  },
  "id" : 60369381884051456,
  "created_at" : "2011-04-19 15:49:16 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57992616180060161",
  "text" : "\u0430\u043B\u044C\u0442\u0438\u0442\u0443\u0434\u044B \u0434\u043E\u043B\u0436\u043D\u044B \u0431\u044B\u0442\u044C \u0441\u044B\u0433\u0440\u0430\u043D\u044B, \u0440\u0430\u0437\u0443\u043C\u0435\u0435\u0442\u0441\u044F, \u0442\u0430\u043A: http:\/\/bit.ly\/gdUtYv\n\u0432\u043E\u0442 \u044D\u0442\u043E - \u0442\u043E\u0447\u043D\u043E \u0433\u0440\u043E\u043C\u043A\u043E )",
  "id" : 57992616180060161,
  "created_at" : "2011-04-13 02:24:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57991865785532417",
  "text" : "http:\/\/bit.ly\/hDIill",
  "id" : 57991865785532417,
  "created_at" : "2011-04-13 02:21:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57991746755375104",
  "text" : "\u043C\u043E\u0436\u043D\u043E \u0434\u0430\u0436\u0435 \u0442\u0430\u043A: http:\/\/bit.ly\/eiUZ6M",
  "id" : 57991746755375104,
  "created_at" : "2011-04-13 02:21:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57991393594974208",
  "text" : "\u044D\u0442\u0438\u043C \u0443\u0442\u0440\u043E\u043C \u044F \u0438\u0433\u0440\u0430\u044E \u0437\u0430\u0432\u0435\u0434\u043E\u043C\u0443\u044E \u0447\u0443\u0448\u044C: http:\/\/bit.ly\/hu881B \n\u043E\u0441\u0442\u043E\u0440\u043E\u0436\u043D\u043E, \u043C\u043E\u0436\u0435\u0442 \u0431\u044B\u0442\u044C \u0433\u0440\u043E\u043C\u043A\u043E",
  "id" : 57991393594974208,
  "created_at" : "2011-04-13 02:20:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "57570532052316160",
  "geo" : { },
  "id_str" : "57611621446582272",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn can't eat anymore at all",
  "id" : 57611621446582272,
  "in_reply_to_status_id" : 57570532052316160,
  "created_at" : "2011-04-12 01:10:55 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "57593758337875969",
  "text" : "\u041F\u0435\u0440\u0438\u043E\u0434\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u0442\u0430\u0431\u043B\u0438\u0446\u0430 \u0441\u044E\u0436\u0435\u0442\u043D\u044B\u0445 \u0442\u0440\u043E\u043F\u043E\u0432: http:\/\/bit.ly\/eFfu89",
  "id" : 57593758337875969,
  "created_at" : "2011-04-11 23:59:56 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56849196598300672",
  "text" : "Before the Devil Knows You\u2019re Dead, \u043D\u0430\u043F\u0440\u0438\u043C\u0435\u0440, -  \u043A\u0430\u0440\u0442\u0438\u043D\u0430, \u0438\u0441\u043F\u043E\u043B\u043D\u0435\u043D\u043D\u0430\u044F \u0438\u0440\u043E\u043D\u0438\u0438 \u0432\u0437\u0440\u043E\u0441\u043B\u043E\u0433\u043E \u0441\u0435\u043C\u0435\u0439\u043D\u043E\u0433\u043E \u043A\u043E\u043D\u0444\u043B\u0438\u043A\u0442\u0430, \u0438\u0440\u043E\u043D\u0438\u0438, \u043D\u0435 \u0437\u043D\u0430\u044E\u0449\u0435\u0439 \u0441\u043E\u0441\u0442\u0440\u0430\u0434\u0430\u043D\u0438\u044F",
  "id" : 56849196598300672,
  "created_at" : "2011-04-09 22:41:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56847523876323329",
  "text" : "\u041C\u0430\u043B\u043E \u043A\u0430\u043A\u0438\u0435 \u0444\u0438\u043B\u044C\u043C\u044B \u043F\u043E\u0442\u0440\u044F\u0441\u0430\u043B\u0438 \u043C\u0435\u043D\u044F \u0442\u0430\u043A, \u043A\u0430\u043A \u0432\u0441\u0435 \u0444\u0438\u043B\u044C\u043C\u044B \u0412\u0435\u0440\u043D\u0435\u0440\u0430 \u0425\u0435\u0440\u0446\u043E\u0433\u0430. \u041D\u0435\u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u043B\u0435\u043D\u0442\u044B \u0421\u0438\u0434\u043D\u0438 \u041B\u044E\u043C\u0435\u0442\u0430 \u043C\u0435\u043D\u044F \u0432\u043F\u0435\u0447\u0430\u0442\u043B\u0438\u043B\u0438.",
  "id" : 56847523876323329,
  "created_at" : "2011-04-09 22:34:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56714131436347392",
  "text" : "\u0421\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u043E, \u041F\u0435\u0440\u0435\u043B\u044C\u043C\u0430\u043D\u043E\u0432 \u044F \u0442\u0430\u043C \u043D\u0435 \u0432\u0441\u0442\u0440\u0435\u0442\u0438\u043B. \u0441\u043A\u043E\u0440\u0435\u0435 \u0437\u043D\u0430\u0442\u043E\u043A\u043E\u0432 \u0441\u0430\u043C\u043E\u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0438\u0438 \u0438 \u0438\u0433\u0440\u043E\u0432\u043E\u0433\u043E \u0442\u0438\u043C\u0431\u0438\u043B\u0434\u0438\u043D\u0433\u0430.",
  "id" : 56714131436347392,
  "created_at" : "2011-04-09 13:44:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "skolkovo",
      "screen_name" : "i_skolkovo",
      "indices" : [ 3, 14 ],
      "id_str" : "411731659",
      "id" : 411731659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "56713729072578560",
  "text" : "RT @i_Skolkovo: \u042D\u043A\u0437\u0430\u043C\u0435\u043D \u0431\u0443\u0434\u0443\u0449\u0435\u0433\u043E http:\/\/j.mp\/goOYTj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.livejournal.com\/\" rel=\"nofollow\"\u003ELiveJournal.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "56627407314108416",
    "text" : "\u042D\u043A\u0437\u0430\u043C\u0435\u043D \u0431\u0443\u0434\u0443\u0449\u0435\u0433\u043E http:\/\/j.mp\/goOYTj",
    "id" : 56627407314108416,
    "created_at" : "2011-04-09 08:00:00 +0000",
    "user" : {
      "name" : "\u0424\u043E\u043D\u0434 \u0421\u043A\u043E\u043B\u043A\u043E\u0432\u043E",
      "screen_name" : "fondskolkovo",
      "protected" : false,
      "id_str" : "163802276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/979306520847450112\/kiYF5MZt_normal.jpg",
      "id" : 163802276,
      "verified" : false
    }
  },
  "id" : 56713729072578560,
  "created_at" : "2011-04-09 13:43:01 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55506376612515840",
  "geo" : { },
  "id_str" : "55702260126187520",
  "in_reply_to_user_id" : 149432947,
  "text" : "@perchenyatko dmae, \u0444\u043E\u0441\u0444\u0430\u0442\u0438\u0434\u0438\u043B-\u0441\u0435\u0440\u0438\u043D. \u041A\u043E\u0444\u0435\u0438\u043D \u043B\u0443\u0447\u0448\u0435 \u0441\u043E\u043A\u0440\u0430\u0449\u0430\u0442\u044C \u0441\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C",
  "id" : 55702260126187520,
  "in_reply_to_status_id" : 55506376612515840,
  "created_at" : "2011-04-06 18:43:48 +0000",
  "in_reply_to_screen_name" : "radiowestin",
  "in_reply_to_user_id_str" : "149432947",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0432\u0441\u0435\u0433\u0434\u0430 \u0442\u0430\u043A \u0434\u0435\u043B\u0430\u044E!",
      "screen_name" : "romandos",
      "indices" : [ 0, 9 ],
      "id_str" : "75751947",
      "id" : 75751947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55293427155353600",
  "geo" : { },
  "id_str" : "55295490111176704",
  "in_reply_to_user_id" : 75751947,
  "text" : "@romandos + \u043E\u0442\u043A\u0430\u0437 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u043A\u0438 \u043F\u0430\u043A\u0435\u0442\u043E\u0432 - \u044D\u0442\u043E \u0435\u0449\u0435 \u043D\u0435 \u0432\u0437\u043B\u043E\u043C, ping \u0434\u0435\u043C\u043E\u043D \u0442\u043E\u0436\u0435 \u043E\u0442\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0431\u043E\u043B\u044C\u0448\u043E\u043C\u0443 \u043A\u043E\u043B\u0438\u0447\u0435\u0441\u0442\u0432\u0443, \u043F\u0440\u0438 \u044D\u0442\u043E\u043C \u043E\u0441\u0442\u0430\u043B\u044C\u043D\u044B\u0435 \u0441\u043B\u0443\u0436\u0431\u044B \u0440\u0430\u0431\u043E\u0442\u0430\u044E\u0442",
  "id" : 55295490111176704,
  "in_reply_to_status_id" : 55293427155353600,
  "created_at" : "2011-04-05 15:47:26 +0000",
  "in_reply_to_screen_name" : "romandos",
  "in_reply_to_user_id_str" : "75751947",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0432\u0441\u0435\u0433\u0434\u0430 \u0442\u0430\u043A \u0434\u0435\u043B\u0430\u044E!",
      "screen_name" : "romandos",
      "indices" : [ 0, 9 ],
      "id_str" : "75751947",
      "id" : 75751947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "55293427155353600",
  "geo" : { },
  "id_str" : "55295095410409472",
  "in_reply_to_user_id" : 75751947,
  "text" : "@romandos \u0435\u0441\u043B\u0438 \u0437\u0430\u043F\u0440\u043E\u0441\u044B \u0440\u0430\u0441\u043F\u0440\u0435\u0434\u0435\u043B\u044F\u044E\u0442\u0441\u044F \u043F\u043E \u0440\u0430\u0437\u043D\u044B\u043C \u0441\u0435\u0440\u0432\u0435\u0440\u0430\u043C, \u0442\u043E, \u0433\u0438\u043F\u043E\u0442\u0435\u0442\u0438\u0447\u0435\u0441\u043A\u0438, \u0430\u0441\u0441\u043E\u0446\u0438\u0438\u0440\u0443\u044E\u0449\u0438\u0439\u0441\u044F\u043B \u043B\u044F\u0436\u0435\u0442 \u0441 \u0433\u0435\u0439\u0442\u0432\u0435\u0435\u043C. \u0411\u043E\u043B\u044C\u0448\u0435 \u0441\u043C\u044B\u0441\u043B\u0430 \u043D\u0435\u0442.",
  "id" : 55295095410409472,
  "in_reply_to_status_id" : 55293427155353600,
  "created_at" : "2011-04-05 15:45:52 +0000",
  "in_reply_to_screen_name" : "romandos",
  "in_reply_to_user_id_str" : "75751947",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ron Gilbert",
      "screen_name" : "grumpygamer",
      "indices" : [ 3, 15 ],
      "id_str" : "27531390",
      "id" : 27531390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "55270858289184768",
  "text" : "RT @grumpygamer: Dear Apple: Please fix GameCenter and the API and make it something actually useful.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "54990267845058560",
    "text" : "Dear Apple: Please fix GameCenter and the API and make it something actually useful.",
    "id" : 54990267845058560,
    "created_at" : "2011-04-04 19:34:36 +0000",
    "user" : {
      "name" : "Ron Gilbert",
      "screen_name" : "grumpygamer",
      "protected" : false,
      "id_str" : "27531390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/948363930799194112\/0rRngzhC_normal.jpg",
      "id" : 27531390,
      "verified" : true
    }
  },
  "id" : 55270858289184768,
  "created_at" : "2011-04-05 14:09:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0447",
      "screen_name" : "informcentr",
      "indices" : [ 0, 12 ],
      "id_str" : "137856929",
      "id" : 137856929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54606287203348480",
  "geo" : { },
  "id_str" : "54614287120994304",
  "in_reply_to_user_id" : 137856929,
  "text" : "@informcentr \u044D\u0442\u043E \u0431\u044B\u043B\u043E \u043D\u0430\u043F\u0438\u0441\u0430\u043D\u043E \u0434\u0430\u0432\u043D\u043E \u0438 \u043D\u0430 \u0433\u043E\u043B\u043E\u0434\u043D\u044B\u0439 \u0436\u0435\u043B\u0443\u0434\u043E\u043A. \u0441\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B \u0440\u0435\u0448\u0430\u044E\u0442\u0441\u044F.",
  "id" : 54614287120994304,
  "in_reply_to_status_id" : 54606287203348480,
  "created_at" : "2011-04-03 18:40:35 +0000",
  "in_reply_to_screen_name" : "informcentr",
  "in_reply_to_user_id_str" : "137856929",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "54601839064264706",
  "text" : "\u041F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043B 38 \u043F\u0440\u043E\u0441\u0442\u044B\u0445 \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0439 todo \u0438 \u043D\u0435 \u043D\u0430\u0448\u0435\u043B \u0442\u0430\u043A\u043E\u0433\u043E http:\/\/todokyo.com lucifer, \u044D\u0442\u043E \u0436\u0435 \u0437\u0430 40 \u0441\u0435\u043A\u0443\u043D\u0434 \u043C\u043E\u0436\u043D\u043E \u043D\u0430\u043F\u0438\u0441\u0430\u0442\u044C",
  "id" : 54601839064264706,
  "created_at" : "2011-04-03 17:51:07 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ibalahnin",
      "screen_name" : "ibalahnin",
      "indices" : [ 0, 10 ],
      "id_str" : "18627413",
      "id" : 18627413
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54573141825036288",
  "geo" : { },
  "id_str" : "54588347267559424",
  "in_reply_to_user_id" : 18627413,
  "text" : "@ibalahnin 3 \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B \u0424\u041F http:\/\/Politicaltheory.ru \u043D\u0430\u0442\u043A\u043D\u0443\u043B\u0441\u044F \u0432 \u0438\u043D\u0435\u0442\u0435",
  "id" : 54588347267559424,
  "in_reply_to_status_id" : 54573141825036288,
  "created_at" : "2011-04-03 16:57:30 +0000",
  "in_reply_to_screen_name" : "ibalahnin",
  "in_reply_to_user_id_str" : "18627413",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0432\u0441\u0435\u0433\u0434\u0430 \u0442\u0430\u043A \u0434\u0435\u043B\u0430\u044E!",
      "screen_name" : "romandos",
      "indices" : [ 0, 9 ],
      "id_str" : "75751947",
      "id" : 75751947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "54164738602577920",
  "geo" : { },
  "id_str" : "54202155883696128",
  "in_reply_to_user_id" : 75751947,
  "text" : "@romandos \u0434\u0430, \u043F\u043E\u043A\u043B\u043E\u043D\u043D\u0438\u043A\u0438 \u043A\u043E\u043D\u0447\u0435\u0432\u0430- \u044D\u0442\u043E \u0447\u0438\u0441\u0442\u043E\u0435 \u0438\u043D\u0444\u0435\u0440\u043D\u043E, \u0438\u043D\u0444\u0430 1488%",
  "id" : 54202155883696128,
  "in_reply_to_status_id" : 54164738602577920,
  "created_at" : "2011-04-02 15:22:55 +0000",
  "in_reply_to_screen_name" : "romandos",
  "in_reply_to_user_id_str" : "75751947",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]