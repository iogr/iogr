Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73842102848598017",
  "text" : "Anatomy of a Spam Viagra Purchase http:\/\/bit.ly\/ms0BlE",
  "id" : 73842102848598017,
  "created_at" : "2011-05-26 20:05:03 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73826368609198080",
  "text" : "\u041F\u0440\u0438\u0432\u0435\u0437\u043B\u0438 \u0442\u043E\u0432\u0430\u0440, \u0432\u043A\u043B\u044E\u0447\u0438\u043B\u0438 \u0434\u0438\u0440\u0435\u043A\u0442 \u0438 \u043C\u0430\u0440\u043A\u0435\u0442, \u0438 \u0432\u0441\u0435 \u0437\u0430\u0440\u0430\u0431\u043E\u0442\u0430\u043B\u043E. \u0442\u0440\u0438 \u0437\u0430\u043A\u0430\u0437\u0430 \u043D\u0430 17 \u0442\u0440 \u0441\u0435\u0433\u043E\u0434\u043D\u044F.",
  "id" : 73826368609198080,
  "created_at" : "2011-05-26 19:02:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72275992508514305",
  "text" : "\u0413\u043E\u0442\u043E\u0432\u0438\u043C\u0441\u044F \u0432\u043E\u0437\u0438\u0442\u044C \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0438 \u0442\u0435\u043A\u0441\u0442\u0438\u043B\u044C \u0434\u043B\u044F \u043E\u0442\u0435\u043B\u0435\u0439 \u0438\u0437 \u0418\u0442\u0430\u043B\u0438\u0438. \u041F\u043E\u043F\u0440\u043E\u0431\u0443\u0435\u043C, \u043A\u043E\u043D\u0435\u0447\u043D\u043E, \u043D\u043E, \u0435\u0441\u043B\u0438 \u043F\u043E-\u0445\u043E\u0440\u043E\u0448\u0435\u043C\u0443, - \u043D\u0443\u0436\u043D\u043E \u0435\u0445\u0430\u0442\u044C \u0432 UK \u0443\u0447\u0438\u0442\u044C \u0444\u0438\u043D\u0430\u043D\u0441\u044B.",
  "id" : 72275992508514305,
  "created_at" : "2011-05-22 12:21:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "72254658919407616",
  "geo" : { },
  "id_str" : "72268988742246400",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u0437\u0430\u0431\u044B\u043B \u0442\u0435\u0431\u044F. \u0437\u0430\u043C\u0435\u0447\u0430\u043B, \u0447\u0442\u043E \u0442\u0435\u0431\u0435 \u043D\u0440\u0430\u0432\u044F\u0442\u0441\u044F \u043D\u044B\u0442\u0438\u043A\u0438 \u0438 \u0441\u0438\u043C\u0443\u043B\u044F\u043D\u0442\u044B, \u0430 \u0432 \u043E\u043A\u0440\u0443\u0436\u0435\u043D\u0438\u0438 \u043D\u0435\u0442 \u0441\u0438\u043B\u044C\u043D\u044B\u0445 \u043C\u0443\u0436\u0447\u0438\u043D. \u043E \u0447\u0443\u0432\u0441\u0442\u0432\u0430\u0445 \u0442\u044B \u0442\u043E\u0436\u0435 \u043C\u0430\u043B\u043E \u0437\u043D\u0430\u0435\u0448\u044C.",
  "id" : 72268988742246400,
  "in_reply_to_status_id" : 72254658919407616,
  "created_at" : "2011-05-22 11:54:04 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72048205155680258",
  "text" : "\u0421 \u0442\u043E\u0440\u0440\u0435\u043D\u0442\u043E\u0432 \u043C\u043E\u0436\u043D\u043E \u0441\u043A\u0430\u0447\u0430\u0442\u044C \u0432\u0441\u0435 \u043C\u043E\u0435 \u0434\u0435\u0442\u0441\u0442\u0432\u043E: http:\/\/bit.ly\/l0gcsy",
  "id" : 72048205155680258,
  "created_at" : "2011-05-21 21:16:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "72046695738916864",
  "text" : "\u0421\u043A\u0435\u043B\u0435\u0442 \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0430\u0435\u0442 \u0441\u043A\u0443\u0447\u0430\u0442\u044C \u043F\u043E \u041C\u0430\u0448\u0435 \u0442\u0430\u0449\u0435\u043C\u0442\u0430.",
  "id" : 72046695738916864,
  "created_at" : "2011-05-21 21:10:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71466945718910976",
  "text" : "\u0413\u0430\u0440\u0440\u0438 \u041F\u043E\u0442\u0442\u0435\u0440: \u00AB\u041B\u0435\u0433\u0435\u043D\u0434\u0430 \u0434\u0440\u0435\u0432\u043D\u0435\u0433\u043E \u0422\u043E\u0440\u043E\u043F\u0446\u0430 \u0438 \u0442\u0430\u0439\u043D\u044B \u043E\u0437\u0435\u0440\u0430 \u0411\u0440\u043E\u0441\u043D\u043E\u00BB (\u0441 \u0448\u0430\u0448\u043B\u044B\u043A\u0430\u043C\u0438 \u043D\u0430 \u0431\u0435\u0440\u0435\u0433\u0443 \u0440\u0443\u0441\u0441\u043A\u043E\u0433\u043E \u041B\u043E\u0445\u043D\u0435\u0441\u0441\u0430)",
  "id" : 71466945718910976,
  "created_at" : "2011-05-20 06:47:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71464842174799872",
  "text" : "\u0432 \u0448\u0432\u0442 \u0437\u0430\u043F\u043B\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u044B \u043C\u0438\u043B\u0435\u043D\u044C\u043A\u0438\u0435 \u0431\u0438\u0437\u043D\u0435\u0441-\u043F\u043E\u0441\u0438\u0434\u0435\u043B\u043A\u0438 \u043F\u043E \u0442\u043A\u0430\u043D\u044F\u043C\\\u0442\u0435\u043A\u0441\u0442\u0438\u043B\u044E\\\u0434\u0438\u0437\u0430\u0439\u043D\u0443 \u0432 \u0433\u043E\u0441\u0442\u044F\u0445 \u0443 \u0418\u0440\u0438\u043D\u044B \u0413.",
  "id" : 71464842174799872,
  "created_at" : "2011-05-20 06:38:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71464303693266944",
  "text" : "\u0412 us \u0441\u043A\u0430\u0437\u0430\u043B\u0438, \u0447\u0442\u043E \u0443 \u043C\u0435\u043D\u044F \u043D\u0435\u043F\u0440\u0438\u043B\u0438\u0447\u043D\u043E \u043D\u0438\u0437\u043A\u0438\u0435 \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u043D\u044B\u0435 \u043E\u0436\u0438\u0434\u0430\u043D\u0438\u044F \u0438 \u043E\u043D\u0438 \u0441\u043D\u0438\u0441\u0445\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u043F\u043E\u0432\u044B\u0448\u0430\u044E\u0442 \u0438\u0445 \u0434\u043E 30-40.",
  "id" : 71464303693266944,
  "created_at" : "2011-05-20 06:36:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71246829420945408",
  "text" : "http:\/\/img.ly\/4euv http:\/\/img.ly\/4euH",
  "id" : 71246829420945408,
  "created_at" : "2011-05-19 16:12:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71198086998917120",
  "geo" : { },
  "id_str" : "71236362979917824",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u0430 \u0442\u0435\u0431\u0435 \u0432\u044B\u043F\u0430\u043B \u043B\u0443\u0442 \u0437\u0430 \u043A\u0432\u0435\u0441\u0442?",
  "id" : 71236362979917824,
  "in_reply_to_status_id" : 71198086998917120,
  "created_at" : "2011-05-19 15:30:47 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71228281977978880",
  "text" : "\u041D\u043E \u0443 \u0442\u0430\u043A\u043E\u0433\u043E \u0444\u044E\u0440\u0435\u0440-\u043F\u0440\u0438\u043D\u0446\u0438\u043F\u0430 \u0435\u0441\u0442\u044C \u043D\u0435\u0434\u043E\u0441\u0442\u0430\u0442\u043E\u043A: \u0445\u043E\u043C\u044F\u0447\u043A\u0438, \u0430\u043A\u0442\u0438\u0432\u043D\u043E \u043F\u043E\u0442\u0440\u0435\u0431\u043B\u044F\u044E\u0449\u0438\u0435 \u043D\u0435\u0433\u0430\u0442\u0438\u0432\u043D\u0443\u044E \u0434\u0438\u0430\u043B\u0435\u043A\u0442\u0438\u043A\u0443 \u043F\u043E\u043F\u0443\u043B\u0438\u0437\u043C\u0430,  \u0432\u043E\u0437\u0433\u043E\u043D\u044F\u044E\u0442 \u043E\u0441\u0432\u0435\u043D\u0446\u0438\u043C \u043F\u0440\u043E\u0441\u0432\u0435\u0449\u0435\u043D\u0438\u044F",
  "id" : 71228281977978880,
  "created_at" : "2011-05-19 14:58:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71227077688442880",
  "text" : "\u043D\u0430\u0438\u0432\u043D\u043E \u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u043C\u0438\u043D\u043E\u0440\u0438\u0442\u0430\u0440\u0438\u0435\u0432 \u0440\u0438\u0441\u043A\u043E\u0432\u0430\u0442\u044C \u0434\u0438\u0432\u0438\u0434\u0435\u043D\u0434\u0430\u043C\u0438 \u0434\u043B\u044F \u0440\u0430\u0441\u043A \u0431\u0443\u0445\u0433 \u0442\u0430\u0439\u043D, \u0432\u043F\u0438\u0441\u044B\u0432\u0430\u044F\u0441\u044C \u0432 \u0448\u0443\u043C \u043F\u0440\u0438 \u0437\u0430\u043A\u0440\u044B\u0442\u0438\u0438 \u0440\u0435\u0435\u0441\u0442\u0440\u043E\u0432, \u044F\u0432\u043B. \u0430\u0442\u0440\u0438\u0431\u0443\u0442\u043E\u043C \u043A\u0440\u0443\u043F\u043D \u0430\u043A\u0446 \u043A\u043E\u043C\u043F",
  "id" : 71227077688442880,
  "created_at" : "2011-05-19 14:53:53 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71225237357854721",
  "text" : "\u041D. \u0441\u043E\u0441\u0442\u043E\u044F\u043B\u0441\u044F \u0437\u0430 \u0441\u0447\u0435\u0442 \u0441\u0438\u043C\u0443\u043B\u044F\u0446\u0438\u0438 \u0437\u043D\u0430\u043A\u0430 \u043F\u043E\u0434\u0432\u0438\u0433\u0430: \u043C\u043E\u043D\u0438\u0442\u043E\u0440\u0438\u0442 \u0441\u0430\u0439\u0442 \u0434\u043B\u044F \u043C\u043E\u043D\u0438\u0442\u043E\u0440\u0438\u043D\u0433\u0430, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u043C\u043E\u043D\u0438\u0442\u043E\u0440\u0438\u043B\u0438 \u0434\u043E \u043D\u0435\u0433\u043E,",
  "id" : 71225237357854721,
  "created_at" : "2011-05-19 14:46:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71224610439430144",
  "text" : "\u041F\u043E\u043F\u0443\u043B\u0438\u0437\u043C - \u043F\u043E\u0434\u0434\u0435\u0440\u0436\u043A\u0430 \u0430\u0441\u0442\u0440\u0430\u043A\u0442\u043D\u043E\u0433\u043E \u0437\u043D\u0430\u043A\u0430 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u044F, \u0440\u0435\u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0443\u044E\u0449\u0435\u0433\u043E \u0432\u0435\u0441\u044C \u043A\u043B\u0430\u0441\u0441 \u0440\u0430\u0437\u0440\u043E\u0437\u043D\u0435\u043D\u043D\u044B\u0445 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0439",
  "id" : 71224610439430144,
  "created_at" : "2011-05-19 14:44:05 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71221309668986881",
  "text" : "\u0425\u043E\u043C\u043D\u0435\u0442 \u0438\u043B\u0438 unicredit securities. \u0441\u043A\u0435\u043B\u0435\u0442 \u043F\u043E\u043B\u0443\u0447\u0438\u0442 \u043D\u043E\u0432\u044B\u0439 \u043B\u0443\u0442, \u043A\u043E\u0433\u0434\u0430 \u043F\u0440\u0438\u0441\u0442\u0443\u043F\u0438\u0442 \u043A \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u043E\u0439 \u0440\u0430\u0431\u043E\u0442\u0435, \u0445\u043E\u0442\u044F \u0441\u043A\u0435\u043B\u0435\u0442 \u043C\u043E\u0436\u0435\u0442 \u0437\u0430\u0440\u0430\u0431\u0430\u0442\u044B\u0432\u0430\u0442\u044C \u0434\u043E\u043C\u0435\u043D\u0430\u043C\u0438 \u0438 \u0442\u0430",
  "id" : 71221309668986881,
  "created_at" : "2011-05-19 14:30:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "71125625288654848",
  "geo" : { },
  "id_str" : "71185434901884928",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u0431\u044B\u043B \u0431\u044B \u043D\u0435\u0432\u043D\u0438\u043C\u0430\u0442\u0435\u043B\u0435\u043D, \u0435\u0441\u043B\u0438 \u0431\u044B \u0434\u0443\u043C\u0430\u043B, \u0447\u0442\u043E \u0442\u044B \u043F\u043E\u0434\u0432\u0435\u0440\u0433\u0430\u0435\u0448\u044C \u044D\u0442\u0443 \u043C\u0435\u0445\u0430\u043D\u0438\u043A\u0443 \u0441\u043E\u043C\u043D\u0435\u043D\u0438\u044E.",
  "id" : 71185434901884928,
  "in_reply_to_status_id" : 71125625288654848,
  "created_at" : "2011-05-19 12:08:24 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71183822670147584",
  "text" : "\u0421\u043A\u0435\u043B\u0435\u0442 \u043F\u0440\u043E\u0448\u0435\u043B \u043F\u043E \u0442\u0440\u043E\u043F\u0435 \u0443\u0436\u0435 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043A\u043E\u043B\u043E\u043C\u0435\u0442\u0440\u043E\u0432, \u043D\u043E \u043F\u043E\u043A\u0430 \u0447\u0442\u043E \u043D\u0435 \u043D\u0430\u0448\u0435\u043B \u043D\u0438\u043A\u0430\u043A\u043E\u0433\u043E \u043B\u0443\u0442\u0430, \u043A\u0440\u043E\u043C\u0435 \u043F\u043E\u043B\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0433\u043E \u0445\u0440\u0443\u0441\u0442\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0447\u0435\u0440\u0435\u043F\u0430 (",
  "id" : 71183822670147584,
  "created_at" : "2011-05-19 12:02:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70998478305755136",
  "text" : "\u0413\u043E\u0442\u043E\u0432\u044B \u0432\u0437\u044F\u0442\u044C \u043D\u0430 \u0434\u0432\u0435 \u043D\u0435 \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u044B\u0445 \u0434\u043E\u043B\u0436\u043D\u043E\u0441\u0442\u0438, \u0430 \u0432\u043E\u0442 \u0441 \u0434\u0440\u0438\u043C\u0432\u0440\u043A, \u0441\u0442\u0440\u0430\u043D\u043D\u044B\u043C \u043E\u0431\u0440\u0430\u0437\u043E\u043C \u0441\u043E\u0435\u0434 \u043C\u043E\u0438 \u0437\u043D\u0430\u043D\u0438\u044F IT \u0438 \u0431\u0438\u0437\u043D\u0435\u0441 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u043E\u0432 \u0441\u0438\u0442 \u043E\u043F\u0440 \u043D\u0430 \u0434\u043D\u044F\u0445",
  "id" : 70998478305755136,
  "created_at" : "2011-05-18 23:45:30 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70942693873819648",
  "geo" : { },
  "id_str" : "70996438653480960",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u043B\u044E\u0431\u043E\u0435 \u0421\u043E\u0431\u044B\u0442\u0438\u0435 (\u043F\u043E \u0411\u0430\u0434\u044C\u044E) \u0430\u0432\u0442\u043E\u0440\u0435\u0444\u0435\u0440\u0435\u043D\u0442\u043D\u043E, \u043D\u0430\u043F\u0440 \u0440\u0435\u0432\u043E\u043B\u044E\u0446\u0438\u044F. \u0442\u0430\u043A \u0441\u043B\u0443\u0447\u0430\u044E\u0442\u0441\u044F \u0438 \u0437\u043D\u0430\u043A\u0438 \u0442\u0438\u043F\u0430 \u043D\u0430\u0432-\u0433\u043E \u0438 \u043B\u0438\u0441\u0442\u0435\u0440\u043C\u0430\u043D\u0430, \u043E\u043D\u0438 \u0441\u043E\u0441\u0442\u043E\u044F\u043B\u0438\u0441\u044C \u043A\u043E\u0433\u0434 \u043F\u0440\u0438\u0437\u043D\u0430\u043D\u044B",
  "id" : 70996438653480960,
  "in_reply_to_status_id" : 70942693873819648,
  "created_at" : "2011-05-18 23:37:24 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70832380235087872",
  "text" : "\u0412 \u0433\u0440\u0430\u0444\u0435 \"\u043F\u0435\u0440\u0435\u0447\u0438\u0441\u043B\u0438\u0442\u0435 \u043D\u0430\u0438\u0431\u043E\u043B\u0435\u0435 \u0437\u043D\u0430\u0447\u0438\u043C\u044B\u0435 \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u044B \u0432\u043D\u0435 \u0440\u0430\u0431\u043E\u0442\u044B 8-\u0441\u0442\u0440\u0430\u043D\u0438\u0447\u043D\u043E\u0439 \u0430\u043D\u043A\u0435\u0442\u044B \u0411\u041C \u043D\u0430\u043F\u0438\u0441\u0430\u043B: \n\"\u0443 \u043C\u0435\u043D\u044F \u0434\u043E\u043C\u0430 \u0435\u0441\u0442\u044C \u0441\u0438\u0442\u043E \u0434\u043B\u044F \u043A\u0443\u0441-\u043A\u0443\u0441\u0430\"",
  "id" : 70832380235087872,
  "created_at" : "2011-05-18 12:45:30 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70825765087887361",
  "text" : "\u041C\u044B, \u0446\u0438\u0440\u043A\u0443\u043C\u0446\u0435\u043B\u043B\u0438\u043E\u043D\u044B,\n\u041D\u0430\u0440\u043E\u0434 \u043D\u0435 \u043F\u0440\u0430\u043A\u0442\u0438\u0447\u043D\u044B\u0439",
  "id" : 70825765087887361,
  "created_at" : "2011-05-18 12:19:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70631832227561473",
  "text" : "everything is the color of television, tuned to a dead channel",
  "id" : 70631832227561473,
  "created_at" : "2011-05-17 23:28:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70629777681285120",
  "text" : "http:\/\/cgsh.ru \u0432\u0441\u0435-\u0442\u0430\u043A\u0438 \u043D\u0443\u0436\u043D\u043E \u0431\u044B\u0442\u044C geek, \u0447\u0442\u043E\u0431\u044B \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u043E\u0442\u043A\u043B\u044E\u0447\u0438\u0442\u044C\u0441\u044F \u043E\u0442 \u0440\u0435\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u043D\u0430 \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u0447\u0430\u0441\u043E\u0432 \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E\u0431\u044B \u0441\u0434\u0435\u043B\u0430\u0442\u044C \u044D\u0442\u043E ^^",
  "id" : 70629777681285120,
  "created_at" : "2011-05-17 23:20:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70472781355171840",
  "geo" : { },
  "id_str" : "70488504437710848",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u043D\u0435 \u0432\u043E \u0432\u0441\u0435\u0445 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u044F\u0445 \u0442\u0430\u043A\u0430\u044F \u0430\u0442\u043C\u043E\u0441\u0444\u0435\u0440\u0430, \u0440\u0430\u0437\u0443\u043C\u0435\u0435\u0442\u0441\u044F. \u0418\u0433\u0440\u044B \u0434\u043B\u044F \u043F\u043B\u0430\u043D\u043A\u0442\u043E\u043D\u0430 \u043D\u0430 \u0441\u043E\u0431\u0435\u0441\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0438 \u0432 \u0411\u041C, \u0438\u043C\u0445\u043E, \u0432\u043F\u043E\u043B\u043D\u0435 \u043D\u043E\u0440\u043C \u043F\u0440\u043E\u0448\u0435\u043B",
  "id" : 70488504437710848,
  "in_reply_to_status_id" : 70472781355171840,
  "created_at" : "2011-05-17 13:59:03 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70486063554109441",
  "text" : "\u0414\u0435\u043B\u043E \u0432 \u0442\u043E\u043C, \u0447\u0442\u043E \u0434\u0430\u0436\u0435 \u0432 \u043A\u0430\u043D\u0442\u043E\u0432\u0441\u043A\u043E\u043C \"\u0432\u044B\u0445\u043E\u0434\u0435 \u0438\u0437 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F \u043D\u0435\u0441\u043E\u0432\u0435\u0440\u0448\u0435\u043D\u043D\u043E\u043B\u0435\u0442\u0438\u044F\" \u0435\u0441\u0442\u044C \u043D\u0435\u0440\u0430\u0437\u0440\u0435\u0448\u0438\u043C\u044B\u0435 \u043F\u0430\u0440\u0430\u0434\u043E\u043A\u0441\u044B \u0444\u0440\u0435\u0439\u043C\u0430, \u0433\u0430\u0441\u0438\u043C\u044B\u0435 \u0434\u0435\u043A\u043B \u043E\u0431\u044F\u0437 \u043A\u0440\u0438\u0442 \u043F\u043E\u0437\u0438\u0446\u0438\u0438",
  "id" : 70486063554109441,
  "created_at" : "2011-05-17 13:49:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70472781355171840",
  "geo" : { },
  "id_str" : "70484013684494336",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u043D\u0430 \u043D\u0438\u0445 \u043B\u0443\u0447\u0448\u0435 \u0432\u043E\u043E\u0431\u0449\u0435 \u043D\u0435 \u0445\u043E\u0434\u0438\u0442\u044C \u0432 \u043C\u043E\u0435\u043C \u0441\u043B\u0443\u0447\u0430\u0435. \u044F \u043D\u0435 \u043F\u043E\u0441\u043B\u0443\u0448\u043D\u044B\u0439 \u043C\u0430\u043B\u044C\u0447\u0438\u043A, \u043B\u044E\u0431\u044F\u0449\u0438\u0439 \u0444\u043E\u0440\u043C\u0430\u043B\u044C\u043D\u043E\u0435 \u043B\u0438\u0446\u0435\u043C\u0435\u0440\u0438\u0435, \u043F\u043E\u0434\u0447\u0438\u043D\u044F\u0442\u044C\u0441\u044F \u0438 \u0441\u043E\u0441\u0430\u0442\u044C \u0445 \u0437\u0430 \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0443",
  "id" : 70484013684494336,
  "in_reply_to_status_id" : 70472781355171840,
  "created_at" : "2011-05-17 13:41:13 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70481203953799168",
  "text" : "\u042F \u0445\u043E\u0447\u0443 \u0441\u043A\u0430\u0437\u0430\u0442\u044C, \u0447\u0442\u043E \u0432\u0441\u044F \u044D\u0442\u0430 \u0430\u0437\u0438\u0430\u0442\u0449\u0438\u043D\u0430 - \u044D\u0442\u043E, \u043D\u0430\u0442\u0443\u0440\u0430\u043B\u044C\u043D\u043E, \u044D\u0444\u0444\u0435\u043A\u0442 lumi\u00E8re, \"\u0441\u0432\u0435\u0442\u0430 \u0440\u0430\u0437\u0443\u043C\u0430\".",
  "id" : 70481203953799168,
  "created_at" : "2011-05-17 13:30:03 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70479890864029697",
  "text" : "- \u043F\u043E\u043B\u044F \u0431\u043B\u0430\u0433\u043E\u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u044F, \u0442.\u0435. \u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0435\u043B\u044C\u043D\u044B\u0445 \u043A\u043E\u043E\u0440\u0434\u0438\u043D\u0430\u0442 \u043F\u043E\u0442\u0440\u0435\u0431\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u043E\u0439 \u0440\u0435\u0434\u043A\u043E\u0441\u0442\u0438.",
  "id" : 70479890864029697,
  "created_at" : "2011-05-17 13:24:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70479583857754112",
  "text" : "\u0447\u0442\u043E \u0442\u0430\u043A\u043E\u0435 \u041F\u0440\u043E\u0441\u0432\u0435\u0449\u0435\u043D\u0438\u0435?\". \u0412\u043C\u0435\u0441\u0442\u043E \u0441\u0430\u043C\u043E\u043E\u0431\u043E\u0441\u043D\u043E\u0432\u0430\u043D\u0438\u044F \u0441\u043E\u0431\u0441\u0442\u0432\u0435\u043D\u043D\u043E\u0433\u043E \u0437\u043D\u0430\u043D\u0438\u044F \u0447\u0435\u0440\u0435\u0437 \u043C\u043E\u0440\u0430\u043B\u044C\u043D\u0443\u044E \u0410\u0432\u0442\u043E\u043D\u043E\u043C\u0438\u044E, \u043C\u044B \u041F\u0440\u0438\u0431\u0435\u0433\u0430\u0435\u043C \u043A \u0441\u0440\u0435\u0434\u0441\u0442\u0432\u0430\u043C \"\u0440\u043E\u0434\u0438\u0442\u0435\u043B\u044C\u0441\u043A\u043E\u0433\u043E\" \u043F\u043E\u043B\u044F",
  "id" : 70479583857754112,
  "created_at" : "2011-05-17 13:23:36 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70479188670423041",
  "text" : "\u041D\u043E\u043D\u0435\u0448\u043D\u0438\u0439 \u0441\u043E\u0446\u0438\u0430\u043B-\u0434\u0430\u0440\u0432\u0438\u043D\u0438\u0437\u043C - \u0442\u0430\u0449\u0435\u043C\u0442\u0430, \u044D\u0444\u0444\u0435\u043A\u0442 \u043A\u043B\u0430\u0441\u0441\u0438\u0447\u0435\u0441\u043A\u043E\u0433\u043E \u0438\u0434\u0435\u0430\u043B\u0430 \u041F\u0440\u043E\u0441\u0432\u0435\u0449\u0435\u043D\u0438\u044F. \u0412\u0441\u043F\u043E\u043C\u043D\u0438\u043C \u0442\u0440\u0430\u043A\u0442\u0430\u0442 \u041A\u0430\u043D\u0442\u0430 1784 \u0433. \"\u041E\u0442\u0432\u0435\u0442 \u043D\u0430 \u0432\u043E\u043F\u0440\u043E\u0441:",
  "id" : 70479188670423041,
  "created_at" : "2011-05-17 13:22:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70425656063832064",
  "text" : "\u0412 \u0411\u0430\u043D\u043A\u0435 \u041C\u043E\u0441\u043A\u0432\u044B \u043D\u0430 \u0442\u0440\u0443\u0431\u043D\u043E\u0439 \u043D\u0430 \u0441\u043E\u0431\u0435\u0441\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0438, \u043F\u0440\u0438\u0448\u0435\u043B \u043D\u0430 15 \u043C\u0438\u043D\u0443\u0442 \u0440\u0430\u043D\u044C\u0448\u0435,  btw",
  "id" : 70425656063832064,
  "created_at" : "2011-05-17 09:49:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0414\u0438\u043D\u043E\u0437\u0430\u0432\u0440-\u0444\u0438\u043B\u043E\u0441\u043E\u0444.",
      "screen_name" : "dinophilosopher",
      "indices" : [ 0, 16 ],
      "id_str" : "280893780",
      "id" : 280893780
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "70151767597387776",
  "geo" : { },
  "id_str" : "70155443636412416",
  "in_reply_to_user_id" : 280893780,
  "text" : "@dinophilosopher \u043E\u043D\u0430, \u043A\u0441\u0442\u0430\u0442\u0438, \u0443\u0448\u043B\u0430 \u0438\u0437 \u0431\u0438\u0437\u043D\u0435\u0441\u0430 (",
  "id" : 70155443636412416,
  "in_reply_to_status_id" : 70151767597387776,
  "created_at" : "2011-05-16 15:55:35 +0000",
  "in_reply_to_screen_name" : "dinophilosopher",
  "in_reply_to_user_id_str" : "280893780",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69930035036962816",
  "text" : "\u0415\u0449\u0435 \u043F\u0430\u0440\u0430 \u0447\u0430\u0441\u043E\u0432 javascript-ajax-php, css \u0441\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u043C \u0432\u0435\u0447\u0435\u0440\u043E\u043C \u0438 \u043F\u043E\u043B\u0443\u0447\u0443 \u043C\u043E\u044E \u043F\u0440\u0435\u043B\u0435\u0441\u0442\u044C ) WYSIWYG \u0440\u0435\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u0432\u0441\u0435\u0433\u0434\u0430 \u0431\u044B\u043B\u0438 \u0443\u0449\u0435\u0440\u0431\u043D\u044B\u043C\u0438.",
  "id" : 69930035036962816,
  "created_at" : "2011-05-16 00:59:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69823519961255936",
  "text" : "\u0420\u0435\u0448\u0438\u043B \u043F\u0440\u043E\u043A\u0430\u0447\u0430\u0442\u044C \u0441\u043A\u0435\u043B\u0435\u0442\u0430 \u0432 epic win, \u0435\u0432\u043F\u043E\u0447\u044F",
  "id" : 69823519961255936,
  "created_at" : "2011-05-15 17:56:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69513597834887168",
  "text" : "\u043F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u043B \u043D\u0430\u0440\u0435\u0437\u043A\u0443 \u043F\u043E\u044E\u0449\u0438\u0445 \u0435\u0432\u0440\u043E\u043F\u0435\u0439\u0441\u043A\u0438\u0445 \u043A\u0430\u043F\u0438\u0442\u0430\u043B\u043E\u0432 \u0438 \u0441\u0434\u0435\u043B\u0430\u043B \u043F\u043E\u0436\u0435\u0440\u0442\u0432\u043E\u0432\u0430\u043D\u0438\u0435 http:\/\/bit.ly\/bGyawb \u0437\u0430 \u0442\u043E, \u0447\u0442\u043E \u043D\u0435 \u0440\u0432\u0443\u0442 \u0433\u043B\u043E\u0442\u043A\u0438, \u043D\u043E \u0437\u043D\u0430\u044E\u0442 \u0447\u0442\u043E \u043F\u043E\u044E\u0442 \u0432\u0435\u0449\u0438",
  "id" : 69513597834887168,
  "created_at" : "2011-05-14 21:25:07 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69472097470136320",
  "geo" : { },
  "id_str" : "69474456573198336",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn from jail ofc",
  "id" : 69474456573198336,
  "in_reply_to_status_id" : 69472097470136320,
  "created_at" : "2011-05-14 18:49:35 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69467741706403840",
  "geo" : { },
  "id_str" : "69469198157488128",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn http:\/\/www.eurovision.tv\/esctv \u043D\u0443\u0436\u043D\u043E octoshape \u043F\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C, \u0435\u0441\u043B\u0438 \u043D\u0435 \u0441\u0442\u043E\u0438\u0442",
  "id" : 69469198157488128,
  "in_reply_to_status_id" : 69467741706403840,
  "created_at" : "2011-05-14 18:28:42 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69392843814354944",
  "geo" : { },
  "id_str" : "69430972621389825",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn Mummy will buy it when you come out sonny )",
  "id" : 69430972621389825,
  "in_reply_to_status_id" : 69392843814354944,
  "created_at" : "2011-05-14 15:56:48 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0447",
      "screen_name" : "informcentr",
      "indices" : [ 0, 12 ],
      "id_str" : "137856929",
      "id" : 137856929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68578223788797952",
  "geo" : { },
  "id_str" : "68580286300041216",
  "in_reply_to_user_id" : 137856929,
  "text" : "@informcentr Congrats!",
  "id" : 68580286300041216,
  "in_reply_to_status_id" : 68578223788797952,
  "created_at" : "2011-05-12 07:36:29 +0000",
  "in_reply_to_screen_name" : "informcentr",
  "in_reply_to_user_id_str" : "137856929",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67583134790721536",
  "text" : "\u0421\u0430\u043C\u043E\u0435 \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u043E\u0435 \u0432 \u043A\u0430\u043A\u0438\u0445 \u0431\u044B \u0442\u043E \u043D\u0438 \u0431\u044B\u043B\u043E \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430\u0445 - \u044D\u0442\u043E \u043F\u0430\u0440\u043E\u043B\u0438 )",
  "id" : 67583134790721536,
  "created_at" : "2011-05-09 13:34:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67582643256049664",
  "text" : "\u0410 \u0432\u043E\u043E\u0431\u0449\u0435, \u043F\u043E\u043B\u044C\u0437\u0443\u044E\u0441\u044C \u043F\u0440\u043E\u0441\u0442\u043E\u0439 \u0441\u0430\u043C\u043E\u043D\u0430\u043F\u0438\u0441\u0430\u043D\u043D\u043E\u0439 \u043D\u0430 cpp, \u043F\u0440\u0435\u043E\u0431\u0440\u0430\u0437\u0443\u044E\u0449\u0435\u0439 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u0434\u043E\u043C\u0435\u043D\u0430 \u0432 \u043F\u0430\u0441\u0441 \u043F\u043E \u043D\u0435\u043A \u043A\u043B\u044E\u0447\u0443",
  "id" : 67582643256049664,
  "created_at" : "2011-05-09 13:32:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67582036755488768",
  "text" : "\u0414\u0435\u0439\u0441\u0442\u0432\u0438\u0442\u0435\u043B\u044C\u043D\u043E, \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u044E \u043D\u0435\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u043C\u043D\u0435\u043C\u043E\u0442\u0435\u0445\u043D\u0438\u043A, \u0432 \u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E\u0441\u0442\u0438 \u043E\u0442 \u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D\u0438\u0439 \u0434\u043B\u0438\u043D\u043D\u044B \u0438 \u0432\u0438\u0434\u043E\u0432 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0445 \u0441\u0438\u043C\u0432\u043E\u043B\u043E\u0432.",
  "id" : 67582036755488768,
  "created_at" : "2011-05-09 13:29:47 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "67580884018147329",
  "text" : "\u0412\u0441\u0435 \u0435\u0449\u0435 \u043F\u043E\u0434\u0432\u0435\u0440\u0436\u0435\u043D \u0437\u043D\u0430\u043A\u043E\u043C\u043E\u043C\u0443 \u0432\u0441\u0435\u043C \u0432\u0435\u0431\u043C\u0430\u0441\u0442\u0435\u0440\u0430\u043C \u0441\u0438\u043D\u0434\u0440\u043E\u043C\u0443 - \u043C\u0430\u0448\u0438\u043D\u0430\u043B\u044C\u043D\u043E \u0432\u0432\u043E\u0436\u0443 admin \u0432 \u043B\u043E\u0433\u0438\u043D\u0430\u0445 \u0437\u043D\u0430\u043A\u043E\u043C\u044B\u0445 \u0441\u0430\u0439\u0442\u043E\u0432.",
  "id" : 67580884018147329,
  "created_at" : "2011-05-09 13:25:13 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66171260723396608",
  "text" : "\u041F\u043E\u0437\u0432\u043E\u043D\u0438\u043B \u0437\u043D\u0430\u043A\u043E\u043C\u044B\u0439 \u0438\u043D\u0432\u0435\u0441\u0442\u043E\u0440 -\u0437\u0430\u0438\u043D\u0442\u0435\u0440\u0435\u0441\u043E\u0432\u0430\u043B\u0441\u044F \u0442\u0435\u043C, \u0447\u0442\u043E \u043C\u043D\u043E\u0433\u0438\u0435 \u0441\u043E \u0441\u0432\u0435\u0436\u0438\u043C\u0438 \u043F\u043E\u0437\u0438\u0446\u0438\u044F\u043C\u0438 \u0441\u0435\u0439\u0447\u0430\u0441 \u0443\u0441\u0440\u0435\u0434\u043D\u044F\u044E\u0442\u0441\u044F. \u0412\u0435\u0447\u0435\u0440 \u0442\u0435\u0445 \u0430\u043D\u0430\u043B\u0438\u0437\u0430.",
  "id" : 66171260723396608,
  "created_at" : "2011-05-05 16:03:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66157387618320384",
  "text" : "\u0412 \u043A\u043E\u043C\u043F \u0438\u0433\u0440\u0435 \u043E\u0447\u0435\u0432\u0438\u0434\u043D\u0430 \u0441\u0432\u044F\u0437\u044C \u043C\u0435\u0436\u0434\u0443 \u0443\u0441\u0438\u043B\u0438\u0435\u043C \u0438 \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u043E\u043C:\u043D\u0435 \u0431\u044B\u0432\u0430\u0435\u0442 \u0442\u0430\u043A, \u0447\u0442\u043E\u0431\u044B \u0434\u0435\u0439\u0441\u0442\u0432\u0438\u044F \u0438\u0433\u0440\u043E\u043A\u0430, \u0432\u0441\u0435 \u0434\u0435\u043B\u0430\u044E\u0449\u0435\u0433\u043E \u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u043E, \u043D\u0435 \u043F\u0440\u0438\u043D\u043E\u0441\u0438\u043B\u0438 \u0431\u044B \u043F\u043B\u043E\u0434\u043E\u0432",
  "id" : 66157387618320384,
  "created_at" : "2011-05-05 15:08:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65112642376830976",
  "text" : "\u0421\u0448\u0430 \u043B\u0438\u043A\u0432\u0438\u0434\u0438\u0440\u043E\u0432\u0430\u043D\u044B, \u043F\u043E\u0441\u043B\u0435 \u0447\u0435\u0433\u043E \u0438\u0445 \u043E\u0441\u0442\u0430\u043D\u043A\u0438 \u0431\u044B\u043B\u0438 \u0438\u0434\u0435\u043D\u0442\u0438\u0444\u0438\u0446\u0438\u0440\u043E\u0432\u0430\u043D\u044B \u0447\u0435\u0440\u0435\u0437 \u0442\u0435\u0441\u0442 \u0434\u043D\u043A \u0438 \u0437\u0430\u0445\u043E\u0440\u043E\u043D\u0435\u043D\u044B \u043F\u043E\u0434 \u0432\u043E\u0434\u043E\u0439; didn't want a grave to become a shrine",
  "id" : 65112642376830976,
  "created_at" : "2011-05-02 17:57:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65111165285572609",
  "text" : "\u041F\u043E\u0441\u043A\u043E\u043B\u044C\u043A\u0443 \u0438\u043C\u044F \u041E\u0441\u0430\u043C\u0430 \u043F\u0440\u0435\u0434\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 \u0437\u0430\u0449\u0438\u0442\u043D\u0443\u044E \u0430\u0433\u0440\u0435\u0441\u0441\u0438\u044E, \u043F\u043E\u0441\u0442\u043E\u043B\u044C\u043A\u0443 \u043D\u0430\u0438\u0432\u043D\u0430 \u0441\u043C\u0435\u0440\u0442\u044C \u043E\u0442 \u0431\u0443\u043A\u0432\u044B\/\u0440\u0443\u043A\u0438 \u0441\u0438\u043C\u043C\u0435\u0442\u0440\u0438\u0447\u043D\u043E\u0433\u043E \u0440\u0443\u043A\u043E\u0432\u043E\u0434\u0441\u0442\u0432\u0430 (\u0441\u043C\u0435\u0440\u0442\u044C \u043F\u043E \u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u0438\u044E)",
  "id" : 65111165285572609,
  "created_at" : "2011-05-02 17:51:26 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64576384164560896",
  "text" : "Tingley, D.  2006.  Neurological Imaging as Evidence in Political Science: A Review, Critique, and Guiding Assessment. Soc. Sc. Inform. 45.",
  "id" : 64576384164560896,
  "created_at" : "2011-05-01 06:26:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maria",
      "screen_name" : "pervomaj",
      "indices" : [ 0, 9 ],
      "id_str" : "46336383",
      "id" : 46336383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64567910663852032",
  "geo" : { },
  "id_str" : "64575864960057344",
  "in_reply_to_user_id" : 46336383,
  "text" : "@pervomaj \u041F\u043E\u0437\u0434\u0440\u0430\u0432\u043B\u044F\u044E!",
  "id" : 64575864960057344,
  "in_reply_to_status_id" : 64567910663852032,
  "created_at" : "2011-05-01 06:24:20 +0000",
  "in_reply_to_screen_name" : "pervomaj",
  "in_reply_to_user_id_str" : "46336383",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]