Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/L2Es1NIq",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=_sUeGC-8dyk",
      "display_url" : "youtube.com\/watch?v=_sUeGC\u2026"
    }, {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/S8sLd4Nv",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=V1E0DrAbN2I",
      "display_url" : "youtube.com\/watch?v=V1E0Dr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "175044836125179904",
  "text" : "http:\/\/t.co\/L2Es1NIq \"Robot Quadrotors Perform James Bond Theme\" = http:\/\/t.co\/S8sLd4Nv",
  "id" : 175044836125179904,
  "created_at" : "2012-03-01 02:28:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174487969309278208",
  "text" : "Yuval-Davis? \u0421\u043B\u044B\u0448\u0430\u043B.",
  "id" : 174487969309278208,
  "created_at" : "2012-02-28 13:35:48 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174483090759098369",
  "text" : "\u0423\u0447\u0435\u043D\u044B\u0439 \u0441\u043E\u0432\u0435\u0442 \u0444\u0430\u043A\u0443\u043B\u044C\u0442\u0435\u0442\u0430 \u041F\u041F \u0412\u0428\u042D \u0437\u0430\u043E\u0434\u043D\u043E \u0438\u043D\u0441\u0446\u0435\u043D\u0438\u0440\u0443\u0435\u0442 \u0437\u0430\u0433\u043E\u0442\u043E\u0432\u043A\u0438 \u043A\u043E\u043C\u0435\u0434\u0438\u0438 \u043F\u043E\u043B\u043E\u0436\u0435\u043D\u0438\u0439, \u043A\u0430\u0436\u0434\u0443\u044E \u0432\u0442\u043E\u0440\u0443\u044E \u0440\u0435\u043F\u043B\u0438\u043A\u0443 \u043F\u0440\u043E\u0438\u0437\u043D\u043E\u0441\u044F\u0442 \u0432 \u0448\u0443\u0442\u043A\u0443, \u0448\u0443\u0442\u044F\u0442 \u0432\u0441\u0435 \u0447\u043B\u0435\u043D\u044B.",
  "id" : 174483090759098369,
  "created_at" : "2012-02-28 13:16:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/c2YAWJWT",
      "expanded_url" : "http:\/\/habrahabr.ru\/blogs\/hr\/138912",
      "display_url" : "habrahabr.ru\/blogs\/hr\/138912"
    } ]
  },
  "geo" : { },
  "id_str" : "174307584206057475",
  "text" : "http:\/\/t.co\/c2YAWJWT \"NewHuman = human:do_something_with_human(Human, Human#human.human), do_something_with_human(Human, coffee) -&gt;.coffee\"",
  "id" : 174307584206057475,
  "created_at" : "2012-02-28 01:39:01 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.azumio.com\" rel=\"nofollow\"\u003EAzumio\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instantheartrate",
      "indices" : [ 24, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/bp3EeeXB",
      "expanded_url" : "http:\/\/goo.gl\/4x4uz",
      "display_url" : "goo.gl\/4x4uz"
    } ]
  },
  "geo" : { },
  "id_str" : "174189852659695616",
  "text" : "My heart rate is 68bpm. #instantheartrate http:\/\/t.co\/bp3EeeXB",
  "id" : 174189852659695616,
  "created_at" : "2012-02-27 17:51:11 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.azumio.com\" rel=\"nofollow\"\u003EAzumio\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Haste",
      "indices" : [ 0, 6 ]
    }, {
      "text" : "instantheartrate",
      "indices" : [ 32, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/bp3EeeXB",
      "expanded_url" : "http:\/\/goo.gl\/4x4uz",
      "display_url" : "goo.gl\/4x4uz"
    } ]
  },
  "geo" : { },
  "id_str" : "174014394085277696",
  "text" : "#Haste. My heart rate is 46bpm. #instantheartrate http:\/\/t.co\/bp3EeeXB",
  "id" : 174014394085277696,
  "created_at" : "2012-02-27 06:13:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173471391386050562",
  "text" : "+ \"J'accuse\" \u0413\u0440\u0438\u043D\u0443\u044D\u044F, \u0434\u043E\u043A\u0443\u043C\u0435\u043D\u0442\u0430\u043B\u044C\u043D\u043E\u0435 \u0440\u0430\u0441\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043D\u0438\u0435 \u0441\u043C\u044B\u0441\u043B\u0430 \u043A\u043E\u043C\u043F\u043E\u0437\u0438\u0446\u0438\u0438 \u043A\u0430\u0440\u0442\u0438\u043D\u044B \"\u041D\u043E\u0447\u043D\u043E\u0439 \u0414\u043E\u0437\u043E\u0440\" \u0420\u0435\u043C\u0431\u0440\u0430\u043D\u0434\u0442\u0430, \u043E\u043A\u0430\u0437\u044B\u0432\u0430\u044E\u0449\u0435\u0439\u0441\u044F \u0441\u0443\u0434\u0435\u0431\u043D\u044B\u043C \u0432\u0435\u0440\u0434\u0438\u043A\u0442\u043E\u043C.",
  "id" : 173471391386050562,
  "created_at" : "2012-02-25 18:16:17 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173468829450637312",
  "text" : "\u041E\u0446\u0435\u043D\u0438\u043B \u043F\u043E \u0434\u043E\u0441\u0442\u043E\u0438\u043D\u0441\u0442\u0432\u0443 \u0445\u043E\u043B\u043E\u0441\u0442\u043E\u0439 \u0441\u0438\u043C\u0432\u043E\u043B\u0438\u0437\u043C \"\u0421\u0442\u044B\u0434\u0430\" \u041C\u0430\u043A\u043A\u0443\u0438\u043D\u0430, \u043A\u0438\u043D\u043E \u043E \u0441\u043A\u0438\u0442\u0430\u043D\u0438\u044F\u0445 \u044D\u0440\u043E\u0442\u043E\u043C\u0430\u043D\u0430, \u0430\u043D\u0442\u0438\u043F\u043E\u0434\u0430 \u0433\u0435\u0440\u043E\u044F \"\u043F\u0440\u0435\u0434\u0435\u043B\u043E\u0432 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044F\".",
  "id" : 173468829450637312,
  "created_at" : "2012-02-25 18:06:06 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0430 \u043F\u0435\u0440\u0435\u0434\u0430\u0447",
      "screen_name" : "informcentr",
      "indices" : [ 0, 12 ],
      "id_str" : "137856929",
      "id" : 137856929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "173038587598733313",
  "geo" : { },
  "id_str" : "173043246640013312",
  "in_reply_to_user_id" : 137856929,
  "text" : "@informcentr \u044D\u043A\u0441\u043F\u0435\u043A\u0442\u043E \u043F\u0430\u0442\u0440\u043E\u043D\u0443\u043C",
  "id" : 173043246640013312,
  "in_reply_to_status_id" : 173038587598733313,
  "created_at" : "2012-02-24 13:54:59 +0000",
  "in_reply_to_screen_name" : "informcentr",
  "in_reply_to_user_id_str" : "137856929",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/lt8SK6aL",
      "expanded_url" : "http:\/\/grimstopmo.blogspot.com\/p\/about-this-project.html",
      "display_url" : "grimstopmo.blogspot.com\/p\/about-this-p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "173042437055463424",
  "text" : "http:\/\/t.co\/lt8SK6aL  Sudden, unbearable icepick of a tasty morsel in my eyebrow.",
  "id" : 173042437055463424,
  "created_at" : "2012-02-24 13:51:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172749112192667648",
  "text" : "\u041F\u043E\u0440\u0430 \u043F\u0435\u0440\u0435\u0441\u0442\u0430\u0442\u044C \u043E\u0431\u043C\u0430\u043D\u044B\u0432\u0430\u0442\u044C \u0441\u0435\u0431\u044F \u0438 \u043E\u0431\u043D\u043E\u0432\u0438\u0442\u044C \u043F\u0440\u0438\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \"\u043A\u0430\u043A \u0437\u0430\u0432\u044F\u0437\u0430\u0442\u044C \u0448\u0430\u0440\u0444\".",
  "id" : 172749112192667648,
  "created_at" : "2012-02-23 18:26:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/v9EgaBMr",
      "expanded_url" : "http:\/\/4sq.com\/Adz4h8",
      "display_url" : "4sq.com\/Adz4h8"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7262158907, 37.5855588913 ]
  },
  "id_str" : "172740621398843392",
  "text" : "I'm at \u0421\u0420\u0415\u0414\u0418 \u0421\u0412\u041E\u0418\u0425 - \u0435\u0432\u0440\u0435\u0439\u0441\u043A\u0430\u044F \u043E\u0431\u0449\u0438\u043D\u0430 + EZRA FSU (1-\u044F \u0424\u0440\u0443\u043D\u0437\u0435\u043D\u0441\u043A\u0430\u044F, 5, \u041C\u043E\u0441\u043A\u0432\u0430) http:\/\/t.co\/v9EgaBMr",
  "id" : 172740621398843392,
  "created_at" : "2012-02-23 17:52:28 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172739423207821312",
  "text" : "\u0412\u0441\u0435\u0445 \u0441 \u0434\u043D\u0435\u043C \u0431\u0435\u0441\u0430, \u0438 \u043D\u0435 \u0436\u0430\u043B\u0435\u0439\u0442\u0435 \u0437\u0430\u0432\u0430\u0440\u043A\u0438 \u0434\u043B\u044F \u0447\u0430\u0439\u043D\u044B\u0445 \u0432\u0435\u0447\u0435\u0440\u0438\u043D\u043E\u043A.",
  "id" : 172739423207821312,
  "created_at" : "2012-02-23 17:47:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172738687753396224",
  "text" : "\u0412\u0442\u043E\u0440\u043E\u0439 \u043C\u0435\u0441\u044F\u0446, \u043F\u0435\u0440\u0438\u043E\u0434\u0438\u0447\u0435\u0441\u043A\u0438, \u043D\u0435 \u0432\u044B\u0441\u044B\u043F\u0430\u044F\u0441\u044C, \u043F\u044B\u0442\u0430\u044E\u0441\u044C \u043F\u0440\u043E\u0439\u0442\u0438 \u0432 \u043C\u0435\u0442\u0440\u043E \u043F\u043E \u043F\u0440\u0435\u0437\u0435\u0440\u0432\u0430\u0442\u0438\u0432\u0443. \u0418\u043D\u043E\u0433\u0434\u0430  \u043D\u0435 \u043F\u043E\u043B\u0443\u0447\u0430\u0435\u0442\u0441\u044F.",
  "id" : 172738687753396224,
  "created_at" : "2012-02-23 17:44:47 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172733288346169344",
  "text" : "\u041F\u0440\u0438\u044F\u0442\u043D\u044B\u0439 \u043C\u043E\u043C\u0435\u043D\u0442 -  $13k \u0441\u0442\u043E\u0440\u043E\u043D\u043D\u0438\u0445 \u0438\u043D\u0432\u0435\u0441\u0442\u0438\u0446\u0438\u0439 \u0432 \u0441\u0442\u0443\u0434\u0438\u044E. \u0447\u0435\u0440\u0435\u0437 napartner.ru .",
  "id" : 172733288346169344,
  "created_at" : "2012-02-23 17:23:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171286201561653248",
  "text" : "The survival of truth after Kurginyan: thinking \u201CIt's a joke, I nearly do not accept\u201D and another yes-laugh reaffirmative ring acts",
  "id" : 171286201561653248,
  "created_at" : "2012-02-19 17:33:07 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171283816722337792",
  "text" : "The Devil Reads Derrida and Other Essays on the University, the Church, Politics, and the Arts",
  "id" : 171283816722337792,
  "created_at" : "2012-02-19 17:23:38 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171274694366990336",
  "text" : "Galetti, Dino R.(2010) 'Looking for a Logic in Derrida: Assessing Hurst's \u201CPlural Logic of the Aporia\u201D', Journ of Lit-ry Studies,26:3,84-109",
  "id" : 171274694366990336,
  "created_at" : "2012-02-19 16:47:23 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/2N4QxNKC",
      "expanded_url" : "http:\/\/www.kickstarter.com\/projects\/66710809\/double-fine-adventure",
      "display_url" : "kickstarter.com\/projects\/66710\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "169487010690629632",
  "text" : "http:\/\/t.co\/2N4QxNKC\n\n$400 k - \u043D\u0435 \u0434\u0435\u043D\u044C\u0433\u0438 \u0434\u043B\u044F \u043F\u043E\u043A\u043B\u043E\u043D\u043D\u0438\u043A\u043E\u0432, \u0435\u0441\u043B\u0438 \u0441\u043E\u0437\u0434\u0430\u0435\u0448\u044C p&c adv \u0438 \u0442\u0435\u0431\u044F \u0437\u043E\u0432\u0443\u0442 \u0422\u0438\u043C \u0428\u0435\u0444\u0435\u0440",
  "id" : 169487010690629632,
  "created_at" : "2012-02-14 18:23:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/UIsTX6H3",
      "expanded_url" : "http:\/\/4sq.com\/xlYIDE",
      "display_url" : "4sq.com\/xlYIDE"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7455143616, 37.6050783059 ]
  },
  "id_str" : "167648815892008960",
  "text" : "I'm at \u0410\u043A\u0430\u0434\u0435\u043C\u0438\u044F (\u0443\u043B. \u0412\u043E\u043B\u0445\u043E\u043D\u043A\u0430 \u0434.15\/17, \u041C\u043E\u0441\u043A\u0432\u0430) w\/ 2 others http:\/\/t.co\/UIsTX6H3",
  "id" : 167648815892008960,
  "created_at" : "2012-02-09 16:39:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/1XOJjJHP",
      "expanded_url" : "http:\/\/4sq.com\/yYLABm",
      "display_url" : "4sq.com\/yYLABm"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7406564357, 37.6090550423 ]
  },
  "id_str" : "167637102241124352",
  "text" : "I'm at Digital October (\u0411\u0435\u0440\u0435\u0441\u043D\u0435\u0432\u0441\u043A\u0430\u044F \u043D\u0430\u0431., 6 \u0441\u0442\u0440. 3, \u041C\u043E\u0441\u043A\u0432\u0430) w\/ 45 others http:\/\/t.co\/1XOJjJHP",
  "id" : 167637102241124352,
  "created_at" : "2012-02-09 15:52:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167297539475902464",
  "text" : "Thou staying within stayforwards, \u043E\u043F\u0435\u0440\u0438\u0440\u0443\u044F \u0432\u043E \u0432\u043F\u043B\u043E\u0442\u043D\u0443\u044E \u043F\u0440\u0438\u043C\u044B\u043A\u0430\u044E\u0449\u0438\u0445 \u0434\u0440\u0443\u0433 \u043A \u0434\u0440\u0443\u0433\u0443 \u0444\u043B\u0435\u0448\u0444\u043E\u0440\u0432\u0430\u0440\u0434\u0430\u0445 \u043D\u0435 \u043F\u0435\u0440\u0435\u0441\u0442\u0430\u0435\u0448\u044C \u0441\u0447\u0438\u0442\u0430\u0442\u044C snapshots \u0437\u0430 flashbacks.",
  "id" : 167297539475902464,
  "created_at" : "2012-02-08 17:23:36 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165920470800154624",
  "text" : "\u0412 \u043A\u0430\u043A\u043E\u043C \u043A\u0440\u0443\u0433\u0435 \u0430\u0434\u0430 \u043F\u0435\u0440\u0435\u043A\u0440\u043E\u0435\u043C\u0441\u044F \u0441\u0435\u0433\u043E\u0434\u043D\u044F? \u0432\u0438\u043D\u0430 \u043D\u0435 \u0437\u043D\u0430\u0435\u0442 \u0438\u0441\u043A\u0443\u043F\u043B\u0435\u043D\u0438\u044F, \u0430\u0434 \u043D\u0435\u0438\u0437\u0431\u044B\u0432\u0435\u043D, \u0438\u043D\u0442\u0435\u043D\u0441\u0438\u0432\u043D\u043E\u0441\u0442\u044C \u0438 \u0432\u043E\u0441\u043F\u0440\u043E\u0438\u0437\u0432\u043E\u0434\u0441\u0442\u0432\u043E-\u043B\u0443\u0447\u0448\u0438\u0435 \u0441\u043F\u043E\u0441\u043E\u0431\u044B \u0442\u043E\u043F\u0438\u0442\u044C \u043F\u0435\u0447\u044C",
  "id" : 165920470800154624,
  "created_at" : "2012-02-04 22:11:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/1DnIHe0Z",
      "expanded_url" : "http:\/\/4sq.com\/A08DcQ",
      "display_url" : "4sq.com\/A08DcQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.759816, 37.622504 ]
  },
  "id_str" : "165907598401486849",
  "text" : "I'm at \u041A\u043B\u0443\u0431-\u0442\u0435\u0430\u0442\u0440 \u00AB\u041C\u0430\u0441\u0442\u0435\u0440\u0441\u043A\u0430\u044F\u00BB (\u0422\u0435\u0430\u0442\u0440\u0430\u043B\u044C\u043D\u044B\u0439 \u043F\u0440\u043E\u0435\u0437\u0434, 3, \u041C\u043E\u0441\u043A\u0432\u0430) w\/ 4 others http:\/\/t.co\/1DnIHe0Z",
  "id" : 165907598401486849,
  "created_at" : "2012-02-04 21:20:28 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/8Uzl6kTW",
      "expanded_url" : "http:\/\/4sq.com\/wWffEA",
      "display_url" : "4sq.com\/wWffEA"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7655498, 37.610998 ]
  },
  "id_str" : "165867600625152000",
  "text" : "I'm at ArteFAQ (\u0411. \u0414\u043C\u0438\u0442\u0440\u043E\u0432\u043A\u0430, 32, \u041C\u043E\u0441\u043A\u0432\u0430) w\/ 10 others http:\/\/t.co\/8Uzl6kTW",
  "id" : 165867600625152000,
  "created_at" : "2012-02-04 18:41:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]