Grailbird.data.tweets_2011_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "30152966409297920",
  "text" : "\u041B\u0435\u0436\u0443 \u0432 \u0448\u043A\u043E\u043B\u044C\u043D\u043E\u043C \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u043C \u043A\u0430\u0431\u0438\u043D\u0435\u0442\u0435 \u043D\u0430 \u0441\u0442\u043E\u043C\u0430\u0442\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u043A\u0440\u0435\u0441\u043B\u0435. Wifi \u0435\u0441\u0442\u044C ) http:\/\/yfrog.com\/gytvreij",
  "id" : 30152966409297920,
  "created_at" : "2011-01-26 06:40:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "25608405741740032",
  "text" : "http:\/\/yfrog.com\/h5lu6rj http:\/\/yfrog.com\/h5drdzhj",
  "id" : 25608405741740032,
  "created_at" : "2011-01-13 17:41:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "24153318074884097",
  "text" : "\u0418\u0443\u0437\u043C2 \u0431\u0435\u0437 illus fish. \u041F\u0440\u044F\u043C\u043E \u0441\u0435\u0439\u0447\u0430\u0441 \u043D\u0430\u0441 \u0441 \u041C\u0430\u0448\u0435\u0439 \u0447\u0435\u0440\u0435\u0437 \u0437\u0430\u0431\u0440\u0430\u043B\u043E \u0434\u0432\u0443\u0445\u043C\u0435\u0442\u0440\u043E\u0432\u043E\u0439 \u0442\u0440\u0443\u0431\u044B \u043E\u0431\u0434\u0443\u0432\u0430\u0435\u0442 \u0441\u0432\u043E\u0438\u043C \u043F\u0440\u043E\u043A\u0443\u0440\u0435\u043D\u043D\u044B\u043C \u0442\u0443\u0432\u0438\u043D\u0441\u043A\u0438\u043C \u0433\u043E\u043B\u043E\u0441\u043E\u043C \u043B\u044B\u0441\u044B\u0439 \u0440\u043E\u0437\u0435\u043D\u0431\u0430\u0443\u043C",
  "id" : 24153318074884097,
  "created_at" : "2011-01-09 17:19:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21865757935673344",
  "text" : "http:\/\/yfrog.com\/h2jxvoqj",
  "id" : 21865757935673344,
  "created_at" : "2011-01-03 09:49:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "21857623754145792",
  "text" : "\u0417\u0430\u043F\u0438\u0441\u044C",
  "id" : 21857623754145792,
  "created_at" : "2011-01-03 09:17:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]