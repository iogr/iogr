Grailbird.data.tweets_2016_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "748513253127491585",
  "text" : "has_many :through",
  "id" : 748513253127491585,
  "created_at" : "2016-06-30 13:47:20 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746795107924455425",
  "text" : "yeah, yeah\u2026     \u05D5\u05D9\u05D1\u05DF \u05D9\u05D4\u05D5\u05D4 \u05D0\u05DC\u05D4\u05D9\u05DD \u05D0\u05EA \u05D4\u05E6\u05DC\u05E2",
  "id" : 746795107924455425,
  "created_at" : "2016-06-25 20:00:03 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "746454033456566273",
  "text" : "Darius Milhaud",
  "id" : 746454033456566273,
  "created_at" : "2016-06-24 21:24:44 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "745644980492996608",
  "text" : "\u0420\u043E\u0441\u043A\u043E\u043C\u043D\u0430\u0434\u0437\u043E\u0440 \u0437\u0430\u0431\u0430\u043D\u0438\u043B Amazon S3, \u0441\u043A\u043E\u0440\u043E \u0438 \u0442\u0435\u0431\u044F \u0437\u0430\u0431\u0430\u043D\u0438\u0442",
  "id" : 745644980492996608,
  "created_at" : "2016-06-22 15:49:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "743843709481943040",
  "text" : "20.59",
  "id" : 743843709481943040,
  "created_at" : "2016-06-17 16:32:14 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742481960744935424",
  "text" : "Dear Bethesda, please tear smn in you staff whos getting over-cranky when each upcoming release is not visially similar to the elder scrolls",
  "id" : 742481960744935424,
  "created_at" : "2016-06-13 22:21:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742294818525728768",
  "text" : "\u0411\u0440\u0430\u0437\u0438\u043B\u0438\u044F \u0418\u043F\u0430\u043D\u0435\u043C\u0430 \u0420\u0443\u0431\u0438",
  "id" : 742294818525728768,
  "created_at" : "2016-06-13 09:57:30 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "742258433471217664",
  "text" : "\u0417\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u0435\u0448\u044C \u0430\u0434\u0440\u0435\u0441? \u041D\u0435\u0431\u0435\u0441\u043D\u044B\u0439 \u0421\u0442\u043E\u043A\u0433\u043E\u043B\u044C\u043C, \u043E\u0441\u0442\u0440\u043E\u0432 \u0418\u0442\u0430\u043A\u0430, \u0413\u0435\u043B\u044C\u0432\u0435\u0446\u0438\u0439 \u0441 \u043C\u0438\u043D\u0438-\u043F\u0435\u0442\u0435\u0440\u0431\u0443\u0440\u0433\u043E\u043C \u0438 \u0441\u0430\u0443\u043D\u043E\u0439 \u0441 \u043B\u043E\u043D\u0434\u043E\u043D\u0441\u043A\u0438\u043C \u0442\u0443\u043C\u0430\u043D\u043E\u043C, \u0441\u0435\u043C\u044C\u0435 \u043E\u0440\u043D\u0438\u0442\u043E\u043B\u043E\u0433\u0430 LoremIpsum",
  "id" : 742258433471217664,
  "created_at" : "2016-06-13 07:32:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741957328279343105",
  "text" : "Lorem Ipsum Inc.",
  "id" : 741957328279343105,
  "created_at" : "2016-06-12 11:36:26 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "741657547732570112",
  "text" : "\u0411\u0435\u043D \u042D\u043B\u0442\u043E\u043D 4\/15",
  "id" : 741657547732570112,
  "created_at" : "2016-06-11 15:45:13 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "739887421584723968",
  "text" : "\u0421\u0438\u043D\u0434\u0440\u043E\u043C \u0432\u043E\u0441\u043F\u0440\u0438\u044F\u0442\u0438\u044F \u0434\u0438\u0441\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u043E\u0439 \u0438 \u0433\u0435\u0448\u0442\u0430\u043B\u044C\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u043E\u0439 \u043F\u043B\u043E\u0441\u043A\u043E\u0441\u0442\u0438 - \u043F\u0440\u0438\u0437\u043D\u0430\u043A \u0440\u0430\u0437\u0432\u0438\u0442\u043E\u0439 \u044D\u043C\u043E\u0446\u0438\u043E\u043D\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438. \u041F\u043E\u043D\u044F\u0442\u0438\u0435  \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u043A\u043E\u0440\u043C\u0438\u0442 \u0437\u0430\u0432\u0442\u0440\u0430\u043A\u0430\u043C\u0438.",
  "id" : 739887421584723968,
  "created_at" : "2016-06-06 18:31:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "737994925183250432",
  "text" : "richard pinhas &amp; oren ambarchi",
  "id" : 737994925183250432,
  "created_at" : "2016-06-01 13:11:16 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]