Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660485919972139008",
  "text" : "Roots Manuva",
  "id" : 660485919972139008,
  "created_at" : "2015-10-31 15:58:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660419381231550465",
  "text" : "The Disco Zombies",
  "id" : 660419381231550465,
  "created_at" : "2015-10-31 11:33:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659796688136241153",
  "text" : "\u0412\u0441\u044E\u0434\u0443 \u0441 \u0442\u043E\u0431\u043E\u0439 \u0431\u0440\u043E\u0434\u0438\u043B\u0438 \u043D\u0435\u0432\u0438\u0434\u0438\u043C\u044B\u0435 \u0443\u0437\u043B\u044B \u043D\u0435\u0432\u0438\u0434\u0438\u043C\u044B\u0435 \u0443\u0437\u043B\u044B \u043F\u043E\u043B\u044F\u0440\u0438\u0437\u043E\u0432\u0430\u043D\u043D\u044B\u0435 \u043F\u043E\u0442\u043E\u043A\u0438",
  "id" : 659796688136241153,
  "created_at" : "2015-10-29 18:19:23 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658352339850514436",
  "text" : "\u0413\u0440\u0443\u0441\u0442\u044C",
  "id" : 658352339850514436,
  "created_at" : "2015-10-25 18:40:04 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656601038607241216",
  "text" : "\u043D\u043E\u0447\u043D\u043E\u0439 \u043C\u043E\u0446\u0430\u0440\u0442 (Sonata for piano and violin in F, K.377 - II), \u043D\u043E\u0447\u043D\u043E\u0439 \u0444\u0438\u043B\u0438\u043F\u043F \u0433\u043B\u0430\u0441\u0441 (I \u043A\u043E\u043D\u0446\u0435\u0440\u0442 \u0434\u043B\u044F \u0432\u0438\u043E\u043B\u043E\u043D\u0447\u0435\u043B\u0438 \u0441 \u043E\u0440\u043A\u0435\u0441\u0442\u0440\u043E\u043C)",
  "id" : 656601038607241216,
  "created_at" : "2015-10-20 22:41:01 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]