Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207769858048393216",
  "text" : "FragonBox+ 5",
  "id" : 207769858048393216,
  "created_at" : "2012-05-30 09:46:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/jGZWHhTg",
      "expanded_url" : "http:\/\/instagr.am\/p\/LK4P1cq9BR\/",
      "display_url" : "instagr.am\/p\/LK4P1cq9BR\/"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.8048810294, 37.5850510841 ]
  },
  "id_str" : "207143904309551105",
  "text" : "Have five more sculptures http:\/\/t.co\/jGZWHhTg",
  "id" : 207143904309551105,
  "created_at" : "2012-05-28 16:18:49 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Verso Books",
      "screen_name" : "VersoBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "23187207",
      "id" : 23187207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/nda7IJ6P",
      "expanded_url" : "http:\/\/www.versobooks.com\/blogs\/1021-zizek-featured-in-the-onion-we-fill-in-the-blanks",
      "display_url" : "versobooks.com\/blogs\/1021-ziz\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207072259083468800",
  "text" : "RT @VersoBooks: In case you didn't see this at the end of last  week - Zizek in the Onion - how to wow him in bed: http:\/\/t.co\/nda7IJ6P",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/nda7IJ6P",
        "expanded_url" : "http:\/\/www.versobooks.com\/blogs\/1021-zizek-featured-in-the-onion-we-fill-in-the-blanks",
        "display_url" : "versobooks.com\/blogs\/1021-ziz\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "207068733141823489",
    "text" : "In case you didn't see this at the end of last  week - Zizek in the Onion - how to wow him in bed: http:\/\/t.co\/nda7IJ6P",
    "id" : 207068733141823489,
    "created_at" : "2012-05-28 11:20:07 +0000",
    "user" : {
      "name" : "Verso Books",
      "screen_name" : "VersoBooks",
      "protected" : false,
      "id_str" : "23187207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/889515094572486657\/xtlkvZ7__normal.jpg",
      "id" : 23187207,
      "verified" : false
    }
  },
  "id" : 207072259083468800,
  "created_at" : "2012-05-28 11:34:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/DOD3zokx",
      "expanded_url" : "http:\/\/img.ly\/iKZs",
      "display_url" : "img.ly\/iKZs"
    } ]
  },
  "geo" : { },
  "id_str" : "206540001545170945",
  "text" : "http:\/\/t.co\/DOD3zokx  Folks with whom we're all acquainted.             Aren't so handsome as they're painted.",
  "id" : 206540001545170945,
  "created_at" : "2012-05-27 00:19:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/ZPbXfRrg",
      "expanded_url" : "http:\/\/img.ly\/iKZ7",
      "display_url" : "img.ly\/iKZ7"
    } ]
  },
  "geo" : { },
  "id_str" : "206538397773332480",
  "text" : "http:\/\/t.co\/ZPbXfRrg Flattering courtier make poor martyrs. Who was Fing of the Crim Tartars?",
  "id" : 206538397773332480,
  "created_at" : "2012-05-27 00:12:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206000774231244801",
  "text" : "\u041F\u0440\u043E\u0434\u0430\u043B 30% \u043F\u0440\u0438\u0431\u044B\u043B\u0438 \u043E\u0442 \u0438\u043D\u0441\u0442\u0430\u0433\u0440\u0430\u0444\u0430 \u0435\u0449\u0435 \u0434\u043E \u0440\u0435\u043B\u0438\u0437\u0430. :\\ \u0442\u0435\u043F\u0435\u0440\u044C, \u0445\u043E\u0442\u044F \u0431\u044B, \u043C\u043E\u0436\u043D\u043E \u043D\u0435 \u0434\u0443\u043C\u0430\u0442\u044C \u043E \u0437\u0430\u0440\u043F\u043B\u0430\u0442\u0430\u0445",
  "id" : 206000774231244801,
  "created_at" : "2012-05-25 12:36:26 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hipster.com\" rel=\"nofollow\"\u003EHipster\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hipster",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/u4CA5zVu",
      "expanded_url" : "http:\/\/hpstr.co\/JKNtL2",
      "display_url" : "hpstr.co\/JKNtL2"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.76786, 37.599506 ]
  },
  "id_str" : "205596227876827136",
  "text" : "Just sent a postcard from Starbucks, \u041C\u043E\u0441\u043A\u0432\u0430, http:\/\/t.co\/u4CA5zVu #hipster",
  "id" : 205596227876827136,
  "created_at" : "2012-05-24 09:48:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/dSiJleQU",
      "expanded_url" : "http:\/\/picgate.com\/dm\/80WO\/web.png",
      "display_url" : "picgate.com\/dm\/80WO\/web.png"
    } ]
  },
  "geo" : { },
  "id_str" : "204870309516558336",
  "text" : "http:\/\/t.co\/dSiJleQU \u041D\u0435\u0445\u0432\u0430\u0442\u0430\u0435\u0442 \u0442\u043E\u043B\u044C\u043A\u043E Malkhuth )",
  "id" : 204870309516558336,
  "created_at" : "2012-05-22 09:44:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204866452052914176",
  "text" : "\u041A\u0430\u043D\u0434\u0438\u0434\u0430\u0442\u0441\u043A\u0438\u0439 \u043C\u0438\u043D\u0438\u043C\u0443\u043C - \u0440\u0430\u0441\u0441\u043A\u0430\u0437\u0430\u0442\u044C \u0431\u043E\u0440\u043E\u0434\u0430\u0442\u043E\u043C\u0443 \u0431\u0430\u043B\u0431\u0435\u0441\u0443 \u0433\u0434\u0435 \u0437\u0434\u0435\u0441\u044C mind harassment \u0438 \u043F\u043E\u043F\u0440\u043E\u0441\u0438\u0442\u044C \u043E\u0442\u043B\u0435\u0437\u0442\u044C \u0441\u043E \u0441\u0432\u043E\u0438\u043C \u0430\u043D\u0430\u043C\u043D\u0435\u0437\u043E\u043C (of instagrammotology)",
  "id" : 204866452052914176,
  "created_at" : "2012-05-22 09:29:03 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/WNdUEVqs",
      "expanded_url" : "http:\/\/youtu.be\/QXB0NNaY1J4",
      "display_url" : "youtu.be\/QXB0NNaY1J4"
    }, {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/MxbHufeB",
      "expanded_url" : "http:\/\/youtu.be\/BtXNLuyqMaQ",
      "display_url" : "youtu.be\/BtXNLuyqMaQ"
    } ]
  },
  "geo" : { },
  "id_str" : "204681668076896258",
  "text" : "http:\/\/t.co\/WNdUEVqs \u227D http:\/\/t.co\/MxbHufeB",
  "id" : 204681668076896258,
  "created_at" : "2012-05-21 21:14:47 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203147579138129920",
  "text" : "***SPOILER ALERT*** \u041E\u043D\u0438 \u044D\u0442\u043E\u0433\u043E \u043D\u0435 \u0434\u0435\u043B\u0430\u044E\u0442",
  "id" : 203147579138129920,
  "created_at" : "2012-05-17 15:38:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203146063559933953",
  "text" : "8 \u043B\u0435\u0442 \u0437\u0430\u043D\u0438\u043C\u0430\u043B\u0441\u044F \u0442\u0445\u0435\u043A\u0432\u043E\u043D\u0434\u043E \u0442\u043E\u043B\u044C\u043A\u043E \u0438\u0437-\u0437\u0430 \u0442\u043E\u0433\u043E, \u0447\u0442\u043E \u0434\u0440\u0443\u0433 \u0432 \u0434\u0435\u0442\u0441\u043A\u043E\u043C \u0441\u0430\u0434\u0443 \u0441\u043A\u0430\u0437\u0430\u043B, \u0447\u0442\u043E \u0442\u0430\u043C \u043B\u043E\u043F\u0430\u044E\u0442 \u0442\u0440\u0435\u0445\u043B\u0438\u0442\u0440\u043E\u0432\u044B\u0435 \u0431\u0430\u043D\u043A\u0438 \u043F\u0430\u043B\u044C\u0446\u0430\u043C\u0438",
  "id" : 203146063559933953,
  "created_at" : "2012-05-17 15:32:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flashgamm",
      "indices" : [ 53, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203072610270068736",
  "text" : "\u041F\u043E\u043E\u0431\u0449\u0430\u043B\u0441\u044F \u0441 \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044F\u043C\u0438 \u0437\u0430 \u043F\u0430\u0440\u0443 \u043D\u0435\u0434\u0435\u043B\u044C \u0434\u043E \u0440\u0435\u043B\u0438\u0437\u0430 \u0438\u0433\u0440\u044B #flashgamm",
  "id" : 203072610270068736,
  "created_at" : "2012-05-17 10:40:57 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/sUg3aD8I",
      "expanded_url" : "http:\/\/4sq.com\/LVjIVu",
      "display_url" : "4sq.com\/LVjIVu"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.822537, 37.646271 ]
  },
  "id_str" : "203035950878687232",
  "text" : "\u042F \u0432 Flashgamm 2012 Moscow w\/ 4 others http:\/\/t.co\/sUg3aD8I",
  "id" : 203035950878687232,
  "created_at" : "2012-05-17 08:15:17 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202495403634081793",
  "text" : "\u041D\u0430\u0441\u043A\u043E\u043B\u044C\u043A\u043E \u044F \u0437\u043D\u0430\u044E ajax, \u0432 \u0444\u0443\u0442\u0435\u0440\u0435 Pinterest \u0434\u043E\u043B\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043D\u0430\u043F\u0438\u0441\u0430\u043D\u043E \"mysql_fetch_array(): supplied argument is not a valid MySQL result resource\"",
  "id" : 202495403634081793,
  "created_at" : "2012-05-15 20:27:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202492251375542273",
  "text" : "\u0437\u0430\u0448\u0435\u043B \u0437\u0430 \u043A\u043D\u0438\u0436\u043A\u043E\u0439 \u043F\u043E lady sciences, \u0432\u044B\u043F\u0435\u0439 50 \u0438 \u0437\u0430\u043A\u0443\u0441\u0438 \u0447\u0435\u0431\u0443\u0440\u0435\u043A\u043E\u043C. \u044F \u0442\u0430\u043A \u043F\u043E\u043D\u0438\u043C\u0430\u044E - \u044D\u0442\u043E \u043A\u043E\u043C\u0431\u0438\u043D\u0430\u0446\u0438\u044F.",
  "id" : 202492251375542273,
  "created_at" : "2012-05-15 20:14:49 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202492141979701249",
  "text" : "\u0442\u0435\u043F\u0435\u0440\u044C \u0443\u0436\u0435 \u043D\u0435 \u0442\u0430\u043A \u043F\u0440\u043E\u0441\u0442\u043E \u0441\u043A\u0430\u0437\u0430\u0442\u044C \u0432 \u0447\u0435\u0439-\u0442\u043E \u0430\u0434\u0440\u0435\u0441 \"\u0441\u0435\u043C\u0435\u043D \u0441\u0435\u043C\u0435\u043D\u043E\u0432\u0438\u0447\", - \u044D\u0442\u043E \u0447\u0435\u0431\u0443\u0440\u0435\u0447\u043D\u0430\u044F \u043F\u043E\u0434 \u0444\u0430\u043B\u0430\u043D\u0441\u0442\u0435\u0440\u043E\u043C, \u0432\u0440\u043E\u0434\u0435.",
  "id" : 202492141979701249,
  "created_at" : "2012-05-15 20:14:23 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202490950373736448",
  "text" : "\u0427\u0442\u043E? \u0423\u044D\u043B\u043B\u0441? \u0430 \u043A\u0442\u043E \u0442\u043E\u0433\u0434\u0430 \u0441\u043E\u0447\u0438\u043D\u0438\u043B \"\u0425\u0440\u043E\u043D\u0438\u043A\u0438 \u0414\u044E\u043D\u044B\"? - \u044D\u0442\u043E \u043D\u0435 \u0438\u043C\u0435\u0435\u0442 \u043E\u0442\u043D\u043E\u0448\u0435\u043D\u0438\u044F \u043A \u044E\u043C\u043E\u0440\u0443 - \u043F\u0440\u043E\u0441\u0442\u043E, \u0435\u0436\u0435\u0434\u043D\u0435\u0432\u043D\u044B\u0439 \u0442\u0435\u0441\u0442 \u043D\u0430 qualia.",
  "id" : 202490950373736448,
  "created_at" : "2012-05-15 20:09:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anton Gorbunov",
      "screen_name" : "iogr",
      "indices" : [ 0, 5 ],
      "id_str" : "64575784",
      "id" : 64575784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202485486487478273",
  "in_reply_to_user_id" : 64575784,
  "text" : "@iogr: \u041A\u0440\u043E\u043C\u0435 \u0442\u043E\u0433\u043E, \u0432\u044B \u0432\u043E\u043E\u0431\u0449\u0435 \u043A\u043E\u0433\u0434\u0430-\u043D\u0438\u0431\u0443\u0434\u044C \u043F\u0440\u043E\u0431\u043E\u0432\u0430\u043B\u0438 \u0412\u044B\u0432\u0435\u0441\u0442\u0438 \u041D\u0430 \u042D\u043A\u0440\u0430\u043D \u041F\u0438\u043A\u0441\u0435\u043B? \u0413\u043E\u0432\u043E\u0440\u044F\u0442, \u0434\u0430\u0436\u0435 \u0443 \u041C\u0430\u043B\u0435\u0432\u0438\u0447\u0430 \u043D\u0435 \u043F\u043E\u043B\u0443\u0447\u0438\u043B\u043E\u0441\u044C.",
  "id" : 202485486487478273,
  "created_at" : "2012-05-15 19:47:56 +0000",
  "in_reply_to_screen_name" : "iogr",
  "in_reply_to_user_id_str" : "64575784",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202483383891275776",
  "text" : "\u0412\u044B \u0436\u0435 \u043D\u0435 \u0437\u0430 \u043E\u0434\u043D\u0438\u043C \u043A\u043E\u043C\u043F\u044C\u044E\u0442\u0435\u0440\u043E\u043C.",
  "id" : 202483383891275776,
  "created_at" : "2012-05-15 19:39:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202483203393601537",
  "text" : "\u0415\u0441\u043B\u0438 \u043B\u044E\u0431\u043E\u0439 \u043C\u043E\u0436\u0435\u0442 \u0434\u043E\u0441\u0442\u0430\u0432\u0438\u0442\u044C ping \u0434\u043E \u0421\u0428\u0410 \u0431\u044B\u0441\u0442\u0440\u0435\u0439, \u0447\u0435\u043C \u0432\u044B\u0432\u0435\u0441\u0442\u0438 \u043D\u0430 \u044D\u043A\u0440\u0430\u043D \u043F\u0438\u043A\u0441\u0435\u043B, \u044D\u0442\u043E \u043D\u0435 \u0437\u043D\u0430\u0447\u0438\u0442, \u0447\u0442\u043E \u0413\u0435\u0440\u0431\u0435\u0440\u0442\u0443 \u0421\u043F\u0435\u043D\u0441\u0435\u0440\u0443 \u043F\u0440\u043E\u0449\u0435 \u0434\u043E\u0437\u0432\u043E\u043D\u0438\u0442\u044C\u0441\u044F \u0432 \u0441\u043A\u0430\u0439\u043F.",
  "id" : 202483203393601537,
  "created_at" : "2012-05-15 19:38:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrey Vinokurov",
      "screen_name" : "Yuusou1989",
      "indices" : [ 0, 11 ],
      "id_str" : "255977897",
      "id" : 255977897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "202371006336212992",
  "geo" : { },
  "id_str" : "202372128895533057",
  "in_reply_to_user_id" : 255977897,
  "text" : "@Yuusou1989 \u044D\u0442\u043E \u043A \u041C\u0430\u043B\u044E\u0442\u0438\u043D\u0443 )",
  "id" : 202372128895533057,
  "in_reply_to_status_id" : 202371006336212992,
  "created_at" : "2012-05-15 12:17:30 +0000",
  "in_reply_to_screen_name" : "Yuusou1989",
  "in_reply_to_user_id_str" : "255977897",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ecoloft",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/iWnhh3Ef",
      "expanded_url" : "http:\/\/4sq.com\/JnABLw",
      "display_url" : "4sq.com\/JnABLw"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.8047813426, 37.58463966 ]
  },
  "id_str" : "201648108906622976",
  "text" : "\u0412 \u041F\u043E\u0438\u0441\u043A\u0430\u0445 \u041D\u043E\u0432\u043E\u0433\u043E \u042F\u0437\u044B\u043A\u0430? Nick fluck gworndy quan-do flern #ecoloft (@ \u0414\u0438\u0437\u0430\u0439\u043D-\u0437\u0430\u0432\u043E\u0434 \"\u0424\u043B\u0430\u043A\u043E\u043D\" (Flacon) w\/ 12 others) http:\/\/t.co\/iWnhh3Ef",
  "id" : 201648108906622976,
  "created_at" : "2012-05-13 12:20:30 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201396318290198529",
  "text" : "\u0442\u043B\u0435\u0442\u0432\u043E\u0440\u043D\u044B\u0439 \u042D\u043B\u044C\u0444\u043C\u0430\u043D \u0441\u043E\u0433\u0440\u0435\u0432\u0430\u043B \u0432\u0435\u0440\u0442\u0435\u043F, \n\u043F\u043E\u043A\u0443\u0434\u0430 \u0414\u0435\u043F\u043F \u0447\u0435\u043A\u0438\u043D\u0438\u043B\u0441\u044F \u0441\u0443\u0434\u044C\u0431\u043E\u0439 \n\u0432 \u043C\u043E\u0433\u0438\u043B\u044C\u043D\u044B\u0439 \u0441\u043A\u043B\u0435\u043F.",
  "id" : 201396318290198529,
  "created_at" : "2012-05-12 19:39:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201396297725526018",
  "text" : "\u041A\u0430\u043A \u043E\u0431\u043C\u0438\u0440\u0430\u044E\u0449\u0438\u0439 \u043D\u0430 \u0433\u0440\u0435\u0431\u043D\u044F\u0445 \u0432\u043E\u043B\u043D \u043F\u043B\u043E\u0432\u0435\u0446\n\u044F \u0411\u0435\u0440\u0442\u043E\u043D\u0443 \u0432\u0435\u043B\u0435\u043D\u0438\u0435\u043C \u0443\u043D\u044B\u043D\u0438\u044F \u0432\u043D\u0438\u043C\u0430\u043B.",
  "id" : 201396297725526018,
  "created_at" : "2012-05-12 19:39:53 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 40, 51 ],
      "id_str" : "804341497441255424",
      "id" : 804341497441255424
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FilmBuff",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/eoHuBpyP",
      "expanded_url" : "http:\/\/4sq.com\/J7ki5C",
      "display_url" : "4sq.com\/J7ki5C"
    } ]
  },
  "geo" : { },
  "id_str" : "201349329800269824",
  "text" : "I just unlocked the \"Zoetrope\" badge on @foursquare for checking in to movie theaters! #FilmBuff http:\/\/t.co\/eoHuBpyP",
  "id" : 201349329800269824,
  "created_at" : "2012-05-12 16:33:15 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "linternaute",
      "screen_name" : "linternaute",
      "indices" : [ 120, 132 ],
      "id_str" : "18600960",
      "id" : 18600960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/almpcK5d",
      "expanded_url" : "http:\/\/www.linternaute.com\/cinema\/star-cinema\/frederic-beigbeder-et-gaspard-proust-frederic-beigbeder-et-gaspard-proust-en-interview-video\/en-savoir-plus.shtml",
      "display_url" : "linternaute.com\/cinema\/star-ci\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "201313297948098560",
  "text" : "En savoir plus - Fr\u00E9d\u00E9ric Beigbeder et Gaspard Proust en interview vid\u00E9o - L'Internaute Cin\u00E9ma http:\/\/t.co\/almpcK5d via @linternaute",
  "id" : 201313297948098560,
  "created_at" : "2012-05-12 14:10:05 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/1itbSkJ6",
      "expanded_url" : "http:\/\/instagr.am\/p\/KfgbLkK9Pd\/",
      "display_url" : "instagr.am\/p\/KfgbLkK9Pd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "200979068085207040",
  "text" : "Stuck on the Wenders photo puzzle http:\/\/t.co\/1itbSkJ6",
  "id" : 200979068085207040,
  "created_at" : "2012-05-11 16:01:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA All Game Live Stream",
      "screen_name" : "UStream",
      "indices" : [ 3, 11 ],
      "id_str" : "1107013535769509896",
      "id" : 1107013535769509896
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ustream",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200232140917579776",
  "text" : "RT @Ustream: News Alert: #Ustream is inaccessible due to a large scale DDOS attack targeting Russian opposition channels on Ustream.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ustream",
        "indices" : [ 12, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200208031617781760",
    "text" : "News Alert: #Ustream is inaccessible due to a large scale DDOS attack targeting Russian opposition channels on Ustream.",
    "id" : 200208031617781760,
    "created_at" : "2012-05-09 12:58:09 +0000",
    "user" : {
      "name" : "IBM Watson Media",
      "screen_name" : "IBMWatsonMedia",
      "protected" : false,
      "id_str" : "5490392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1092826975473987588\/od7qJuE6_normal.jpg",
      "id" : 5490392,
      "verified" : true
    }
  },
  "id" : 200232140917579776,
  "created_at" : "2012-05-09 14:33:57 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200209563109171200",
  "text" : "\u041F\u0435\u0440\u0435\u0432\u0435\u0434\u0435\u043D\u043D\u044B\u0439 \u043C\u043D\u043E\u0439 \u0442\u0435\u043A\u0441\u0442 Andrew Mason \u043D\u0430\u0441\u0442\u043E\u043B\u044C\u043A\u043E \u0441\u043E\u0441\u0442\u043E\u0438\u0442 \u0438\u0437 \u0441\u043B\u043E\u0432-\u043F\u0430\u0440\u0430\u0437\u0438\u0442\u043E\u0432, \u0447\u0442\u043E \u044F \u043F\u0435\u0440\u0435\u0441\u0442\u0430\u043B \u043F\u043E\u043D\u0438\u043C\u0430\u0442\u044C \u043A\u0442\u043E \u0443 \u043A\u043E\u0433\u043E \u0432 \u0433\u043E\u0441\u0442\u044F\u0445.",
  "id" : 200209563109171200,
  "created_at" : "2012-05-09 13:04:14 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "againstthestate",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200169579044020225",
  "text" : "My hiding place is open space, Not bolthole small or large. Bench, wall and tree, but now you\u2019ll see, Some urban camouflage #againstthestate",
  "id" : 200169579044020225,
  "created_at" : "2012-05-09 10:25:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198720526968033280",
  "text" : "We are just finishing off the antipasto of the crisis comrogues. forza multitude, the dolce is yet to come. And all this are not cursewords!",
  "id" : 198720526968033280,
  "created_at" : "2012-05-05 10:27:20 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/O5pn5Vm5",
      "expanded_url" : "http:\/\/levelss.com\/04_-_melee_island_-_circus.mp3",
      "display_url" : "levelss.com\/04_-_melee_isl\u2026"
    }, {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/1DlqPx6e",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=fHC4VeAlJpU",
      "display_url" : "youtube.com\/watch?v=fHC4Ve\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198545965815308288",
  "text" : "http:\/\/t.co\/O5pn5Vm5 \u0435\u0441\u043B\u0438 \u0432\u044B \u043A\u043E\u0433\u0434\u0430-\u043B\u0438\u0431\u043E \u0440\u0430\u043D\u0435\u0435 \u0441\u043B\u044B\u0448\u0430\u043B\u0438 \u044D\u0442\u0443 \u043A\u043E\u043C\u043F\u043E\u0437\u0438\u0446\u0438\u044E, \u0442\u043E \u0432\u044B \u043D\u0435\u0440\u0434. Answer: http:\/\/t.co\/1DlqPx6e",
  "id" : 198545965815308288,
  "created_at" : "2012-05-04 22:53:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/bCWdV31s",
      "expanded_url" : "http:\/\/i47.tinypic.com\/23vne60.jpg",
      "display_url" : "i47.tinypic.com\/23vne60.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "198471297695621120",
  "text" : "http:\/\/t.co\/bCWdV31s \u041D\u0430\u043F\u0440\u0430\u0441\u043D\u043E \u0441\u0442\u0430\u0440\u0430\u044E\u0442\u0441\u044F, \u0432 \u0440\u0430\u0448\u043A\u0435 \u043F\u043E\u0440\u0442\u0430\u043B \u0432 \u0430\u0434 \u043D\u0438\u043A\u043E\u0433\u0434\u0430 \u0438 \u043D\u0435 \u0437\u0430\u043A\u0440\u044B\u0432\u0430\u043B\u0441\u044F.",
  "id" : 198471297695621120,
  "created_at" : "2012-05-04 17:56:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198462844788936705",
  "text" : "\u0417\u0430\u043F\u0438\u0441\u044C \u0432 to-do: \u043A\u043E\u043D\u0446\u0435\u043F\u0442 Apostille (Convention de la Haye du 5 octobre 1961)",
  "id" : 198462844788936705,
  "created_at" : "2012-05-04 17:23:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexey Chadayev",
      "screen_name" : "chadayev",
      "indices" : [ 3, 12 ],
      "id_str" : "46926019",
      "id" : 46926019
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197782096910106624",
  "text" : "RT @chadayev: \u0410 \u0410\u043C\u0430\u0437\u043E\u043D \u0442\u0435\u043C \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0440\u0435\u043A\u043B\u0430\u043C\u0438\u0440\u0443\u0435\u0442 \u043D\u043E\u0432\u044B\u0439 \u0440\u043E\u043C\u0430\u043D \u0427\u0430\u0439\u043D\u044B \u041C\u044C\u0435\u043B\u044C\u0432\u0438\u043B\u044F Railsea. \u0418\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u044B\u0435 \u043A\u043D\u0438\u0433\u0438 \u043F\u043E\u044F\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u043D\u0430 \u0433\u043E\u0440\u0438\u0437\u043E\u043D\u0442\u0435 \u0431\u044B\u0441\u0442\u0440\u0435\u0435, \u0447 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197779658169794560",
    "text" : "\u0410 \u0410\u043C\u0430\u0437\u043E\u043D \u0442\u0435\u043C \u0432\u0440\u0435\u043C\u0435\u043D\u0435\u043C \u0440\u0435\u043A\u043B\u0430\u043C\u0438\u0440\u0443\u0435\u0442 \u043D\u043E\u0432\u044B\u0439 \u0440\u043E\u043C\u0430\u043D \u0427\u0430\u0439\u043D\u044B \u041C\u044C\u0435\u043B\u044C\u0432\u0438\u043B\u044F Railsea. \u0418\u043D\u0442\u0435\u0440\u0435\u0441\u043D\u044B\u0435 \u043A\u043D\u0438\u0433\u0438 \u043F\u043E\u044F\u0432\u043B\u044F\u044E\u0442\u0441\u044F \u043D\u0430 \u0433\u043E\u0440\u0438\u0437\u043E\u043D\u0442\u0435 \u0431\u044B\u0441\u0442\u0440\u0435\u0435, \u0447\u0435\u043C \u0443\u0441\u043F\u0435\u0432\u0430\u044E \u0447\u0438\u0442\u0430\u0442\u044C",
    "id" : 197779658169794560,
    "created_at" : "2012-05-02 20:08:39 +0000",
    "user" : {
      "name" : "Alexey Chadayev",
      "screen_name" : "chadayev",
      "protected" : false,
      "id_str" : "46926019",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/319507132\/chadayev_normal.jpg",
      "id" : 46926019,
      "verified" : false
    }
  },
  "id" : 197782096910106624,
  "created_at" : "2012-05-02 20:18:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/YpnovY16",
      "expanded_url" : "http:\/\/img.ly\/hHPx",
      "display_url" : "img.ly\/hHPx"
    } ]
  },
  "geo" : { },
  "id_str" : "197335672334450690",
  "text" : "\u0421\u043C\u043E\u0442\u0440\u044F\u0442, \u0433\u043E\u0432\u043E\u0440\u044F\u0442 \u043C\u043E\u043B\u043E\u0434\u0430\u044F \u0434\u0435\u0432\u0443\u0448\u043A\u0430, \u043B\u0435\u0442 20 http:\/\/t.co\/YpnovY16 \u043D\u0430\u0447\u0430\u043B\u0430\u0441\u044C \u0441\u0443\u0435\u0442\u0430, \u043D\u0435\u0441\u0443\u0442 \u043D\u043E\u0441\u0438\u043B\u043A\u0438",
  "id" : 197335672334450690,
  "created_at" : "2012-05-01 14:44:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197334090947624960",
  "text" : "\u0421\u043E\u0442\u0440\u0443\u0434\u043D\u0438\u043A\u043E\u0432 \u043F\u043E\u043B\u0438\u0446\u0438\u0438 \u0447\u0435\u043B\u043E\u0432\u0435\u043A 12",
  "id" : 197334090947624960,
  "created_at" : "2012-05-01 14:38:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/1G88akZB",
      "expanded_url" : "http:\/\/img.ly\/hHOm",
      "display_url" : "img.ly\/hHOm"
    } ]
  },
  "geo" : { },
  "id_str" : "197333744317763585",
  "text" : "\u0421\u0438\u0436\u0443 \u0432 \u0432\u0430\u0433\u043E\u043D\u0435 \u043F\u043E\u0435\u0437\u0434\u0430, \u043F\u043E\u0434 \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u0431\u0440\u043E\u0441\u0438\u043B\u0441\u044F \u0447\u0435\u043B\u043E\u0432\u0435\u043A (\u0412\u043E\u0440\u043E\u0431\u044C\u0435\u0432\u044B \u0433\u043E\u0440\u044B) http:\/\/t.co\/1G88akZB",
  "id" : 197333744317763585,
  "created_at" : "2012-05-01 14:36:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]