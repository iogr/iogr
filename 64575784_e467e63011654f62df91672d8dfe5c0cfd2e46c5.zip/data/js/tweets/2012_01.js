Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156953317610762240",
  "text" : "\u041A\u043E\u0433\u0434\u0430 \u0440\u0430\u0437\u043E\u0440\u0443\u0436\u0430\u0435\u0448\u044C\u0441\u044F \u043E\u0442 \u0432\u0441\u0435\u0445 \u0444\u043E\u0440\u043C \u043F\u0440\u0438\u043D\u044F\u0442\u0438\u044F \u0430\u0434\u0430, \u0436\u0438\u0442\u044C \u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u043D\u0435\u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E.",
  "id" : 156953317610762240,
  "created_at" : "2012-01-11 04:19:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156735271587684352",
  "text" : "\u0418\u0437\u043E\u0431\u0440\u0435\u0442\u0435\u043D\u0438\u0435 \u0434\u043D\u044F: \u043F\u0430\u0440\u0435\u043D\u044C \u0443\u0448\u0435\u043B \u0441 \u043F\u0440\u043E\u0448\u043B\u043E\u0439 \u0440\u0430\u0431\u043E\u0442\u044B, \u0442.\u043A. \u0435\u0433\u043E \u0434\u043E\u0441\u0442\u0430\u043B \u0413\u043E\u0440\u043C\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0439 \u041C\u0435\u043D\u0435\u0434\u0436\u043C\u0435\u043D\u0442.",
  "id" : 156735271587684352,
  "created_at" : "2012-01-10 13:52:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u0438\u043A\u0438\u0442\u0430 \u0422\u043E\u043C\u0438\u043B\u043B\u0438\u043D",
      "screen_name" : "TomilinNikita",
      "indices" : [ 0, 14 ],
      "id_str" : "74164361",
      "id" : 74164361
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156631632844034048",
  "in_reply_to_user_id" : 51485640,
  "text" : "@TomilinNikita \u042F\u043F\u043E\u043D\u0446\u044B \u043E\u0431\u0435\u0449\u0430\u044E\u0442 \u043A\u043B\u043E\u043D\u0438\u0440\u043E\u0432\u0430\u0442\u044C \u0441\u0438\u0431\u0438\u0440\u0441\u043A\u043E\u0433\u043E \u043C\u0430\u043C\u043E\u043D\u0442\u0430 \u0443\u0436\u0435 \u0432 \u044D\u0442\u043E\u043C \u0433\u043E\u0434\u0443, \u043D\u043E \u044F \u0434\u0443\u043C\u0430\u044E, \u0447\u0442\u043E \u043E\u0442\u0435\u0446 \u043D\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u0438\u0442\u0441\u044F.",
  "id" : 156631632844034048,
  "created_at" : "2012-01-10 07:01:06 +0000",
  "in_reply_to_screen_name" : "TMLN_doc",
  "in_reply_to_user_id_str" : "51485640",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrey Vinokurov",
      "screen_name" : "Yuusou1989",
      "indices" : [ 0, 11 ],
      "id_str" : "255977897",
      "id" : 255977897
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156467959328538624",
  "geo" : { },
  "id_str" : "156473140409675776",
  "in_reply_to_user_id" : 255977897,
  "text" : "@Yuusou1989 \u043F\u0440\u043E\u0441\u0442\u043E \u0432\u0441\u0435 \u043D\u0435\u043D\u0430\u0438\u0432\u043D\u044B\u0435 \u0434\u0435\u0432\u0443\u0448\u043A\u0438 \u0441\u0442\u0430\u0440\u0430\u044E\u0442\u0441\u044F \u043E\u0431\u0435\u0437\u043E\u043F\u0430\u0441\u0438\u0442\u044C \u0441\u0435\u0431\u044F \u0432 \u043F\u0441\u0438\u0445\u043E\u043B\u043E\u0433\u0438\u0447\u0435\u0441\u043A\u043E\u043C \u0438 \u043C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044C\u043D\u043E\u043C \u0441\u043C\u044B\u0441\u043B\u0435. \u044F \u043F\u0440\u043E\u0442\u0438\u0432 \u0447\u0438\u0441\u0442\u043E\u0433\u043E \u043C\u0435\u0440\u043A\u0430\u043D\u0442\u0438\u043B\u0438\u0437\u043C\u0430",
  "id" : 156473140409675776,
  "in_reply_to_status_id" : 156467959328538624,
  "created_at" : "2012-01-09 20:31:18 +0000",
  "in_reply_to_screen_name" : "Yuusou1989",
  "in_reply_to_user_id_str" : "255977897",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156467225308577792",
  "text" : "\u041F\u0440\u0430\u0432\u0438\u043B\u043E: \u043D\u0435 \u0440\u0430\u0437\u0432\u0438\u0432\u0430\u044E \u0438\u043D\u0442\u0438\u043C\u043D\u044B\u0435 \u043E\u0442\u043D\u043E\u0448\u0435\u043D\u0438\u044F, \u0435\u0441\u043B\u0438 \u043E\u043D\u0438 \u043E\u043F\u0443\u0442\u044B\u0432\u0430\u044E\u0442\u0441\u044F \u043E\u043C\u0435\u0440\u0437\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0439 \u0431\u0440\u043E\u043D\u0435\u0439 \u0441\u0442\u0440\u0430\u0442\u0435\u0433\u0438\u0439.",
  "id" : 156467225308577792,
  "created_at" : "2012-01-09 20:07:48 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156466874538934272",
  "text" : "Verdict: \u044F \u043D\u0435 \u0431\u0443\u0434\u0443 \u0440\u0430\u0437\u0432\u0438\u0432\u0430\u0442\u044C \u044D\u0442\u0443 \u0432\u0435\u0442\u0432\u044C.",
  "id" : 156466874538934272,
  "created_at" : "2012-01-09 20:06:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/P7p7wLKF",
      "expanded_url" : "http:\/\/4sq.com\/zv7FLD",
      "display_url" : "4sq.com\/zv7FLD"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7348, 37.627316 ]
  },
  "id_str" : "156378996911771650",
  "text" : "\u0413\u043E\u043B\u043E\u0434\u0435\u043D, \u043D\u043E \u0431\u0443\u0434\u0443 \u0435\u0441\u0442\u044C \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u043E \u0436\u0435, \u0447\u0442\u043E \u0438 \u043E\u043F\u0430\u0437\u0434\u044B\u0432\u0430\u044E\u0449\u0430\u044F the woman (@ \u0422\u0430\u043D\u0443\u043A\u0438 w\/ 4 others) http:\/\/t.co\/P7p7wLKF",
  "id" : 156378996911771650,
  "created_at" : "2012-01-09 14:17:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ftimn",
      "screen_name" : "ftimn",
      "indices" : [ 0, 6 ],
      "id_str" : "80279354",
      "id" : 80279354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156036830528159745",
  "in_reply_to_user_id" : 80279354,
  "text" : "@ftimn \u0432 \u0442\u043E\u0442 \u0440\u0430\u0437 \u0442\u044B \u0442\u0430\u043A \u0445\u043E\u0442\u0435\u043B\u0430 \u0443\u0439\u0442\u0438, \u0447\u0442\u043E \u043C\u044B \u043D\u0435 \u0434\u043E\u0436\u0434\u0430\u043B\u0438\u0441\u044C \u0442\u043E\u0433\u043E, \u0440\u0430\u0434\u0438 \u0447\u0435\u0433\u043E \u043F\u0440\u0438\u0448\u043B\u0438. \u042F \u0440\u0430\u0441\u0441\u0442\u0440\u043E\u0438\u043B\u0441\u044F, \u043D\u043E \u0442\u0435\u0431\u0435 \u043D\u0435 \u0441\u043A\u0430\u0437\u0430\u043B. )",
  "id" : 156036830528159745,
  "created_at" : "2012-01-08 15:37:34 +0000",
  "in_reply_to_screen_name" : "ftimn",
  "in_reply_to_user_id_str" : "80279354",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156035834158657536",
  "text" : "\u041C\u0435\u0447\u0442\u044B \u0441\u0431\u044B\u0432\u0430\u044E\u0442\u0441\u044F, milf.",
  "id" : 156035834158657536,
  "created_at" : "2012-01-08 15:33:36 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156034698076889088",
  "text" : "\u0412\u0437\u0440\u043E\u0441\u043B\u044B\u0439 \u0447\u0435\u043B\u043E\u0432\u0435\u043A - \u0434\u0443\u043C\u0430\u044E\u0449\u0438\u0439, \u0447\u0442\u043E \u0435\u043C\u0443 \u043D\u0435\u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E \u043D\u0435\u043F\u0440\u0435\u0440\u044B\u0432\u043D\u043E \u043F\u043E\u043B\u0443\u0447\u0430\u0442\u044C \u0443\u0434\u043E\u0432\u043E\u043B\u044C\u0441\u0442\u0432\u0438\u0435 \u0438, \u0438\u043B\u0438 \u0431\u044B\u0442\u044C \u0441\u0447\u0430\u0441\u0442\u043B\u0438\u0432\u044B\u043C.",
  "id" : 156034698076889088,
  "created_at" : "2012-01-08 15:29:05 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155803617486581760",
  "text" : "+ \u0444\u0435\u043D\u0438\u043B\u0430\u043B\u0430\u043D\u0438\u043D (30 000 \u0433\u0440\u0430\u043C\u043C).      .",
  "id" : 155803617486581760,
  "created_at" : "2012-01-08 00:10:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155772325999017985",
  "text" : "\u041D\u043E \u043D\u0443\u0436\u043D\u0430 \u043F\u043E\u0442\u0430\u0441\u043E\u0432\u043A\u0430, \u044F \u0432 \u043E\u0442\u043B\u0438\u0447\u043D\u043E\u0439 \u0444\u043E\u0440\u043C\u0435 )",
  "id" : 155772325999017985,
  "created_at" : "2012-01-07 22:06:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/BrVNHKxU",
      "expanded_url" : "http:\/\/4sq.com\/znx0RT",
      "display_url" : "4sq.com\/znx0RT"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7397172529, 37.6100099087 ]
  },
  "id_str" : "155750980225474561",
  "text" : "\u0418\u0433\u0440\u0430\u0435\u043C \u043F\u043E \u043F\u0440\u0430\u0432\u0438\u043B\u0430\u043C \u0442\u0438\u0440\u0430\u043D\u0438\u0438 \u0441\u0447\u0430\u0441\u0442\u044C\u044F, \u0443\u043B\u044B\u0431\u043A\u0438 \u0438 \u043D\u043E\u0447\u043D\u044B\u0445 \u043A\u043B\u0443\u0431\u043E\u0432. (@ GIPSY w\/ 58 others) http:\/\/t.co\/BrVNHKxU",
  "id" : 155750980225474561,
  "created_at" : "2012-01-07 20:41:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Foursquare",
      "screen_name" : "Foursquare",
      "indices" : [ 37, 48 ],
      "id_str" : "804341497441255424",
      "id" : 804341497441255424
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/ilNyhbuq",
      "expanded_url" : "http:\/\/4sq.com\/ye8YgI",
      "display_url" : "4sq.com\/ye8YgI"
    } ]
  },
  "geo" : { },
  "id_str" : "155750979835404289",
  "text" : "I just unlocked the \"Swarm\" badge on @foursquare! http:\/\/t.co\/ilNyhbuq",
  "id" : 155750979835404289,
  "created_at" : "2012-01-07 20:41:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155736901280743425",
  "text" : "\u041D\u0430 \u0432\u043E\u0441\u044C\u043C\u0438\u0431\u0438\u0442\u043D\u043E\u0439 \u0434\u0438\u0441\u043A\u043E\u0442\u0435\u043A\u0435 \u0432\u044B \u0431\u0443\u0434\u0435\u0442\u0435 \u0443\u043D\u0438\u0447\u0442\u043E\u0436\u0435\u043D\u044B!",
  "id" : 155736901280743425,
  "created_at" : "2012-01-07 19:45:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/BXR6Nc6v",
      "expanded_url" : "http:\/\/4sq.com\/wI5nvQ",
      "display_url" : "4sq.com\/wI5nvQ"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.782052, 37.599201 ]
  },
  "id_str" : "155728837173444608",
  "text" : "\u0410\u0431\u0441\u043E\u043B\u044E\u0442\u043D\u043E \u0422\u0440\u0435\u0437\u0432\u044B\u0435 \u0422\u0430\u043D\u0446\u044B (@ \u041A\u0443\u043A\u043B\u044B \u041F\u0438\u0441\u0442\u043E\u043B\u0435\u0442\u044B \/ Dolls Pistols w\/ 4 others) http:\/\/t.co\/BXR6Nc6v",
  "id" : 155728837173444608,
  "created_at" : "2012-01-07 19:13:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.azumio.com\" rel=\"nofollow\"\u003EAzumio\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "instantheartrate",
      "indices" : [ 71, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/WzqazD4z",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eI_VJTblVJk",
      "display_url" : "youtube.com\/watch?v=eI_VJT\u2026"
    }, {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/bp3EeeXB",
      "expanded_url" : "http:\/\/goo.gl\/4x4uz",
      "display_url" : "goo.gl\/4x4uz"
    } ]
  },
  "geo" : { },
  "id_str" : "155093366453960706",
  "text" : "\u041F\u0443\u043B\u044C\u0441 \u0434\u043E\u043B\u0436\u0435\u043D \u0431\u044B\u0442\u044C \u0442\u0430\u043A\u0438\u043C: http:\/\/t.co\/WzqazD4z. My heart rate is 56bpm. #instantheartrate http:\/\/t.co\/bp3EeeXB",
  "id" : 155093366453960706,
  "created_at" : "2012-01-06 01:08:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/PjjMQPYN",
      "expanded_url" : "http:\/\/www.pcauthority.com.au\/?168019",
      "display_url" : "pcauthority.com.au\/?168019"
    } ]
  },
  "geo" : { },
  "id_str" : "155002292842676226",
  "text" : "Looking back at the Commodore 64 http:\/\/t.co\/PjjMQPYN",
  "id" : 155002292842676226,
  "created_at" : "2012-01-05 19:06:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155001557077860353",
  "text" : "\u0416\u0430\u043B\u044C, \u0447\u0442\u043E \u043D\u0435 \u0447\u0443\u043C\u0430 - \u043E\u0431\u044A\u044F\u0441\u043D\u0438\u043B\u043E \u0431\u044B \u043A\u0440\u044B\u0441. \nkong marketmaker rats ofc",
  "id" : 155001557077860353,
  "created_at" : "2012-01-05 19:03:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/b1n6Topv",
      "expanded_url" : "http:\/\/smart-lab.ru\/uploads\/images\/00\/03\/68\/2012\/01\/05\/e63b6d.png",
      "display_url" : "smart-lab.ru\/uploads\/images\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155000997796786176",
  "text" : "http:\/\/t.co\/b1n6Topv\nBwahhaha, curves are burrowing deeper and deeper into smns mind.",
  "id" : 155000997796786176,
  "created_at" : "2012-01-05 19:01:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/iq4kE7ta",
      "expanded_url" : "http:\/\/img.ly\/cjAn",
      "display_url" : "img.ly\/cjAn"
    } ]
  },
  "geo" : { },
  "id_str" : "154773560936775680",
  "text" : "\u0412\u043E\u0442, \u0438\u043C\u0435\u043D\u043D\u043E \u043F\u043E \u044D\u0442\u043E\u0439 \u043F\u0440\u0438\u0447\u0438\u043D\u0435 \u0441\u043B\u0435\u0434\u043E\u0432\u0430\u043B\u043E \u0431\u044B \u0437\u0430\u043F\u0440\u0435\u0442\u0438\u0442\u044C \u043C\u043D\u0435 \u043E\u0441\u0443\u0449\u0435\u0441\u0442\u0432\u043B\u044F\u0442\u044C \u043E\u043D\u043B\u0430\u0439\u043D-\u0437\u0430\u043A\u0430\u0437\u044B: http:\/\/t.co\/iq4kE7ta",
  "id" : 154773560936775680,
  "created_at" : "2012-01-05 03:57:47 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154744099621187584",
  "text" : "\u0423 \u041D\u0435\u0437\u043D\u0430\u0439\u043A\u0438, \u043A\u0430\u043A \u0438 \u0443 \u0424\u0443\u043D\u0442\u0438\u043A\u0430 \u0431\u044B\u043B\u0438 \u043D\u0435 \u0441\u0430\u043C\u044B\u0435 \u043D\u0438\u0437\u043A\u0438\u0435 social skills, \u0437\u0430\u043C\u0435\u0442\u0438\u043C.",
  "id" : 154744099621187584,
  "created_at" : "2012-01-05 02:00:43 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154741387336753152",
  "text" : "\u0428\u0430\u043F\u043E\u043A\u043B\u044F\u043A - \u043E\u0431\u0440\u0430\u0437 \u0441\u043E\u0431\u0438\u0440\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439, \u043D\u043E, \u043A\u0430\u043A \u043F\u043E \u043C\u043D\u0435, \u043E\u0447\u0435\u043D\u044C \u043D\u0435\u0436\u043D\u044B\u0439, - \u0432\u0435\u0434\u044C \u043E\u043D\u0430 \u043D\u0438\u043A\u043E\u0433\u0434\u0430 \u043D\u0435 \u043E\u0446\u0435\u043D\u0438\u0442 \u0447\u0442\u043E-\u043B\u0438\u0431\u043E, \u0441\u0434\u0435\u043B\u0430\u043D\u043D\u043E\u0435 (\u0435\u0439) \u043D\u0435 \u0432\u043E \u0432\u0440\u0435\u0434.",
  "id" : 154741387336753152,
  "created_at" : "2012-01-05 01:49:56 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154701292659425280",
  "text" : "\u0414\u043E\u0444\u0430\u043C\u0438\u043D, \u0441\u0435\u0440\u043E\u0442\u043E\u043D\u0438\u043D \u0438 \u044D\u043D\u0434\u043E\u0440\u0444\u0438\u043D\u044B \u0443\u0448\u043B\u0438. \u0421\u043E \u043C\u043D\u043E\u0439 \u043D\u0438\u043A\u0442\u043E \u043D\u0435 \u0441\u043E\u0432\u0435\u0442\u043E\u0432\u0430\u043B\u0441\u044F.",
  "id" : 154701292659425280,
  "created_at" : "2012-01-04 23:10:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/wjb3x9PV",
      "expanded_url" : "http:\/\/4sq.com\/A5e9am",
      "display_url" : "4sq.com\/A5e9am"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.8049115789, 37.5851290182 ]
  },
  "id_str" : "154579718610489344",
  "text" : "I'm at \u0414\u0438\u0437\u0430\u0439\u043D-\u0437\u0430\u0432\u043E\u0434 \"\u0424\u043B\u0430\u043A\u043E\u043D\" (Flacon) (\u0411\u043E\u043B. \u041D\u043E\u0432\u043E\u0434\u043C\u0438\u0442\u0440\u043E\u0432\u0441\u043A\u0430\u044F \u0443\u043B., 36\/4, \u041C\u043E\u0441\u043A\u0432\u0430) http:\/\/t.co\/wjb3x9PV",
  "id" : 154579718610489344,
  "created_at" : "2012-01-04 15:07:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153937933806739456",
  "text" : "\u041D\u0430\u0443\u0447\u0438\u043B\u0441\u044F \u0441\u0436\u0438\u043C\u0430\u0442\u044C Captains of Crush \u21161, \u0432\u0442\u043E\u0440\u043E\u0439 \u043D\u043E\u043C\u0435\u0440 \u043F\u043E\u043A\u0430 \u0441\u0436\u0430\u0442\u044C \u043D\u0435 \u043C\u043E\u0433\u0443, \u0442\u044F\u0436\u0435\u043B\u043E. + \u0432\u0440\u0435\u0434\u043D\u043E \u043C\u043D\u043E\u0433\u043E \u0441\u0436\u0438\u043C\u0430\u0442\u044C \u0431\u0435\u0437 \u043F\u0435\u0440\u0447\u0430\u0442\u043E\u043A.",
  "id" : 153937933806739456,
  "created_at" : "2012-01-02 20:37:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/the-sheeps-free\/id486185138?mt=8&uo=4\" rel=\"nofollow\"\u003Ethe Sheeps Free on iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iogr\/status\/153934264218566656\/photo\/1",
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/e88EhR1T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AiLiZdHCQAA8sCl.jpg",
      "id_str" : "153934264222760960",
      "id" : 153934264222760960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiLiZdHCQAA8sCl.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/e88EhR1T"
    } ],
    "hashtags" : [ {
      "text" : "\u041E\u0432\u0446\u044B",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/GelHIaU4",
      "expanded_url" : "http:\/\/bit.ly\/mVF39H",
      "display_url" : "bit.ly\/mVF39H"
    } ]
  },
  "geo" : { },
  "id_str" : "153934264218566656",
  "text" : "\u0416\u044E\u0441\u0442\u0438\u043D \u0447\u0443\u0442\u044C \u043D\u0435 \u0443\u043F\u0430\u043B\u0430 \u0432 \u043F\u0440\u043E\u043F\u0430\u0441\u0442\u044C #\u041E\u0432\u0446\u044B http:\/\/t.co\/GelHIaU4 http:\/\/t.co\/e88EhR1T",
  "id" : 153934264218566656,
  "created_at" : "2012-01-02 20:22:43 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153883743092883456",
  "text" : "\"\u0413\u0440\u044F\u0434\u0443\u0449\u0435\u0435 \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u0438\u0435\" - \u0434\u043E\u0432\u043E\u043B\u044C\u043D\u043E \u0443\u0432\u043B\u0435\u043A\u0430\u0442\u0435\u043B\u044C\u043D\u044B\u0439 \u0434\u043B\u044F \u0442\u0435\u043A\u0441\u0442\u043E\u0432 \u0441\u0432\u043E\u0435\u0433\u043E \u043A\u043B\u0430\u0441\u0441\u0430. sezamm \u0442\u043E\u0436\u0435 \u0431\u0443\u0434\u0435\u0442 \u043F\u043E\u0434\u0430\u043D \u043A\u0430\u043A \u0444\u043E\u0440\u043F\u043E\u0441\u0442 \u0438\u0441\u043A\u0440\u0435\u043D\u043D\u043E\u0441\u0442\u0438 \u0438 \u043C\u043D\u0438\u043C\u043E\u0439 \u0438\u043D\u0442\u0438\u043C\u043D\u043E\u0441\u0442\u0438",
  "id" : 153883743092883456,
  "created_at" : "2012-01-02 17:01:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/cQfDIqKS",
      "expanded_url" : "http:\/\/rutabook.livejournal.com\/28918.html",
      "display_url" : "rutabook.livejournal.com\/28918.html"
    } ]
  },
  "geo" : { },
  "id_str" : "153831959607513088",
  "text" : "SENTENTIA ab exterioribus ad interiora http:\/\/t.co\/cQfDIqKS",
  "id" : 153831959607513088,
  "created_at" : "2012-01-02 13:36:11 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]