Grailbird.data.tweets_2017_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/50RaOB8Ohk",
      "expanded_url" : "https:\/\/shz.am\/t52802736",
      "display_url" : "shz.am\/t52802736"
    } ]
  },
  "geo" : { },
  "id_str" : "908026197015240704",
  "text" : "Shazam: Oliver Koletzki &amp; Fran - It's A Pleasure To Meet You (Original Version) https:\/\/t.co\/50RaOB8Ohk",
  "id" : 908026197015240704,
  "created_at" : "2017-09-13 17:54:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 75 ],
      "url" : "https:\/\/t.co\/5CWicxWLnn",
      "expanded_url" : "https:\/\/shz.am\/t315270",
      "display_url" : "shz.am\/t315270"
    } ]
  },
  "geo" : { },
  "id_str" : "905003393843953666",
  "text" : "Shazam: Leonard Cohen - Dance Me To The End Of Love https:\/\/t.co\/5CWicxWLnn",
  "id" : 905003393843953666,
  "created_at" : "2017-09-05 09:43:17 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]