Grailbird.data.tweets_2014_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "470299022004355073",
  "text" : "\u0441\u0435\u0433\u043E\u0434\u043D\u044F \u044F \u043D\u0435 \u0438\u0441\u043A\u0430\u043B \u0432 \u0435\u0435 \u0440\u0435\u0447\u0438 \u043D\u0435\u0443\u043C\u0435\u043B\u043E \u0441\u043A\u0440\u044B\u0432\u0430\u044E\u0449\u0438\u0445 \u0441\u0435\u0431\u044F \u043F\u0430\u0440\u0430\u0434\u043E\u043A\u0441\u043E\u0432, \u044D\u0442\u0438\u0445 \u043E\u0442\u043B\u0438\u0447\u043D\u043E \u043F\u0440\u043E\u0434\u0430\u0432\u0430\u0435\u043C\u044B\u0445 \u0442\u043E\u0432\u0430\u0440\u043E\u0432 \u043D\u0430 \u0440\u044B\u043D\u043A\u0435 \u043C\u043D\u0435\u043D\u0438\u0439",
  "id" : 470299022004355073,
  "created_at" : "2014-05-24 20:23:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "465261500379451393",
  "text" : "\u0412 \u041C\u043E\u0441\u043A\u0432\u0435 \u0435\u0441\u0442\u044C \u043D\u0435\u043F\u043B\u043E\u0445\u043E\u0435 \u043A\u0430\u0444\u0435 West 4. Coffee Brew Bar, \u0440\u0430\u0441\u043F\u043E\u043B\u043E\u0436\u0435\u043D\u043D\u043E\u0435 \u043D\u0435\u0434\u0430\u043B\u0435\u043A\u043E \u043E\u0442 Pussy Riot church",
  "id" : 465261500379451393,
  "created_at" : "2014-05-10 22:46:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "464098576663330818",
  "text" : "\u043B\u044E\u0434\u0438 \u0441\u0438\u0434\u044F\u0442 \u0434\u043E\u043C\u0430 \u0438 \u0440\u0430\u0434\u0443\u044E\u0442\u0441\u044F, \u0447\u0442\u043E \u0442\u0435\u043B\u0435\u0444\u043E\u043D \u043D\u0435 \u0437\u0432\u043E\u043D\u0438\u0442; \u0430 \u043A\u043E\u0433\u0434\u0430 \u043E\u043D \u0437\u0432\u043E\u043D\u0438\u0442, \u043D\u0435 \u0431\u0435\u0440\u0443\u0442 \u0442\u0440\u0443\u0431\u043A\u0443, \u0438 \u0441\u043E\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0437\u0430\u043F\u0438\u0441\u044B\u0432\u0430\u0435\u0442\u0441\u044F \u043D\u0430 \u0430\u0432\u0442\u043E\u043E\u0442\u0432\u0435\u0442\u0447\u0438\u043A",
  "id" : 464098576663330818,
  "created_at" : "2014-05-07 17:44:57 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/TzYyk3vpiD",
      "expanded_url" : "http:\/\/37.media.tumblr.com\/0fad2485066cff131bb645d63348f388\/tumblr_meuqasqeMo1qcmo9qo1_1280.jpg",
      "display_url" : "37.media.tumblr.com\/0fad2485066cff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "463387112445063170",
  "text" : "http:\/\/t.co\/TzYyk3vpiD",
  "id" : 463387112445063170,
  "created_at" : "2014-05-05 18:37:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "462348655690006528",
  "text" : "\u0445\u0440\u0430\u043D\u044E \u043F\u043E\u0434 \u043A\u0440\u043E\u0432\u0430\u0442\u044C\u044E \u0441\u0442\u043E\u043F\u043A\u0443 \u043A\u043E\u043C\u0438\u043A\u0441\u043E\u0432 \u043F\u0440\u043E \u041F\u0438\u0444\u0430 - \u0441\u0432\u0438\u0434\u0435\u0442\u0435\u043B\u0435\u0439 \u043D\u0435\u0438\u0441\u043F\u043E\u0432\u0435\u0434\u0438\u043C\u043E\u0433\u043E \u0440\u0430\u044F \u0438 \u0430\u043F\u043E\u0441\u0442\u0440\u043E\u0444 \u043D\u0435\u0437\u0430\u0431\u044B\u0432\u0430\u0435\u043C\u044B\u0445 \u0436\u0435\u043B\u0430\u043D\u0438\u0439, \u043F\u0440\u0438\u0434\u0443\u043C\u0430\u043D\u043D\u044B\u0445 \u043A\u043E\u043C \u043F\u0430\u0440\u0442\u0438\u0435\u0439 \u042E\u043C\u0430\u043D\u0438\u0442\u0435",
  "id" : 462348655690006528,
  "created_at" : "2014-05-02 21:51:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]