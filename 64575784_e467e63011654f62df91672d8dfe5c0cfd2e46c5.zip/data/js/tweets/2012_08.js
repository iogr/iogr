Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241442489502928896",
  "text" : "\u0411\u044B\u043B \u043B\u0438 \u0443 \u0428\u0435\u0440\u0432\u0443\u0434\u0430 \u0410\u043D\u0434\u0435\u0440\u0441\u043E\u043D\u0430 \u043F\u0430\u0442\u0435\u043D\u0442\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0441\u0446\u0435\u043D\u0430\u0440\u043D\u044B\u0439 \u043A\u043E\u043C\u043F\u0438\u043B\u044F\u0442\u043E\u0440 \u0442\u0438\u043F\u0430 \u0442\u0440\u0435\u0443\u0433\u043E\u043B\u044C\u043D\u044B\u0445 \u043A\u043E\u043D\u0432\u0435\u0440\u0442\u0438\u043A\u043E\u0432 \u0438\u043B\u0438 \u043A\u0430\u0440\u0442\u043E\u0442\u0435\u0447\u043D\u043E\u0433\u043E \u043A\u043E\u0440\u043E\u0431\u0430? \"\u0428\u0430\u0440\u0438\u043A\u0438 \u0438\u0437 \u0431\u0443\u043C\u0430\u0433\u0438\"?",
  "id" : 241442489502928896,
  "created_at" : "2012-08-31 07:49:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/YQlvQTm9",
      "expanded_url" : "http:\/\/arxiv.org\/abs\/1208.5715",
      "display_url" : "arxiv.org\/abs\/1208.5715"
    } ]
  },
  "geo" : { },
  "id_str" : "241049114660462593",
  "text" : "if AdS4 space-times are a crime then I am Jesse James http:\/\/t.co\/YQlvQTm9",
  "id" : 241049114660462593,
  "created_at" : "2012-08-30 05:46:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NietzscheQuotes",
      "screen_name" : "NietzscheQuotes",
      "indices" : [ 3, 19 ],
      "id_str" : "50056496",
      "id" : 50056496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238183434617491456",
  "text" : "RT @NietzscheQuotes: In the stream. - Mighty waters draw much stone and rubble along with them; mighty spirits many stupid and bewildere ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nietzsche",
        "indices" : [ 125, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "237916936774766593",
    "text" : "In the stream. - Mighty waters draw much stone and rubble along with them; mighty spirits many stupid and bewildered heads.  #Nietzsche",
    "id" : 237916936774766593,
    "created_at" : "2012-08-21 14:19:52 +0000",
    "user" : {
      "name" : "NietzscheQuotes",
      "screen_name" : "NietzscheQuotes",
      "protected" : false,
      "id_str" : "50056496",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/278748917\/Nietzsche1882_normal.jpg",
      "id" : 50056496,
      "verified" : false
    }
  },
  "id" : 238183434617491456,
  "created_at" : "2012-08-22 07:58:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237943468884914176",
  "text" : "\u0422\u0440\u0438 \u043D\u0435\u0434\u0435\u043B\u0438 \u043F\u0440\u0438\u0434\u0435\u0442\u0441\u044F \u0445\u043E\u0434\u0438\u0442\u044C \u0441 \u0442\u0440\u043E\u0441\u0442\u044C\u044E. Wohoo!",
  "id" : 237943468884914176,
  "created_at" : "2012-08-21 16:05:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/I4cB6VIP",
      "expanded_url" : "http:\/\/instagr.af",
      "display_url" : "instagr.af"
    } ]
  },
  "geo" : { },
  "id_str" : "232979464634642432",
  "text" : "This days sleeping  turns out to be way more exciting than living. http:\/\/t.co\/I4cB6VIP",
  "id" : 232979464634642432,
  "created_at" : "2012-08-07 23:20:07 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232684898522112000",
  "text" : "\u041F\u043E\u0440\u0432\u0430\u043B \u0431\u0438\u0446\u0435\u043F\u0441\u043E\u043C \u0440\u0443\u043A\u0430\u0432 \u0443 \u0440\u0443\u0431\u0430\u0448\u043A\u0438. I'll miss you, high protein appetiser marks. Will you miss me",
  "id" : 232684898522112000,
  "created_at" : "2012-08-07 03:49:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arnold",
      "screen_name" : "Schwarzenegger",
      "indices" : [ 3, 18 ],
      "id_str" : "12044602",
      "id" : 12044602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/eIm6kZGH",
      "expanded_url" : "http:\/\/www.schwarzenegger.com\/fitness\/post\/just-1-percent",
      "display_url" : "schwarzenegger.com\/fitness\/post\/j\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "232658484989161472",
  "text" : "RT @Schwarzenegger: In case you need some Monday motivation, I\u2019m here for you: http:\/\/t.co\/eIm6kZGH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/eIm6kZGH",
        "expanded_url" : "http:\/\/www.schwarzenegger.com\/fitness\/post\/just-1-percent",
        "display_url" : "schwarzenegger.com\/fitness\/post\/j\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "232623227778772993",
    "text" : "In case you need some Monday motivation, I\u2019m here for you: http:\/\/t.co\/eIm6kZGH",
    "id" : 232623227778772993,
    "created_at" : "2012-08-06 23:44:34 +0000",
    "user" : {
      "name" : "Arnold",
      "screen_name" : "Schwarzenegger",
      "protected" : false,
      "id_str" : "12044602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1113949429214486528\/sBbamBnV_normal.jpg",
      "id" : 12044602,
      "verified" : true
    }
  },
  "id" : 232658484989161472,
  "created_at" : "2012-08-07 02:04:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Helberg",
      "screen_name" : "simonhelberg",
      "indices" : [ 3, 16 ],
      "id_str" : "187428929",
      "id" : 187428929
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "231980782124662785",
  "text" : "RT @simonhelberg: Michael Phelps has a schwimmer's face.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "231975489470865408",
    "text" : "Michael Phelps has a schwimmer's face.",
    "id" : 231975489470865408,
    "created_at" : "2012-08-05 04:50:41 +0000",
    "user" : {
      "name" : "Simon Helberg",
      "screen_name" : "simonhelberg",
      "protected" : false,
      "id_str" : "187428929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1381902112\/image_normal.jpg",
      "id" : 187428929,
      "verified" : true
    }
  },
  "id" : 231980782124662785,
  "created_at" : "2012-08-05 05:11:43 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]