Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318517894218645504",
  "text" : "\u043A\u0438\u043D\u044C\u044F\u0440, \u044F\u0433\u0443\u0430\u0440, \u043C\u0434\u043F",
  "id" : 318517894218645504,
  "created_at" : "2013-04-01 00:19:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/TWXqSLjwXJ",
      "expanded_url" : "http:\/\/i887.photobucket.com\/albums\/ac76\/geoleeman\/awesomee.jpg",
      "display_url" : "i887.photobucket.com\/albums\/ac76\/ge\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316014154311946240",
  "text" : "6:05, \u043F\u0440\u043E\u0441\u043D\u0443\u043B\u0441\u044F \u043E\u0442 \u043F\u043E\u0445\u043C\u0435\u043B\u044C\u044F \u2013 \u0432 \u043E\u0431\u043D\u0438\u043C\u043A\u0443 \u0441\u043E \u0441\u0442\u043E\u043F\u043A\u043E\u0439 \u043A\u043D\u0438\u0433 \u043F\u043E \u0448\u0435\u043A\u0441\u043F\u0438\u0440\u043E\u0432\u0435\u0434\u0435\u043D\u0438\u044E. http:\/\/t.co\/TWXqSLjwXJ",
  "id" : 316014154311946240,
  "created_at" : "2013-03-25 02:30:20 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315042929439805441",
  "text" : "But a RocknRolla, oh, he's different. Why? Because a real RocknRolla wants the fucking lot.",
  "id" : 315042929439805441,
  "created_at" : "2013-03-22 10:11:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314303587775832064",
  "text" : "(\u043A\u0430\u0442\u0430\u044E\u0441\u044C \u043F\u043E \u043F\u043E\u043B\u0443, \u043D\u0430\u0431\u043B\u044E\u0434\u0430\u044F \u0443\u0432\u043B\u0435\u043A\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043A\u0440\u044B\u0441\u0438\u043D\u043E\u0435 \u043F\u043E\u0440\u043D\u043E)",
  "id" : 314303587775832064,
  "created_at" : "2013-03-20 09:13:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314303473501999106",
  "text" : "\u0432\u0430\u0448\u0438 \u0434\u0440\u0443\u0437\u044C\u044F \u0434\u0436\u0438\u043D\u043D\u0438 \u0438 \u0442\u043E\u043D\u0438\u043A \u043F\u0440\u0438\u0433\u043B\u0430\u0448\u0430\u044E\u0442 \u0432\u0430\u0441 \u0431\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u043E \u0432\u0441\u0442\u0443\u043F\u0438\u0442\u044C \u0432 \u043A\u043B\u0443\u0431 \u043D\u0430 \u0441\u0430\u0439\u0442\u0435 \u0448\u043E\u043F\u043E\u0433\u043E\u043B\u0438\u043A.\u0440\u0443 \u041A\u041F\u041F\u041D\u0423\u041A\u041F",
  "id" : 314303473501999106,
  "created_at" : "2013-03-20 09:12:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312318479233581057",
  "text" : "* \u0446\u0438\u043D\u0438\u0447\u043D\u043E \u0441\u0442\u0440\u044F\u0445\u043D\u0443\u0432 \u043F\u0435\u043F\u0435\u043B \u043D\u0430 \u0431\u0440\u044E\u043A\u0438, \u043F\u0440\u043E\u0447\u0438\u0449\u0430\u044E \u043F\u043E\u0432\u0435\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u0433\u043E\u0440\u043B\u043E",
  "id" : 312318479233581057,
  "created_at" : "2013-03-14 21:45:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311532195623882752",
  "text" : "Perceval?",
  "id" : 311532195623882752,
  "created_at" : "2013-03-12 17:40:38 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311279334059028481",
  "text" : "\u041A\u0443\u0441\u043E\u043A \u043B\u044C\u0434\u0430, \u0434\u0435\u0442\u0430\u043B\u044C \u043E\u0442 \u043F\u0430\u0440\u043E\u0432\u043E\u0437\u0430.",
  "id" : 311279334059028481,
  "created_at" : "2013-03-12 00:55:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FictionalCharactersIWantToMarry",
      "indices" : [ 0, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309823941768269824",
  "text" : "#FictionalCharactersIWantToMarry Angelique Bouchard",
  "id" : 309823941768269824,
  "created_at" : "2013-03-08 00:32:38 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]