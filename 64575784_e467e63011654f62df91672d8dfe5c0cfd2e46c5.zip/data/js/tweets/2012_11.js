Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/readability.com\" rel=\"nofollow\"\u003EReadability\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/sm7ku0RF",
      "expanded_url" : "http:\/\/rdd.me\/k5afjpuh",
      "display_url" : "rdd.me\/k5afjpuh"
    } ]
  },
  "geo" : { },
  "id_str" : "273169358631608320",
  "text" : "Speculative Heresy http:\/\/t.co\/sm7ku0RF",
  "id" : 273169358631608320,
  "created_at" : "2012-11-26 21:00:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Readmill",
      "screen_name" : "Readmill",
      "indices" : [ 101, 110 ],
      "id_str" : "220296634",
      "id" : 220296634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 132 ],
      "url" : "https:\/\/t.co\/tNa4e6Ke",
      "expanded_url" : "https:\/\/readmill.com\/joanofarctan\/reads\/after-finitude-an-essay-on-the-necessity-of-contingency\/highlights\/bf35",
      "display_url" : "readmill.com\/joanofarctan\/r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273168342112690176",
  "text" : "\u201CConsciousness and its language certainly transcend themselves towards the world, but there is\u2026\u201D via @Readmill https:\/\/t.co\/tNa4e6Ke",
  "id" : 273168342112690176,
  "created_at" : "2012-11-26 20:56:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/Qf5O4w5W",
      "expanded_url" : "http:\/\/instagr.am\/p\/SQr8MMq9Pz\/",
      "display_url" : "instagr.am\/p\/SQr8MMq9Pz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "270950717957763074",
  "text" : "\u0437\u0430\u043C\u0435\u0442\u043A\u0430 \u043E \u043A\u0430\u0443\u0444\u043C\u0430\u043D\u0435 http:\/\/t.co\/Qf5O4w5W",
  "id" : 270950717957763074,
  "created_at" : "2012-11-20 18:04:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/readmill.com\" rel=\"nofollow\"\u003EReadmill\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Readmill",
      "screen_name" : "Readmill",
      "indices" : [ 130, 139 ],
      "id_str" : "220296634",
      "id" : 220296634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/TeIVO58o",
      "expanded_url" : "http:\/\/rdml.it\/T6n3E1",
      "display_url" : "rdml.it\/T6n3E1"
    } ]
  },
  "geo" : { },
  "id_str" : "270473057854951424",
  "text" : "\u201CI had been passing alone, on horseback, through a singularly dreary tract of country; and at length f\u2026\u201D http:\/\/t.co\/TeIVO58o via @Readmill",
  "id" : 270473057854951424,
  "created_at" : "2012-11-19 10:26:16 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/readmill.com\" rel=\"nofollow\"\u003EReadmill\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Readmill",
      "screen_name" : "Readmill",
      "indices" : [ 130, 139 ],
      "id_str" : "220296634",
      "id" : 220296634
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/FIE6qenG",
      "expanded_url" : "http:\/\/rdml.it\/WdMxQg",
      "display_url" : "rdml.it\/WdMxQg"
    } ]
  },
  "geo" : { },
  "id_str" : "269907770889863169",
  "text" : "\u201C\u041F\u0443\u0442\u0435\u0448\u0435\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u2013 \u043F\u043E\u043B\u0435\u0437\u043D\u043E, \u044D\u0442\u043E \u0437\u0430\u0441\u0442\u0430\u0432\u043B\u044F\u0435\u0442 \u0440\u0430\u0431\u043E\u0442\u0430\u0442\u044C \u0432\u043E\u043E\u0431\u0440\u0430\u0436\u0435\u043D\u0438\u0435. \u0412\u0441\u0435 \u043E\u0441\u0442\u0430\u043B\u044C\u043D\u043E\u0435 \u2013 \u0440\u0430\u0437\u043E\u0447\u0430\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u0438 \u0443\u0441\u0442\u0430\u043B\u043E\u2026\u201D http:\/\/t.co\/FIE6qenG via @Readmill",
  "id" : 269907770889863169,
  "created_at" : "2012-11-17 21:00:01 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269882704579944448",
  "text" : "\u041A\u0430\u0440\u0442\u0430 \u0438 \u0442\u0435\u0440\u0440\u0438\u0442\u043E\u0440\u0438\u044F \u0423\u044D\u043B\u044C\u0431\u0435\u043A\u0430 \u043D\u0435\u043E\u0436\u0438\u0434\u0430\u043D\u043D\u043E \u043F\u0440\u0435\u0432\u043E\u0441\u0445\u043E\u0434\u043D\u044B\u0439, \u043D\u0430\u0434\u0435\u044E\u0441\u044C, \u0447\u0442\u043E \u0438 \u0411\u0435\u0440\u0442\u043E\u043B\u0443\u0447\u0447\u0438 \u043F\u043E\u0448\u043B\u0438 \u043D\u0430 \u043F\u043E\u043B\u044C\u0437\u0443 \u043A\u0430\u043D\u0438\u043A\u0443\u043B\u044B, \u043D\u0430 \u043A\u043E\u0442\u043E\u0440\u044B\u0445 \u0412\u0443\u0434\u0438 \u0440\u0430\u0431\u043E\u0442\u0430\u043B \u0432 \u0434\u0432\u0435 \u0441\u043C\u0435\u043D\u044B",
  "id" : 269882704579944448,
  "created_at" : "2012-11-17 19:20:25 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/tsJ6kL4x",
      "expanded_url" : "http:\/\/shar.es\/GkbFE",
      "display_url" : "shar.es\/GkbFE"
    } ]
  },
  "geo" : { },
  "id_str" : "269402517098602496",
  "text" : "http:\/\/t.co\/tsJ6kL4x \"\u0442\u0435\u0431\u0435 \u043D\u0435 \u0445\u0432\u0430\u0442\u0430\u0435\u0442 \u043C\u0430\u043B\u043E\u0433\u043E: \u043F\u043E\u043D\u044F\u0442\u044C, \u0447\u0442\u043E \u043D\u0430\u0441 \u0442\u043E\u043B\u044C\u043A\u043E \u0434\u0432\u043E\u0435, \u0447\u0442\u043E \u0432\u0440\u0435\u043C\u044F - \u043E\u0434\u043D\u043E \u043D\u0430\u0435-\u0432\u043E, \u043F\u0440\u043E\u0441\u0442\u0440\u0430\u043D\u0441\u0442\u0432\u043E-\u0434\u0440\u0443\u0433\u043E\u0435\". \u0418\u0437 \u043F\u0435\u0440\u0432\u043E\u0439 \u041A\u0440\u0438\u0442\u0438\u043A\u0438.",
  "id" : 269402517098602496,
  "created_at" : "2012-11-16 11:32:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/8VNjgYlv",
      "expanded_url" : "http:\/\/www.nonfunctionalthoughts.net",
      "display_url" : "nonfunctionalthoughts.net"
    } ]
  },
  "geo" : { },
  "id_str" : "268144729160572928",
  "text" : "http:\/\/t.co\/8VNjgYlv \u041F\u0435\u0440\u0444\u043E\u043C\u0430\u043D\u0441\u044B \u0438 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u044F \u0427\u0435\u0437\u0430\u0440\u0435 \u041F\u044C\u0435\u0442\u0440\u043E\u044E\u0441\u0442\u0438",
  "id" : 268144729160572928,
  "created_at" : "2012-11-13 00:14:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]