Grailbird.data.tweets_2016_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "733047817737015296",
  "text" : "\u0411\u0435\u043D \u042D\u043B\u0442\u043E\u043D 2\/15",
  "id" : 733047817737015296,
  "created_at" : "2016-05-18 21:33:13 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "730480443741581312",
  "text" : "\u0433\u043E\u0440\u043C\u043E\u043D\u0430\u043B\u044C\u043D\u044B\u0435 \u0438\u043D\u0442\u0435\u0440\u043F\u0440\u0435\u0442\u0430\u0442\u043E\u0440\u044B \u0432\u0437\u0430\u0438\u043C\u043E\u0434\u0435\u0439\u0441\u0442\u0432\u0443\u044E\u0442 \u0441 \u0448\u0430\u0440\u043E\u043C \u043D\u0430 7140 \u043C2, \u0433\u043E\u0440\u043C\u043E\u043D\u044B \u0438 \u043F\u0440\u043E\u0441\u0442\u0430\u0442\u044B \u043A\u043E\u043C\u043F\u0438\u043B\u0438\u0440\u0443\u044E\u0442 \u0434\u0430\u043D\u043D\u044B\u0435 \u044D\u043A\u0440\u0430\u043D\u0430 \u0432 \u0434\u0438\u0441\u043A\u0443\u0440\u0441\u0438\u0432\u043D\u044B\u0435 \u0437\u0432\u0443\u043A\u0438",
  "id" : 730480443741581312,
  "created_at" : "2016-05-11 19:31:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729605949921607680",
  "text" : "Casella Alfredo &amp; Rosamonte especial",
  "id" : 729605949921607680,
  "created_at" : "2016-05-09 09:36:28 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Web App\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "729031862966956032",
  "text" : "You",
  "id" : 729031862966956032,
  "created_at" : "2016-05-07 19:35:15 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Web App\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/uq9zgP8tVe",
      "expanded_url" : "https:\/\/github.com\/iogr\/FuntikC",
      "display_url" : "github.com\/iogr\/FuntikC"
    } ]
  },
  "geo" : { },
  "id_str" : "727050175982800896",
  "text" : "Published FuntikC (scala FuntikParser): Programming language based on the one-liners of Funtik and Gospoga Beladonna https:\/\/t.co\/uq9zgP8tVe",
  "id" : 727050175982800896,
  "created_at" : "2016-05-02 08:20:44 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]