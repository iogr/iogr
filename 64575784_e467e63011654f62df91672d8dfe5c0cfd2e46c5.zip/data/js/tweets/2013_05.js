Grailbird.data.tweets_2013_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "339838018334625793",
  "text" : "\u041F\u0440\u043E\u043B\u0435\u0436\u0430\u043B \u0442\u0440\u043E\u0435 \u0441\u0443\u0442\u043E\u043A \u0441 \u0442\u0435\u043C\u043F\u0435\u0440\u0430\u0442\u0443\u0440\u043E\u0439 (\u043D\u0430 \u043F\u043E\u043B\u0443, \u0432 \u0442\u0435\u043C\u043D\u043E\u0442\u0435 \u0438 \u0442\u0438\u0448\u0438\u043D\u0435), \u0430 \u0442\u0435\u043F\u0435\u0440\u044C \u0432\u044B\u0431\u0440\u0430\u043B\u0441\u044F \u0441 \u043E\u0444\u0441\u0435\u0442\u043D\u044B\u043C \u0442\u043E\u043C\u043E\u043C \u042D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u0440\u043D\u044B\u0445 \u0447\u0430\u0441\u0442\u0438\u0446 \u0444\u043E\u0440\u043C\u0430\u0442\u0430 76\u0445100 1\/32",
  "id" : 339838018334625793,
  "created_at" : "2013-05-29 20:17:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "334102855512387584",
  "text" : "\u0417\u0430\u043A\u0438\u043D\u0443\u043B\u0441\u044F \u0441\u043D\u043E\u0442\u0432\u043E\u0440\u043D\u044B\u043C, \n\u0440\u0430\u0441\u043F\u0435\u0447\u0430\u0442\u044B\u0432\u0430\u044E \u0430\u043B\u044C\u0431\u043E\u043C \u0425\u0443\u043D\u0434\u0435\u0440\u0442\u0432\u0430\u0441\u0441\u0435\u0440\u0430",
  "id" : 334102855512387584,
  "created_at" : "2013-05-14 00:28:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]