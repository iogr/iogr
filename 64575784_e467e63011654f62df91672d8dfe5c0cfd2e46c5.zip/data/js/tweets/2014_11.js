Grailbird.data.tweets_2014_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "538073968096579584",
  "text" : "\u043F\u0435\u0440\u0435\u0436\u0438\u0434\u0430\u044E \u0434\u0435\u043F\u0440\u0435\u0441\u0441\u0438\u044E, \u043E\u0434\u0438\u043D\u043E\u0447\u0435\u0441\u0442\u0432\u043E, \u043D\u0435\u043D\u0430\u0432\u0438\u0441\u0442\u044C \u0438 \u043F\u043E\u043B\u043D\u043E\u0435 \u043E\u0442\u0441\u0443\u0442\u0441\u0442\u0432\u0438\u0435 \u0432\u0435\u0440\u044B \u0432 \u0441\u0435\u0431\u044F",
  "id" : 538073968096579584,
  "created_at" : "2014-11-27 20:56:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537134072766926849",
  "text" : "Tracht Gut Vet Zayn Gut!",
  "id" : 537134072766926849,
  "created_at" : "2014-11-25 06:41:57 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537027418415190017",
  "text" : "\u0441\u0432\u0435\u0440\u0445\u0441\u0435\u0441\u0443\u0430\u043B\u044C\u043D\u044B\u0439 \u0437\u0430\u043A\u0430\u0442 \u0435\u0432\u0440\u043E\u043F\u044B, \u0437\u0432\u0435\u0437\u0434\u0430 \u0434\u0435\u0442\u0441\u043A\u043E\u0433\u043E \u043F\u043E\u0440\u043D\u043E Siberian mouse. \u0441\u0442\u044B\u0434\u043D\u043E \u043D\u0435 \u0437\u043D\u0430\u0442\u044C, \u0432 \u043F\u0440\u0438\u043B\u0438\u0447\u043D\u043E\u043C \u043E\u0431\u0449\u0435\u0441\u0442\u0432\u0435 \u043C\u043E\u0436\u043D\u043E \u043F\u043E\u043F\u0430\u0441\u0442\u044C \u0432 \u043D\u0435\u043B\u043E\u0432\u043A\u0443\u044E \u0441\u0438\u0442\u0443\u0430\u0446\u0438\u044E",
  "id" : 537027418415190017,
  "created_at" : "2014-11-24 23:38:08 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "537025777179832320",
  "text" : "\u0418\u043D\u0442\u0435\u0440\u0441\u0442\u0435\u043B\u043B\u0430\u0440 \u0438\u0437\u043C\u0435\u043D\u0438\u043B \u0432\u0441\u0435 \u0431\u0430\u043D\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u044C\u044E, \u0441 \u043A\u043E\u0442\u043E\u0440\u043E\u0439 \u043D\u0435 \u0441\u043C\u0438\u0440\u0438\u0442\u044C\u0441\u044F.\u041A\u0430\u043A \u0441 \u043A\u043D\u043E\u043F\u043A\u043E\u0439 000 \u0432 \u0431\u0430\u043D\u043A\u043E\u043C\u0430\u0442\u0435 \u0438\u043B\u0438 \u043C\u043E\u0437\u0433\u043E\u043C \u041A\u0430\u0433\u0430\u0440\u043B\u0438\u0446\u043A\u043E\u0433\u043E,\u043F\u0435\u0440\u0435\u0441\u0430\u0436\u0435\u043D\u043D\u043E\u043C Lego-\u0440\u043E\u0431\u043E\u0442\u0443",
  "id" : 537025777179832320,
  "created_at" : "2014-11-24 23:31:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536578095705518080",
  "text" : "\u2115 (\u041C\u0430\u0442\u0435\u0438\u043D) = (\u043A\u043E\u0444\u0435\u0438\u043D (\u0442\u0440\u0438\u043C\u0435\u0442\u0438\u043B\u043A\u0441\u0430\u043D\u0442\u0438\u043D) \u222A \u0442\u0435\u043E\u0431\u0440\u043E\u043C\u0438\u043D (3,7- \u0434\u0438\u043C\u0435\u0442\u0438\u043B\u043A\u0441\u0430\u043D\u0442\u0438\u043D) \u222A \u0442\u0435\u043E\u0444\u0438\u043B\u043B\u0438\u043D (\u043D\u0435 \u043F\u0443\u0442\u0430\u0442\u044C \u0441 \u0442\u0444\u0438\u043B\u0438\u043D\u043E\u043C, 1,3-\u0434\u0438\u043C\u0435\u0442\u0438\u043B\u043A\u0441\u0430\u043D\u0442\u0438\u043D)), \u2208 \u041A\u0441\u0430\u043D\u0442\u0438\u043D\u044B",
  "id" : 536578095705518080,
  "created_at" : "2014-11-23 17:52:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "536574753549852673",
  "text" : "\u041C\u0430\u0442\u0435\u0438\u043D - \u043D\u0435 \u0441\u0442\u0435\u0440\u0435\u043E\u0438\u0437\u043E\u043C\u0435\u0440 \u043A\u043E\u0444\u0435\u0438\u043D\u0430. \u041A\u043E\u0444\u0435\u0438\u043D \u043D\u0435 \u0438\u043C\u0435\u0435\u0442 \u0441\u0442\u0435\u0440\u0435\u043E\u0446\u0435\u043D\u0442\u0440\u0430 \u0438, \u0441\u043E\u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u043E, \u043D\u0435 \u0438\u043C\u0435\u0435\u0442 \u0441\u0442\u0435\u0440\u0435\u043E\u0438\u0437\u043E\u043C\u0435\u0440\u043E\u0432.",
  "id" : 536574753549852673,
  "created_at" : "2014-11-23 17:39:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/X97Tzuldid",
      "expanded_url" : "http:\/\/failedmessiah.com",
      "display_url" : "failedmessiah.com"
    } ]
  },
  "geo" : { },
  "id_str" : "536441665100455937",
  "text" : "\u0415\u0441\u043B\u0438 \u0441\u044A\u0435\u0441\u0442\u044C \u041C\u041D\u041E\u0413\u041E \u043A\u0438\u0441\u043B\u043E\u0442\u044B, \u043C\u043E\u0436\u043D\u043E \u0441\u0442\u0430\u0442\u044C \u041D\u041E\u0420\u041C\u0410\u041B\u042C\u041D\u042B\u041C \u0447\u0435\u043B\u043E\u0432\u0435\u043A\u043E\u043C, \u0435\u0441\u043B\u0438 \u0441\u044A\u0435\u0441\u0442\u044C \u041D\u0415\u041E\u0427\u0415\u041D\u042C \u043C\u043D\u043E\u0433\u043E \u043A\u0438\u0441\u043B\u043E\u0442\u044B, \u043C\u043E\u0436\u043D\u043E \u043F\u0440\u043E\u0441\u043D\u0443\u0442\u044C\u0441\u044F \u043D\u0430 http:\/\/t.co\/X97Tzuldid",
  "id" : 536441665100455937,
  "created_at" : "2014-11-23 08:50:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535911246395371520",
  "text" : "\u043F\u043E\u0447\u0442\u0438 \u043F\u043E\u043B\u0433\u043E\u0434\u0430, \u0447\u0442\u043E\u0431\u044B \u0434\u043E\u0441\u0442\u0430\u0442\u044C \u0436\u0438\u0437\u043D\u0435\u043D\u043D\u043E \u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C\u044B\u0435 \u043A\u0430\u0436\u0434\u043E\u043C\u0443 \"\u0430\u0439\u043E\u043C \u0448\u0435\u043B\u044C \u043E\u043F\u0440\u0438\u0447\u043D\u0438\u043A\" \u043D\u0430 \u0438\u0432\u0440\u0438\u0442\u0435 \u0438 \u0441\u0431\u0440\u0443\u0438 zana bayne (\u043F\u043E\u0434 \u043F\u0438\u0434\u0436\u0430\u043A) - \u044D\u0442\u043E \u043F\u0435\u0440\u0435\u0431\u043E\u0440",
  "id" : 535911246395371520,
  "created_at" : "2014-11-21 21:42:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535737105360900096",
  "text" : "\u0438 \u043F\u043E\u0441\u043A\u043E\u043B\u044C\u043A\u0443 \u0435\u0441\u0442\u044C \u0445\u0435\u0434\u0435\u0440\u044B, \u0432\u0441\u0435 \u044D\u0442\u0438 \u043F\u0430\u0440\u043E\u043B\u0438 \u0445\u0440\u0430\u043D\u044F\u0442\u0441\u044F \u0432 \u0442\u0432\u0438\u0442\u0442\u0435\u0440\u0435 \u043A\u0430\u043A \u0430\u0444\u0438\u043D\u0430 \u0432 \u0433\u043E\u043B\u043E\u0432\u0435 \u0437\u0435\u0432\u0441\u0430",
  "id" : 535737105360900096,
  "created_at" : "2014-11-21 10:10:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535736859767615489",
  "text" : "( \u0633\u062C\u0644 \u0648\u0627\u062D\u0635\u0644 \u0639\u0644\u0649 \u062A\u062F\u0631\u064A\u0628 \u0645\u062C\u0627\u0646\u064A ) \u0437\u0430\u0432\u0438\u0441\u0448\u0430\u044F \u0440\u0435\u043F\u043B\u0438\u043A\u0430 \u043F\u0430\u0440\u043E\u043B\u044F, \u043F\u0435\u0440\u0435\u0432\u043E\u0434\u0438\u0442\u0441\u044F \u043A\u0430\u043A \"\u0432\u0441\u0435\u043C \u043F\u0440\u0438\u0432\u0435\u0442 \u0432 \u044D\u0442\u043E\u043C \u0447\u0430\u0442\u0438\u043A\u0435\"",
  "id" : 535736859767615489,
  "created_at" : "2014-11-21 10:09:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "535731984535138305",
  "text" : "\u0421\u043E\u0441\u043A\u043E\u0447\u0438\u0442\u044C \u0441 \u0443\u0431\u0438\u0445\u0438\u043D\u043E\u043B\u0430, \u043A\u043E\u043C\u0438\u043A\u0441\u043E\u0432 \u043F\u0440\u043E \u041F\u0438\u0444\u0430 \u0438\u0437 ebay \u0438 \u0434\u0430\u0436\u0435 \u043F\u0435\u0440\u0435\u0441\u0442\u0430\u0442\u044C \u043F\u0435\u0440\u0435\u0441\u043B\u0443\u0448\u0438\u0432\u0430\u0442\u044C \u0434\u0438\u043A\u0442\u043E\u0444\u043E\u043D\u043D\u044B\u0435 \u0437\u0430\u043F\u0438\u0441\u0438 \u0440\u0430\u0437\u0433\u043E\u0432\u043E\u0440\u043E\u0432, \u043A\u043E\u0442\u043E\u0440\u044B\u043C \u043F\u043E 10 \u043B\u0435\u0442\u2026 ma no!",
  "id" : 535731984535138305,
  "created_at" : "2014-11-21 09:50:33 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/Qv6aCTY45v",
      "expanded_url" : "https:\/\/readymag.com\/",
      "display_url" : "readymag.com"
    } ]
  },
  "geo" : { },
  "id_str" : "534701197182369793",
  "text" : "https:\/\/t.co\/Qv6aCTY45v",
  "id" : 534701197182369793,
  "created_at" : "2014-11-18 13:34:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/T6OHrEC6Kh",
      "expanded_url" : "http:\/\/theoryandpractice.ru\/seminars\/72753-master-klass-kak-druzhit-s-gosudarstvom-19-11",
      "display_url" : "theoryandpractice.ru\/seminars\/72753\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "534432135302492160",
  "text" : "http:\/\/t.co\/T6OHrEC6Kh",
  "id" : 534432135302492160,
  "created_at" : "2014-11-17 19:45:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533998981739991040",
  "text" : "\u00AB\u041F\u043E\u0441\u043B\u0435 \u043F\u0443\u0431\u043B\u0438\u043A\u0430\u0446\u0438\u0438 \"\u042D\u043B\u0435\u043C\u0435\u043D\u0442\u0430\u0440\u043D\u044B\u0445 \u0447\u0430\u0441\u0442\u0438\u0446\" \u043F\u0438\u0441\u0430\u0442\u0435\u043B\u044C \u043F\u0443\u0431\u043B\u0438\u0447\u043D\u043E \u043D\u0430\u0437\u044B\u0432\u0430\u043B \u043C\u0430\u0442\u044C \"\u0441\u0442\u0430\u0440\u043E\u0439 \u0448\u043B\u044E\u0445\u043E\u0439\" \u0438 \u0437\u0430\u0432\u0435\u0440\u044F\u043B \u043F\u0440\u0435\u0441\u0441\u0443, \u0447\u0442\u043E \u043E\u043D\u0430 \u0443\u0436\u0435 \u0443\u043C\u0435\u0440\u043B\u0430.\u00BB",
  "id" : 533998981739991040,
  "created_at" : "2014-11-16 15:04:13 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533572336335990784",
  "text" : "\u041C\u043E\u0439 \u043B\u044E\u0431\u0438\u043C\u044B\u0439 \u0444\u0440\u0430\u0433\u043C\u0435\u043D\u0442 \u0443 \u0410\u043F\u0434\u0430\u0439\u043A\u0430 - \u043A\u043E\u0433\u0434\u0430 \u043F\u0438\u0441\u0430\u0442\u0435\u043B\u044C \u0438 \u0436\u0435\u043D\u0449\u0438\u043D\u0430, \u043F\u0435\u0440\u0435\u043E\u0434\u0435\u0442\u0430\u044F \u0432 \u043A\u043E\u0441\u0442\u044E\u043C \u043A\u043E\u0448\u043A\u0438 \u043F\u043E \u0442\u0440\u0443\u0431\u0435 \u043B\u0435\u0437\u0443\u0442 \u043A \u043B\u0438\u0442. \u043A\u0440\u0438\u0442\u0438\u043A\u0443, \u043A\u043E\u0442\u043E\u0440\u044B\u0439 \u0447\u0438\u0442\u0430\u0435\u0442 \u0411\u0435\u043D\u044C\u044F\u043C\u0438\u043D\u0430",
  "id" : 533572336335990784,
  "created_at" : "2014-11-15 10:48:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "533342574917189632",
  "text" : "Lol, \u0437\u0430\u0431\u044B\u043B \u043F\u0440\u043E \u043D\u0430\u043A\u043B\u0435\u0439\u043A\u0438 \u00AB\u043D\u0435 \u0437\u0430\u0431\u0443\u0434\u044C\u0442\u0435 \u043D\u0430\u0434\u0435\u0442\u044C \u043C\u0430\u0441\u043A\u0443 \u0441\u0447\u0430\u0441\u0442\u044C\u044F\u00BB \u0438 \u00AB\u043D\u0438\u043A\u043E\u0433\u0434\u0430 \u043D\u0435 \u0443\u043F\u0443\u0441\u043A\u0430\u0439 \u0432\u043E\u0437\u043C\u043E\u0436\u043D\u043E\u0441\u0442\u0438 \u0437\u0430\u043D\u044F\u0442\u044C\u0441\u044F \u0441\u0435\u043A\u0441\u043E\u043C \u0438\u043B\u0438 \u043F\u043E\u0447\u0438\u0442\u0430\u0442\u044C \u043A\u043D\u0438\u0433\u0443\u00BB \u043D\u0430 \u043D\u043E\u0443\u0442\u0431\u0443\u043A\u0435",
  "id" : 533342574917189632,
  "created_at" : "2014-11-14 19:35:53 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIW14",
      "indices" : [ 53, 59 ]
    }, {
      "text" : "RIW2014",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "riwguide",
      "indices" : [ 69, 78 ]
    }, {
      "text" : "riw",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "Moscow",
      "indices" : [ 84, 91 ]
    }, {
      "text" : "OpenData",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "BigData",
      "indices" : [ 102, 110 ]
    }, {
      "text" : "socialist",
      "indices" : [ 111, 121 ]
    }, {
      "text" : "actionpay",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/J6T1i6DGKN",
      "expanded_url" : "http:\/\/PM-Tech.ru",
      "display_url" : "PM-Tech.ru"
    } ]
  },
  "geo" : { },
  "id_str" : "532588458590875648",
  "text" : "http:\/\/t.co\/J6T1i6DGKN \u0412\u0435\u0431-\u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u043A\u0430 \u0438 Hardcore IT. #RIW14 #RIW2014 #riwguide #riw #Moscow #OpenData #BigData #socialist #actionpay",
  "id" : 532588458590875648,
  "created_at" : "2014-11-12 17:39:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531897410621308929",
  "text" : "is a Chaplinesque sort of an aufhebung self-sabotage within mom-approved dialectics",
  "id" : 531897410621308929,
  "created_at" : "2014-11-10 19:53:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531897294262898688",
  "text" : "digging through porn in search of a glimour of the communistic final fantasy",
  "id" : 531897294262898688,
  "created_at" : "2014-11-10 19:52:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "531492241471447041",
  "text" : "\u0433\u0435\u043C\u0430\u0442\u0440\u0438\u044F - \u0434\u0435\u0441\u0435\u0440\u0442 \u043A \u0441\u0442\u0430\u0442\u0443\u0441\u0443 \u0434\u0438\u0441\u043A\u0443\u0440\u0441\u0430, \u043F\u0440\u0438 \u043A\u043E\u0442\u043E\u0440\u043E\u043C \u043F\u0435\u0440\u043B\u043E\u043A\u0443\u0442\u0438\u0432\u043D\u044B\u0439 \u044D\u0444\u0444\u0435\u043A\u0442 \u0432\u044B\u0441\u0442\u0443\u043F\u0430\u0435\u0442 \u043E\u0442\u043F\u0440\u0430\u0432\u043D\u043E\u0439 \u0442\u043E\u0447\u043A\u043E\u0439 \u043A \u0442\u043E\u043C\u0443, \u0447\u0442\u043E\u0431\u044B \u043F\u0435\u0440\u0435\u0441\u043F\u0430\u0442\u044C \u0441 \u0431\u044C\u044E\u0442\u0438 \u0432\u043B\u043E\u0433\u0435\u0440\u0448\u0435\u0439",
  "id" : 531492241471447041,
  "created_at" : "2014-11-09 17:03:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "528686571512295424",
  "text" : "\u0421\u043F\u0430\u0441\u0438\u0431\u043E \u0413\u043E\u0441\u043F\u043E\u0434\u0443 \u0437\u0430 \u0447\u0435\u0440\u043D\u044B\u0439 \u0440\u044B\u043D\u043E\u043A. \u041D\u0435 \u0432 \u0431\u0443\u043A\u0432\u0430\u043B\u044C\u043D\u043E\u043C \u0441\u043C\u044B\u0441\u043B\u0435, \u043A\u043E\u043D\u0435\u0447\u043D\u043E.",
  "id" : 528686571512295424,
  "created_at" : "2014-11-01 23:14:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]