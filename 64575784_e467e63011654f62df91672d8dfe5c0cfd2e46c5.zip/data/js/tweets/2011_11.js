Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/LVCrnKn",
      "expanded_url" : "http:\/\/informer.rts.ru\/main\/graph\/issue\/RTS-12.11.gif",
      "display_url" : "informer.rts.ru\/main\/graph\/iss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "141783400913702912",
  "text" : "http:\/\/t.co\/LVCrnKn \u0440\u044B\u043D\u043E\u043A \u043C\u0430\u0440\u043A\u0435\u0442\u043C\u0435\u0439\u043A\u0435\u0440\u0430?",
  "id" : 141783400913702912,
  "created_at" : "2011-11-30 07:39:31 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141513233646366720",
  "text" : "\u0412 333 \u0434\u0435\u043D\u044C \u0433\u043E\u0434\u0430 \u043C\u0443\u0434\u0430\u043A\u0438 \u0441\u043D\u043E\u0432\u0430 \u043C\u0435\u0448\u0430\u044E\u0442 \u0437\u0430\u043D\u0438\u043C\u0430\u0442\u044C\u0441\u044F \u043B\u044E\u0431\u0438\u043C\u044B\u043C \u0434\u0435\u043B\u043E\u043C.",
  "id" : 141513233646366720,
  "created_at" : "2011-11-29 13:45:58 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140403254671577088",
  "text" : "My Heart Rate is 70. in sub",
  "id" : 140403254671577088,
  "created_at" : "2011-11-26 12:15:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140374705361272832",
  "text" : "My Heart Rate is 61. after lunch",
  "id" : 140374705361272832,
  "created_at" : "2011-11-26 10:21:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http:\/\/t.co\/EU383jH",
      "expanded_url" : "http:\/\/www.instantheartrate.com",
      "display_url" : "instantheartrate.com"
    } ]
  },
  "geo" : { },
  "id_str" : "140349117552541696",
  "text" : "My Heart Rate is 57. Measured with my iPhone. http:\/\/t.co\/EU383jH",
  "id" : 140349117552541696,
  "created_at" : "2011-11-26 08:40:11 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/2Le1QgN",
      "expanded_url" : "http:\/\/4sq.com\/uMsgOn",
      "display_url" : "4sq.com\/uMsgOn"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7532622477, 37.6483547688 ]
  },
  "id_str" : "140328269483483136",
  "text" : "I'm at \u0412\u044B\u0441\u0448\u0430\u044F \u0448\u043A\u043E\u043B\u0430 \u044D\u043A\u043E\u043D\u043E\u043C\u0438\u043A\u0438 (\u041D\u0418\u0423 \u0412\u0428\u042D) (\u041F\u043E\u043A\u0440\u043E\u0432\u0441\u043A\u0438\u0439 \u0431\u0443\u043B., \u0434. 11, \u0443\u043B. \u0412\u043E\u0440\u043E\u043D\u0446\u043E\u0432\u043E \u043F\u043E\u043B\u0435, \u041C\u043E\u0441\u043A\u0432\u0430) w\/ 19 others http:\/\/t.co\/2Le1QgN",
  "id" : 140328269483483136,
  "created_at" : "2011-11-26 07:17:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140082343330328576",
  "text" : "\u0412\u0432\u0435\u0434\u0435\u043D\u0438\u0435 1 \u043C\u0435\u0441. \u043B\u043E\u043A\u0430 \u043D\u0430 \u0442\u0440\u0430\u043D\u0441\u0444\u0435\u0440 \u0434\u043E\u043C\u0435\u043D\u043E\u0432 nic \u0441\u043B\u0438\u0448\u043A\u043E\u043C \u043F\u043E\u0445\u043E\u0436\u0435 \u043D\u0430 \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u0435 \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u0437\u0430\u043F\u0440\u0430\u0432\u0438\u0442\u044C\u0441\u044F \u043F\u043E 35, \u043F\u043E\u0442\u043E\u043C\u0443 \u0447\u0442\u043E \u0434\u0430\u043B\u044C\u0448\u0435 \u0432\u0441\u044E \u0434\u043E\u0440\u043E\u0433\u0443 \u0437\u0430 27.",
  "id" : 140082343330328576,
  "created_at" : "2011-11-25 15:00:07 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\/",
      "screen_name" : "zehnerson",
      "indices" : [ 3, 13 ],
      "id_str" : "3102036190",
      "id" : 3102036190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140080379569778688",
  "text" : "RT @zehnerson: \u0425\u043E\u0442\u0438\u0442\u0435 \u0430\u0434?\u042F \u043F\u043E\u043B\u0433\u043E\u0434\u0430 \u043E\u0431\u0449\u0430\u043B\u0441\u044F \u0441 \u0447\u0443\u0432\u0430\u043A\u043E\u043C \u0438\u0437 \u0418\u0437\u0440\u0430\u0438\u043B\u044F, \u0447\u0442\u043E\u0431\u044B \u043E\u043D \u043D\u0435 \u0437\u0430\u0431\u044B\u0432\u0430\u043B \u0440\u0443\u0441\u0441\u043A\u0438\u0439, \u043E\u043D \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0438\u043B \u043F\u043E\u0433\u043E\u0432\u043E\u0440\u0438\u0442\u044C \u043F\u043E \u0441\u043A\u0430\u0439\u043F\u0443 \u0438 \u043E\u043A\u0430\u0437\u0430\u043B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "140079759873933313",
    "text" : "\u0425\u043E\u0442\u0438\u0442\u0435 \u0430\u0434?\u042F \u043F\u043E\u043B\u0433\u043E\u0434\u0430 \u043E\u0431\u0449\u0430\u043B\u0441\u044F \u0441 \u0447\u0443\u0432\u0430\u043A\u043E\u043C \u0438\u0437 \u0418\u0437\u0440\u0430\u0438\u043B\u044F, \u0447\u0442\u043E\u0431\u044B \u043E\u043D \u043D\u0435 \u0437\u0430\u0431\u044B\u0432\u0430\u043B \u0440\u0443\u0441\u0441\u043A\u0438\u0439, \u043E\u043D \u043F\u0440\u0435\u0434\u043B\u043E\u0436\u0438\u043B \u043F\u043E\u0433\u043E\u0432\u043E\u0440\u0438\u0442\u044C \u043F\u043E \u0441\u043A\u0430\u0439\u043F\u0443 \u0438 \u043E\u043A\u0430\u0437\u0430\u043B\u0441\u044F \u0421\u041E\u0427\u041D\u0415\u0419\u0428\u0415\u0419 \u0422\u0415\u041B\u041A\u041E\u0419",
    "id" : 140079759873933313,
    "created_at" : "2011-11-25 14:49:51 +0000",
    "user" : {
      "name" : "\u0433\u0430\u0440\u043C\u043E\u043D\u0438\u044F \u043F\u043B\u0443\u0442\u043E\u0432\u0441\u0442\u0432\u0430",
      "screen_name" : "princdatskij",
      "protected" : false,
      "id_str" : "47102028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1012237731991351296\/3yJ4Vm8f_normal.jpg",
      "id" : 47102028,
      "verified" : false
    }
  },
  "id" : 140080379569778688,
  "created_at" : "2011-11-25 14:52:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140080169321902080",
  "text" : "\u043F\u0440\u0438 \u044D\u0442\u043E \u044F \u043A\u0430\u043A \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u043A\u0440\u0430\u043D \u043F\u0435\u0440\u0435\u0441\u0438\u0434\u0435\u043B \u043F\u043E\u0447\u0442\u0438 \u0432\u0435\u0441\u044C \u0443\u0431\u044B\u0442\u043E\u043A, \u043F\u043E\u0437\u0438\u0446\u0438\u044F \u0432\u0441\u0435 \u0435\u0449\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u0430 \u0438 \u0431\u0443\u0434\u0435\u0442 \u043F\u0435\u0440\u0435\u043D\u0435\u0441\u0435\u043D\u0430 overweekend.",
  "id" : 140080169321902080,
  "created_at" : "2011-11-25 14:51:29 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140079512745558017",
  "text" : "margin call ) \u043E\u0447\u0435\u0440\u0435\u0434\u043D\u043E\u0439 \u0443\u0440\u043E\u043A \u043F\u0440\u043E\u0442\u0438\u0432 \u0448\u0443\u0442\u043E\u043A \u0441 \u043E\u043F\u0446\u0438\u043E\u043D\u043E\u043C, \u0443 \u043A\u043E\u0442\u043E\u0440\u043E\u0433\u043E \u0433\u0430\u0440\u0430\u043D\u0442\u0438\u0439\u043D\u043E\u0435 \u043E\u0431\u0435\u0441\u043F\u0435\u0447\u0435\u043D\u0438\u0435 \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430 10 \u0442.\u0440., \u0430 \u043A\u0443\u0440\u0441\u043E\u0432\u0430\u044F \u0441\u0442\u043E\u0438\u043C\u043E\u0441\u0442\u044C 80.",
  "id" : 140079512745558017,
  "created_at" : "2011-11-25 14:48:53 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 85 ],
      "url" : "http:\/\/t.co\/5TEf6Ty",
      "expanded_url" : "http:\/\/4sq.com\/sNW9OY",
      "display_url" : "4sq.com\/sNW9OY"
    } ]
  },
  "geo" : {
    "type" : "Point",
    "coordinates" : [ 55.7721195777, 37.5929617882 ]
  },
  "id_str" : "139611582077476865",
  "text" : "I'm at \u041A\u0430\u0444\u0435 \u0420\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0430* (\u0443\u043B. 1-\u044F \u0422\u0432\u0435\u0440\u0441\u043A\u0430\u044F-\u042F\u043C\u0441\u043A\u0430\u044F, \u0434\u043E\u043C 10, \u041C\u043E\u0441\u043A\u0432\u0430) http:\/\/t.co\/5TEf6Ty",
  "id" : 139611582077476865,
  "created_at" : "2011-11-24 07:49:29 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/LVCrnKn",
      "expanded_url" : "http:\/\/informer.rts.ru\/main\/graph\/issue\/RTS-12.11.gif",
      "display_url" : "informer.rts.ru\/main\/graph\/iss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "139259730051858432",
  "text" : "http:\/\/t.co\/LVCrnKn",
  "id" : 139259730051858432,
  "created_at" : "2011-11-23 08:31:21 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138271269136248832",
  "text" : "\u041F\u0435\u0442\u0443\u0448\u043A\u0430 \u043E\u0441\u0432\u0438\u0441\u0442\u0430\u043B\u0438, \u043D\u043E \u043A\u0443\u0440\u043E\u0447\u043A\u0430 \u0435\u0449\u0435 \u0432 \u0433\u043D\u0435\u0437\u0434\u0435.",
  "id" : 138271269136248832,
  "created_at" : "2011-11-20 15:03:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137790857570025472",
  "text" : "\u041D\u0430 \u0444\u0438\u043D\u0430\u043D\u0441\u043E\u0432\u043E\u0439 \u044D\u043A\u043E\u043D\u043E\u043C\u0438\u043A\u0435: perpetuity, \u043A\u043E\u043D\u0441\u043E\u043B\u0438 \u0413\u0435\u043E\u0440\u0433\u0430 \u0438 \u043A\u043E\u0444\u0435 \u0438\u0437 dd.",
  "id" : 137790857570025472,
  "created_at" : "2011-11-19 07:14:35 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/foursquare.com\" rel=\"nofollow\"\u003EFoursquare\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 65 ],
      "url" : "http:\/\/t.co\/OfnyPxA",
      "expanded_url" : "http:\/\/4sq.com\/sy5KnM",
      "display_url" : "4sq.com\/sy5KnM"
    } ]
  },
  "geo" : { },
  "id_str" : "137114489790267394",
  "text" : "&lt;&lt;&lt;&lt;&lt;&lt; (@ \u041A\u0430\u0444\u0435 \u0420\u0435\u0441\u043F\u0443\u0431\u043B\u0438\u043A\u0430*) http:\/\/t.co\/OfnyPxA",
  "id" : 137114489790267394,
  "created_at" : "2011-11-17 10:26:56 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/UpmeHVo",
      "expanded_url" : "http:\/\/www.ridus.ru\/news\/10065\/",
      "display_url" : "ridus.ru\/news\/10065\/"
    } ]
  },
  "geo" : { },
  "id_str" : "137084383910838272",
  "text" : "http:\/\/t.co\/UpmeHVo\nQiiae quia non liceat non facit, illa facit",
  "id" : 137084383910838272,
  "created_at" : "2011-11-17 08:27:18 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http:\/\/t.co\/h8qpTY8",
      "expanded_url" : "http:\/\/anonim-from-rus.livejournal.com\/233878.html",
      "display_url" : "anonim-from-rus.livejournal.com\/233878.html"
    } ]
  },
  "geo" : { },
  "id_str" : "137075828931575808",
  "text" : "\u0427\u0430\u0441\u0442\u043E \u043A \u043A\u043E\u043D\u0446\u0443 \u0440\u0430\u0431\u043E\u0447\u0435\u0433\u043E \u0434\u043D\u044F \u044F \u043E\u0449\u0443\u0449\u0430\u044E \u0441\u0435\u0431\u044F \u043F\u0440\u0438\u043C\u0435\u0440\u043D\u043E \u0442\u0430\u043A:\nhttp:\/\/t.co\/h8qpTY8",
  "id" : 137075828931575808,
  "created_at" : "2011-11-17 07:53:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iogr\/status\/135842532260200449\/photo\/1",
      "indices" : [ 73, 92 ],
      "url" : "http:\/\/t.co\/dsiKaX1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AeKcEDkCQAEC7j7.png",
      "id_str" : "135842532264394753",
      "id" : 135842532264394753,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AeKcEDkCQAEC7j7.png",
      "sizes" : [ {
        "h" : 481,
        "resize" : "fit",
        "w" : 642
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 642
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 642
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 642
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/dsiKaX1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135842532260200449",
  "text" : "\u043F\u0435\u0440\u0432\u0430\u044F \u0441\u0446\u0435\u043D\u0430 \u0438\u0437 byte of the draculator, ags november 2011. \u043E\u0442\u043B\u043E\u0436\u0438\u043B \u043A \u043D\u0433. http:\/\/t.co\/dsiKaX1",
  "id" : 135842532260200449,
  "created_at" : "2011-11-13 22:12:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 54 ],
      "url" : "http:\/\/t.co\/j73gyjk",
      "expanded_url" : "http:\/\/graphics.thomsonreuters.com\/11\/07\/BV_ITDBT0711_VF.html",
      "display_url" : "graphics.thomsonreuters.com\/11\/07\/BV_ITDBT\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "135835337736990722",
  "text" : "calculator on Italy's debt spiral: http:\/\/t.co\/j73gyjk",
  "id" : 135835337736990722,
  "created_at" : "2011-11-13 21:44:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135760990917767168",
  "text" : "So I can not well avoid saying kong rats.",
  "id" : 135760990917767168,
  "created_at" : "2011-11-13 16:48:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 31 ],
      "url" : "http:\/\/t.co\/hQkoZgq",
      "expanded_url" : "http:\/\/info.mipt.ru\/index\/public\/n_5b42to.html?&xsl:onlynew=0",
      "display_url" : "info.mipt.ru\/index\/public\/n\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "135757886998581250",
  "text" : "RT @NES1992 http:\/\/t.co\/hQkoZgq \u043C\u0431 \u0441\u043C\u043E\u0433\u0443 \u043B\u0438\u0447\u043D\u043E \u043F\u043E\u0431\u043B\u0430\u0433\u043E\u0434\u0430\u0440\u0438\u0442\u044C \u0421\u0435\u0440\u0433\u0435\u044F \u0413\u0443\u0440\u0438\u0435\u0432\u0430 \u0437\u0430 \u0442\u0435\u043A\u0441\u0442 \u043E\u0431 \u0430\u043C\u043E\u0440\u0430\u043B\u044C\u043D\u043E\u0441\u0442\u0438 \u043F\u0440\u0438\u0437\u044B\u0432\u043D\u043E\u0433\u043E \u0440\u0430\u0431\u0441\u0442\u0432\u0430.",
  "id" : 135757886998581250,
  "created_at" : "2011-11-13 16:36:17 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135756728993189888",
  "text" : "\u041F\u0440\u0438\u0437\u043D\u0430\u044E\u0441\u044C, \u043E\u0442\u043A\u0440\u044B\u043B \u0448\u043E\u0440\u0442 riz1-rts 12.11, \u0442.\u043A \u0434\u0443\u043C\u0430\u043B, \u0447\u0442\u043E \u044D\u043A\u0441\u043F\u0438\u0440\u0430\u0446\u0438\u044F \u0444\u044C\u044E\u0447\u0435\u0440\u0441\u0430 \u0431\u0443\u0434\u0435\u0442 12 \u043D\u043E\u044F\u0431\u0440\u044F (\u043E\u043D\u0430 15) ;) epic, ftw.",
  "id" : 135756728993189888,
  "created_at" : "2011-11-13 16:31:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135369356841459712",
  "text" : "\u041D\u0435 \u0432\u0441\u0442\u0440\u0435\u0447\u0430\u044E \u0447\u0435\u0442\u044B\u0440\u0435\u0445 \u0437\u043D\u0430\u043A\u043E\u043C\u044B\u0445 \u0444\u0438\u043B\u043E\u0441\u043E\u0444\u043E\u0432 xor \u043F\u043E\u043B\u0438\u0442\u043E\u043B\u043E\u0433\u043E\u0432 \u043D\u0435 \u043D\u0430 8-\u0431\u0438\u0442\u043D\u043E\u0439 \u0434\u0438\u0441\u043A\u043E\u0442\u0435\u043A\u0435 \u0434\u043B\u044F \u043D\u0435\u0440\u0434\u043E\u0432 dev &gt; null \u0434\u043D\u0435\u0439.",
  "id" : 135369356841459712,
  "created_at" : "2011-11-12 14:52:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135334776126177281",
  "text" : "\u041C\u0435\u0434\u0432\u0435\u0434\u0435\u0432\u0430 \u0441\u043E \u0441\u0442\u043E\u0440\u043E\u043D\u043D\u0438\u043A\u0430\u043C\u0438, \u0433\u0434\u0435 \u043E\u043D \u043F\u043E\u043D\u0442\u043E\u0432\u0430\u043Bc\u044F \u0432 \u0441\u0442\u0438\u043B\u0435 \"\u044F \u0432\u0447\u0435\u0440\u0430 \u0432 4 \u0443\u0442\u0440\u0430 \u043F\u0440\u0430\u0432\u0438\u043B \u0441\u0442\u0430\u0442\u044C\u044E \u043F\u0440\u043E \u0447\u0435\u0440\u0435\u043F\u0430\u0448\u0435\u043A \u043D\u0438\u043D\u0434\u0437\u044F \u043D\u0430 \u043B\u0443\u0440\u043A\u0435, \u0430 \u0447\u0435\u0433\u043E \u0434\u043E\u0431\u0438\u043B\u0441\u044F \u0442\u044B?\",fgs!",
  "id" : 135334776126177281,
  "created_at" : "2011-11-12 12:34:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135334507246129152",
  "text" : "\u0414\u0440\u0443\u0437\u044C\u044F \u043E\u0442 \u0440\u0435\u0436\u0438\u043C\u0430 \u0445\u043E\u0442\u0435\u043B\u0438 \u043C\u0435\u043D\u044F \u0437\u0430\u0448\u043A\u0432\u0430\u0440\u0438\u0442\u044C \u0438 \u0437\u0432\u0430\u043B\u0438 \u043D\u0430 \u0432\u0441\u0442\u0440\u0435\u0447\u0443",
  "id" : 135334507246129152,
  "created_at" : "2011-11-12 12:33:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135331759528222720",
  "text" : "Trolled enough\nNo matter what I hear you say\nI've trolled enough to know you gotta go...\n\ndoink bloink sloop budoink\ndoubidouwap",
  "id" : 135331759528222720,
  "created_at" : "2011-11-12 12:23:00 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134320940615077888",
  "text" : "\u041D\u0430\u0447\u0430\u043B \u0435\u0436\u0435\u0434\u043D\u0435\u0432\u043D\u043E \u0432\u044B\u043A\u0440\u0430\u0438\u0432\u0430\u0442\u044C \u043D\u0435\u043C\u043D\u043E\u0433\u043E \u0432\u0440\u0435\u043C\u0435\u043D\u0438 \u043D\u0430 \u043D\u0430\u043F\u0438\u0441\u0430\u043D\u0438\u0435 \u043F\u0438\u043A\u0441\u0435\u043B\u044C\u043D\u043E\u0433\u043E \u043A\u0432\u0435\u0441\u0442\u0430. \u0418\u0434\u0435\u0438 \u043F\u043E\u043A\u0430 \u043D\u0435\u0442, \u0442\u043E\u043B\u044C\u043A\u043E \u0441\u0438\u043D\u0442\u0435\u0437\u0430\u0442\u043E\u0440 \u0432 \u0441\u0442\u0438\u043B\u0435 pre-sound blaster.",
  "id" : 134320940615077888,
  "created_at" : "2011-11-09 17:26:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/vqKqKdW",
      "expanded_url" : "http:\/\/smart-lab.ru\/uploads\/images\/00\/09\/33\/2011\/11\/08\/3c8dce.png",
      "display_url" : "smart-lab.ru\/uploads\/images\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "133904965763727360",
  "text" : "http:\/\/t.co\/vqKqKdW\n\u0442\u0435\u0445\u043D\u0438\u0447\u0435\u0441\u043A\u0438\u0439 \u0430\u043D\u0430\u043B\u0438\u0437",
  "id" : 133904965763727360,
  "created_at" : "2011-11-08 13:53:26 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 19 ],
      "url" : "http:\/\/t.co\/3tgJWPZ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=LT1Mb8oPjPI",
      "display_url" : "youtube.com\/watch?v=LT1Mb8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "133875581480742913",
  "text" : "http:\/\/t.co\/3tgJWPZ\n\u0432 \u0442\u0430\u043A\u0438\u0435 \u043C\u043E\u043C\u0435\u043D\u0442\u044B \u043D\u0443\u0436\u043D\u043E \u0431\u044B\u0442\u044C \u043D\u0430 \u0441\u0446\u0435\u043D\u0435",
  "id" : 133875581480742913,
  "created_at" : "2011-11-08 11:56:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133201446438047746",
  "text" : "Day One, plaintext.",
  "id" : 133201446438047746,
  "created_at" : "2011-11-06 15:17:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/y63LwIh",
      "expanded_url" : "http:\/\/img.ly\/a9Rj",
      "display_url" : "img.ly\/a9Rj"
    } ]
  },
  "geo" : { },
  "id_str" : "133014884773400577",
  "text" : "You have that awfull curse!- what curse? - \u041F\u0435\u0440\u0444\u0435\u043A\u0446\u0438\u043E\u043D\u0438\u0437\u043C \u0432 \u043F\u0440\u043E\u0433\u0440\u0430\u043C\u043C\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0438 :\\ \u043B\u0443\u0447\u0448\u0435 \u0431\u044B always kidding :[ http:\/\/t.co\/y63LwIh",
  "id" : 133014884773400577,
  "created_at" : "2011-11-06 02:56:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132826131589103616",
  "text" : "1. \u0411\u0435\u0437\u043E\u0442\u043D\u043E\u0441\u0438\u0442\u0435\u043B\u044C\u043D\u043E \u0437\u0430\u043A\u0440\u044B\u0432\u0430\u0439 \u043F\u043E\u0437\u0438\u0446\u0438\u0438 \n2. \u0427\u0443\u0432\u0441\u0442\u0432\u0443\u0439 \u0441\u0442\u0430\u043D\u0434\u0430\u0440\u0442\u043D\u043E\u0435 \u043E\u0442\u043A\u043B\u043E\u043D\u0435\u043D\u0438\u0435 \u0432 \u043C\u0438\u043D\u0443\u0442\u0435\n3. \u0421\u0442\u0430\u0432\u044C \u043C\u0438\u043D\u0438\u043C\u0430\u043B\u044C\u043D\u044B\u0439 \u0442\u0435\u0439\u043A \n\n= profit!11",
  "id" : 132826131589103616,
  "created_at" : "2011-11-05 14:26:32 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132824957347569665",
  "text" : "\u0421\u043E\u0441\u0442\u0430\u0432\u0438\u043B \u0443\u0436\u0435 \u0434\u043E\u0431\u0440\u044B\u0439 \u0434\u0435\u0441\u044F\u0442\u043E\u043A \u0441\u043F\u0438\u0441\u043A\u043E\u0432 \u0442\u043E\u0440\u0433\u043E\u0432\u044B\u0445 \u043F\u0440\u0430\u0432\u0438\u043B \u0434\u043B\u044F \u0441\u043A\u0430\u043B\u044C\u043F\u0438\u043D\u0433\u0430 \u0444\u044C\u044E\u0447\u0430 \u0440\u0442\u0441, \u043D\u0430 \u0434\u0430\u043D\u043D\u044B\u0439 \u043C\u043E\u043C\u0435\u043D\u0442 \u043E\u0441\u0442\u0430\u043B\u043E\u0441\u044C \u0442\u0440\u0438 \u0431\u0430\u0437\u043E\u0432\u044B\u0445 \u043F\u0443\u043D\u043A\u0442\u0430:",
  "id" : 132824957347569665,
  "created_at" : "2011-11-05 14:21:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132823931919925250",
  "text" : "\u041F\u043E\u0435\u0434\u0443 \u0432 \u0414\u041E\u041C \u043D\u0430 Diatribes \u043A 19 \u0442\u0440\u0435\u0437\u0432\u044B\u0439 \u043A\u0430\u043A \u043F\u0435\u0440\u0441\u0442 \u0438 \u043E\u0434\u0438\u043D \u043A\u0430\u043A \u0441\u0442\u0435\u043A\u043B\u043E ofc.",
  "id" : 132823931919925250,
  "created_at" : "2011-11-05 14:17:47 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 44 ],
      "url" : "http:\/\/t.co\/DTkavsl",
      "expanded_url" : "http:\/\/img.ly\/a6mK",
      "display_url" : "img.ly\/a6mK"
    } ]
  },
  "geo" : { },
  "id_str" : "132504847726542850",
  "text" : "or you can get with that http:\/\/t.co\/DTkavsl",
  "id" : 132504847726542850,
  "created_at" : "2011-11-04 17:09:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 102 ],
      "url" : "http:\/\/t.co\/vFiZzK1",
      "expanded_url" : "http:\/\/img.ly\/a6iJ",
      "display_url" : "img.ly\/a6iJ"
    } ]
  },
  "geo" : { },
  "id_str" : "132504796170166277",
  "text" : "the next step in my argument is just no more damn arty-farty macabre tranny issues http:\/\/t.co\/vFiZzK1",
  "id" : 132504796170166277,
  "created_at" : "2011-11-04 17:09:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 108 ],
      "url" : "http:\/\/t.co\/VeL5b8V",
      "expanded_url" : "http:\/\/img.ly\/a6hJ",
      "display_url" : "img.ly\/a6hJ"
    } ]
  },
  "geo" : { },
  "id_str" : "132483440544194560",
  "text" : "\u041B\u0435\u0436\u0443 \u0432 \u043F\u0443\u0441\u0442\u043E\u043C \u043E\u0444\u0438\u0441\u0435 \u043D\u0430 \u0430\u043C\u043E\u0440\u0444\u043D\u043E\u0439 \u043F\u043E\u0434\u0443\u0448\u043A\u0435 \u0438 \u043F\u043E\u0434 \u0447\u0430\u0439 \u0438\u0437 \u0440\u043E\u043C\u0430\u0448\u043A\u0438 \u043E\u0441\u043C\u0430\u0442\u0440\u0438\u0432\u0430\u044E \u043D\u043E\u043C\u0435\u0440\u0430 citizen k http:\/\/t.co\/VeL5b8V tranny?",
  "id" : 132483440544194560,
  "created_at" : "2011-11-04 15:44:48 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/sopzrmg",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=78XrI_2bPVA",
      "display_url" : "youtube.com\/watch?v=78XrI_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "132444640698826752",
  "text" : "Tim Minchin - Some people have it worse than I : http:\/\/t.co\/sopzrmg",
  "id" : 132444640698826752,
  "created_at" : "2011-11-04 13:10:37 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pridekills",
      "screen_name" : "pride_kills",
      "indices" : [ 3, 15 ],
      "id_str" : "214165006",
      "id" : 214165006
    }, {
      "name" : "\u05D9\u05E9\u05DF \u05D0\u05DA \u05DC\u05D0 \u05DE\u05D9\u05D5\u05E9\u05DF",
      "screen_name" : "juliyvchirkov",
      "indices" : [ 17, 31 ],
      "id_str" : "483236233",
      "id" : 483236233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132358123318026240",
  "text" : "RT @pride_kills: @juliyvchirkov \u044F \u0445\u043E\u0434\u0438\u043B \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u0438\u0439 \u043C\u0430\u0440\u0448, \u043A\u043E\u0433\u0434\u0430 \u043C\u043D\u043E\u0433\u0438\u0435 \u0438\u0437 \u0432\u0430\u0441 \u0435\u0449\u0435 \u043D\u0435 \u0431\u044B\u043B\u0438 \u0440\u0443\u0441\u0441\u043A\u0438\u043C\u0438!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u05D9\u05E9\u05DF \u05D0\u05DA \u05DC\u05D0 \u05DE\u05D9\u05D5\u05E9\u05DF",
        "screen_name" : "juliyvchirkov",
        "indices" : [ 0, 14 ],
        "id_str" : "483236233",
        "id" : 483236233
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "132337877462958080",
    "text" : "@juliyvchirkov \u044F \u0445\u043E\u0434\u0438\u043B \u043D\u0430 \u0440\u0443\u0441\u0441\u043A\u0438\u0439 \u043C\u0430\u0440\u0448, \u043A\u043E\u0433\u0434\u0430 \u043C\u043D\u043E\u0433\u0438\u0435 \u0438\u0437 \u0432\u0430\u0441 \u0435\u0449\u0435 \u043D\u0435 \u0431\u044B\u043B\u0438 \u0440\u0443\u0441\u0441\u043A\u0438\u043C\u0438!",
    "id" : 132337877462958080,
    "created_at" : "2011-11-04 06:06:23 +0000",
    "user" : {
      "name" : "pridekills",
      "screen_name" : "pride_kills",
      "protected" : false,
      "id_str" : "214165006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3542571928\/744471cb7643d09168bae2ea86b76939_normal.jpeg",
      "id" : 214165006,
      "verified" : false
    }
  },
  "id" : 132358123318026240,
  "created_at" : "2011-11-04 07:26:50 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Levitt",
      "screen_name" : "AaronLevitt",
      "indices" : [ 3, 15 ],
      "id_str" : "90885914",
      "id" : 90885914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131360013255061504",
  "text" : "RT @AaronLevitt: Damn it Greece...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131359347719684098",
    "text" : "Damn it Greece...",
    "id" : 131359347719684098,
    "created_at" : "2011-11-01 13:18:03 +0000",
    "user" : {
      "name" : "Aaron Levitt",
      "screen_name" : "AaronLevitt",
      "protected" : false,
      "id_str" : "90885914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1043196482617257984\/cEafFGCg_normal.jpg",
      "id" : 90885914,
      "verified" : false
    }
  },
  "id" : 131360013255061504,
  "created_at" : "2011-11-01 13:20:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131359193750962178",
  "text" : "\u05D0\u05DE\u05D0 \u05DC\u05DE\u05D4 \u05D0\u05E0\u05D9 \u05DC\u05D0 \u05DC\u05DE\u05DB\u05D5\u05E8 \u05D0\u05EA \u05E2\u05E6\u05DE\u05DA \u05E7\u05E6\u05E8 ))",
  "id" : 131359193750962178,
  "created_at" : "2011-11-01 13:17:26 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131357514666221571",
  "text" : "\u041F\u0430\u043F\u0430\u043D\u0434\u0440\u0435\u0443 \u0432\u044B\u0441\u043A\u0430\u0437\u0430\u043B\u0441\u044F, \u0444\u044C\u044E\u0447\u0435\u0440\u0441 \u043D\u0430 \u0438\u043D\u0434\u0435\u043A\u0441 \u0440\u0442\u0441 \u043E\u0442\u043B\u0435\u0442\u0435\u043B \u043D\u0430 6.6%, \u043C\u043C\u0432\u0431 \u0437\u0430\u043A\u0440\u044B\u043B\u0438 )",
  "id" : 131357514666221571,
  "created_at" : "2011-11-01 13:10:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]