Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460402278005215232",
  "text" : "\u041F\u0430\u0440\u043E\u0434\u0438\u044F \u0432\u0437\u044F\u043B\u0430\u0441\u044C \u0438\u0437 \u0440\u0430\u043F\u0441\u043E\u0434\u0438\u0438, \u043F\u0430\u043D\u0442\u043E\u043C\u0438\u043C\u0430 \u043F\u0440\u043E\u0438\u0437\u043E\u0448\u043B\u0430 \u0438\u0437 \u043A\u043E\u043C\u0435\u0434\u0438\u0438, \u0441\u0430\u0442\u0438\u0440\u0430 \u043E\u0442 \u0442\u0440\u0430\u0433\u0435\u0434\u0438\u0438,\u0435\u0441\u043B\u0438 \u0442\u0435\u0431\u0435 \u0434\u0430\u043B\u0430 \u0434\u0435\u0432\u0443\u0448\u043A\u0430 \u0443\u0440\u043E\u0432\u043D\u044F Mary Charteris-\u044D\u0442\u043E \u043D\u0435 \u0442\u0440\u0430\u0433\u0435\u0434\u0438\u044F",
  "id" : 460402278005215232,
  "created_at" : "2014-04-27 12:57:11 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460390244236656640",
  "text" : "\"\u041A\u0418\u0422\u0410\u0419\u0426\u042B \u041B\u042E\u0411\u042F\u0422 \u041F\u041E\u041A\u0423\u041F\u0410\u0422\u042C \u0411\u041E\u041B\u042C\u0428\u0418\u0415 \u0411\u0420\u0415\u041D\u0414\u042B \u0421 \u041B\u041E\u0413\u041E\u0422\u0418\u041F\u0410\u041C\u0418, \u0427\u0422\u041E\u0411\u042B \u0412\u0421\u0415 \u041C\u041E\u0413\u041B\u0418 \u041E\u0422\u041C\u0415\u0422\u0418\u0422\u042C \u0423\u0420\u041E\u0412\u0415\u041D\u042C \u0418\u0425 \u0411\u041B\u0410\u0413\u041E\u041F\u041E\u041B\u0423\u0427\u0418\u042F. \u042D\u0422\u041E \u0418\u0414\u0415\u0422 \u0418\u0417 \u0413\u041B\u0423\u0411\u0418\u041D \u0421\u041E\u0417\u041D\u0410\u041D\u0418\u042F, \u041C\u0415\u041D\u0422-\u0422\u0410\"",
  "id" : 460390244236656640,
  "created_at" : "2014-04-27 12:09:22 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459655980771737600",
  "text" : "\u2026 \u044F \u0431\u044B \u0441 \u0440\u0430\u0434\u043E\u0441\u0442\u044C\u044E, \u043D\u043E \u044D\u0442\u043E\u043C\u0443 \u0443\u0436\u0435 \u043F\u043E\u0441\u0432\u044F\u0449\u0435\u043D\u0430 \u043E\u043F\u0435\u0440\u0430 \u0414\u0436\u0435\u0439\u043C\u0441\u0430 \u041C\u0430\u0440\u0432\u0435\u043B\u0430 \u0438 Gotham Chamber Opera \u0441 \u043C\u0443\u0437\u044B\u043A\u043E\u0439 \u041B\u0435\u043C\u0431\u0438\u0442 \u0411\u0438\u0447\u0435\u0440\u0430 \u00AB\u041C\u043D\u0435 \u043D\u0435\u0447\u0435\u0433\u043E \u0442\u0435\u0431\u0435 \u0440\u0430\u0441\u0441\u043A\u0430\u0437\u0430\u0442\u044C\u00BB",
  "id" : 459655980771737600,
  "created_at" : "2014-04-25 11:31:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459277532941283328",
  "text" : "\u0430\u0441\u0441\u043E\u0440\u0442\u0438\u043C\u0435\u043D\u0442\u0430 \u043E\u0431\u0441\u0442\u0430\u043D\u043E\u0432\u043E\u043A \u0432 \u043F\u0440\u043E\u0446\u0435\u0441\u0441\u0435 \u044D\u043A\u0437\u0438\u0441\u0442\u0435\u043D\u0446\u0438\u0430\u043B\u044C\u043D\u043E\u0433\u043E \u0448\u043E\u043F\u0438\u043D\u0433\u0430, \u044F \u043A\u0430\u0436\u0434\u044B\u0439 \u0440\u0430\u0437 \u043D\u0430\u0434\u0435\u0432\u0430\u044E \u0441\u043C\u043E\u043A\u0438\u043D\u0433,  \u043F\u0435\u0440\u0435\u0434 \u0442\u0435\u043C \u043A\u0430\u043A \u043F\u0435\u0440\u0435\u0434\u0435\u0440\u043D\u0443\u0442\u044C \u043D\u0430 Mary Charteris",
  "id" : 459277532941283328,
  "created_at" : "2014-04-24 10:27:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459277483876315136",
  "text" : "\u043F\u043E\u0434\u043E\u0431\u043D\u043E \u0430\u043D\u0433\u0435\u043B\u0430\u043C, \u043A\u043E\u0442\u043E\u0440\u044B\u0435 \u0441\u043E\u0433\u043B\u0430\u0441\u043D\u043E \u0422\u0430\u043B\u043C\u0443\u0434\u0443, \u043F\u043E\u044E\u0442 \u0445\u0432\u0430\u043B\u0443 \u0411-\u0433\u0443 \u0438 \u0432\u043D\u0435\u0437\u0430\u043F\u043D\u043E \u0438\u0441\u0447\u0435\u0437\u0430\u044E\u0442 \u0432 \u043D\u0438\u0447\u0442\u043E, \u0432\u044B\u0431\u0438\u0440\u0430\u044F \u0438\u0437 \u043E\u0440\u0438\u0433\u0438\u043D\u0430\u043B\u044C\u043D\u043E\u0433\u043E",
  "id" : 459277483876315136,
  "created_at" : "2014-04-24 10:27:39 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003ETwitter Web App\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458541816615555072",
  "text" : "\u043D\u0430\u0448\u0438\u043C \u043C\u0430\u043B\u0435\u043D\u044C\u043A\u0438\u043C, \u043A\u0430\u043A \u0432\u043E\u043B\u043E\u0441 \u0432 \u0442\u0432\u043E\u0435\u043C \u0440\u0442\u0443, \u0441\u0435\u043A\u0440\u0435\u0442\u043E\u043C",
  "id" : 458541816615555072,
  "created_at" : "2014-04-22 09:44:23 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458317384823357440",
  "text" : "\u041D\u0430\u0441\u043B\u0430\u0436\u0434\u0435\u043D\u0438\u0435 \u043D\u0430\u0447\u0438\u043D\u0430\u0435\u0442 \u043D\u0430\u0434\u043E\u0435\u0434\u0430\u0442\u044C",
  "id" : 458317384823357440,
  "created_at" : "2014-04-21 18:52:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]