Grailbird.data.tweets_2012_07 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A4\u30A8\u30BD\u30C9",
      "screen_name" : "Yesodd",
      "indices" : [ 3, 10 ],
      "id_str" : "1047091669395361797",
      "id" : 1047091669395361797
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "225910573945212928",
  "text" : "RT @Yesodd: \u0432 \u043B\u0435\u043D\u0442\u0435 \u043F\u043E\u0434 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D\u0438\u0435 \u0433\u043E\u0432\u043E\u0440\u044F\u0442 \u043E \u0415\u0414\u0415. \u0415\u0414\u042B, \u043A \u0441\u043E\u0436\u0430\u043B\u0435\u043D\u0438\u044E, \u0432 \u043C\u0441\u043A \u043D\u0435\u0442, \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u0440\u0435\u0439\u0444\u043D\u0430\u044F \u0445\u0438\u043C\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043B\u0430\u0431\u0443\u0434\u0430.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "225900439047135232",
    "text" : "\u0432 \u043B\u0435\u043D\u0442\u0435 \u043F\u043E\u0434 \u043D\u0430\u0441\u0442\u0440\u043E\u0435\u043D\u0438\u0435 \u0433\u043E\u0432\u043E\u0440\u044F\u0442 \u043E \u0415\u0414\u0415. \u0415\u0414\u042B, \u043A \u0441\u043E\u0436\u0430\u043B\u0435\u043D\u0438\u044E, \u0432 \u043C\u0441\u043A \u043D\u0435\u0442, \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u0440\u0435\u0439\u0444\u043D\u0430\u044F \u0445\u0438\u043C\u0438\u0447\u0435\u0441\u043A\u0430\u044F \u043B\u0430\u0431\u0443\u0434\u0430.",
    "id" : 225900439047135232,
    "created_at" : "2012-07-19 10:30:36 +0000",
    "user" : {
      "name" : "Alex Yesod",
      "screen_name" : "rebyesod",
      "protected" : false,
      "id_str" : "260654136",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/977302789570420736\/WvStOAyG_normal.jpg",
      "id" : 260654136,
      "verified" : false
    }
  },
  "id" : 225910573945212928,
  "created_at" : "2012-07-19 11:10:52 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/0w8KZyiV",
      "expanded_url" : "http:\/\/youtu.be\/RxH_saKDHEI",
      "display_url" : "youtu.be\/RxH_saKDHEI"
    } ]
  },
  "geo" : { },
  "id_str" : "223969859892031488",
  "text" : "http:\/\/t.co\/0w8KZyiV \u043A\u0440\u0430\u0442\u043A\u043E\u0435 \u0438 \u0442\u043E\u0447\u043D\u043E\u0435 \u0438\u0437\u043B\u043E\u0436\u0435\u043D\u0438\u0435 \u043C\u043E\u0438\u0445 \u043F\u0440\u0438\u043D\u0446\u0438\u043F\u043E\u0432 \u0438 \u0443\u0431\u0435\u0436\u0434\u0435\u043D\u0438\u0439",
  "id" : 223969859892031488,
  "created_at" : "2012-07-14 02:39:10 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/NLgV9h4r",
      "expanded_url" : "http:\/\/youtu.be\/L95KBuwGNDY",
      "display_url" : "youtu.be\/L95KBuwGNDY"
    } ]
  },
  "geo" : { },
  "id_str" : "223946231255277569",
  "text" : "http:\/\/t.co\/NLgV9h4r i was in love with the idea of being in love with a woman way before I was actually in love with one",
  "id" : 223946231255277569,
  "created_at" : "2012-07-14 01:05:16 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "222049842497728514",
  "text" : "The \u03B1\u03B8\u03B5\u03C9\u0432\u03C1\u03B1\u03C7\u03BC\u03AC\u03BD\u03C9\u03C1\u03B9\u03B8\u03BC\u03B7\u03C4\u03B9\u03BA\u03AE day",
  "id" : 222049842497728514,
  "created_at" : "2012-07-08 19:29:42 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0432\u0441\u0435\u0433\u0434\u0430 \u0442\u0430\u043A \u0434\u0435\u043B\u0430\u044E!",
      "screen_name" : "romandos",
      "indices" : [ 0, 9 ],
      "id_str" : "75751947",
      "id" : 75751947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "221839058735869952",
  "in_reply_to_user_id" : 75751947,
  "text" : "@romandos, \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u043B\u0438 \u0431\u0438\u043B\u0434 \u043D\u0430 \u0440\u0435\u043B\u0438\u0437. waiting for review",
  "id" : 221839058735869952,
  "created_at" : "2012-07-08 05:32:07 +0000",
  "in_reply_to_screen_name" : "romandos",
  "in_reply_to_user_id_str" : "75751947",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/twitterrific.com\/ios\" rel=\"nofollow\"\u003ETwitterrific for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "220481310546870274",
  "text" : "Three region",
  "id" : 220481310546870274,
  "created_at" : "2012-07-04 11:36:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]