Grailbird.data.tweets_2015_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "626854613094957056",
  "text" : "\u0437\u0430 \u0434\u0435\u043D\u044C \u0434\u043E \u0434\u0435\u0434\u043B\u0430\u0439\u043D\u0430 \u0442\u044B - \u0441\u0430\u043C\u0430 \u043D\u043E\u0447\u044C, \u0442\u044B \u0432\u0435\u0441\u0435\u043B\u0438\u0448\u044C\u0441\u044F \u0441 \u043C\u0438\u043B\u043B\u0438\u043E\u043D\u043E\u043C \u043F\u0435\u0447\u0430\u0442\u043D\u044B\u0445 \u0437\u043D\u0430\u043A\u043E\u0432, \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E\u0431\u044B \u0432 \u043E\u0447\u0435\u0440\u0435\u0434\u043D\u043E\u0439, \u043C\u0438\u043B\u043B\u0438\u043E\u043D\u043D\u044B\u0439 \u0440\u0430\u0437 \u0437\u0430\u0442\u0440\u043E\u043B\u043B\u0438\u0442\u044C \u044D\u0442\u0443 \u0436\u0438\u0437\u043D\u044C",
  "id" : 626854613094957056,
  "created_at" : "2015-07-30 20:39:20 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621644340218216448",
  "text" : "console &amp; serpentine",
  "id" : 621644340218216448,
  "created_at" : "2015-07-16 11:35:34 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "621447249873235968",
  "text" : "\u0412\u0447\u0435\u0440\u0430\u0448\u043D\u044F\u044F Canto Ostinato \u0442\u0435\u043D \u0425\u043E\u043B\u044C\u0442\u0430 \u0432 MAMM \u0438 \u043D\u0435\u0434\u0430\u0432\u043D\u0438\u0435 \u00AB\u0412\u0440\u0435\u043C\u0435\u043D\u0430 \u0433\u043E\u0434\u0430\u00BB \u041C\u0430\u0440\u0442\u044B\u043D\u043E\u0432\u0430 \u043E\u0442 Opus Posth \u2013 \u044D\u0442\u043E \u0434\u0432\u0430 \u0443\u0434\u0430\u0447\u043D\u044B\u0445 \u0432\u0435\u0447\u0435\u0440\u0430",
  "id" : 621447249873235968,
  "created_at" : "2015-07-15 22:32:24 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]