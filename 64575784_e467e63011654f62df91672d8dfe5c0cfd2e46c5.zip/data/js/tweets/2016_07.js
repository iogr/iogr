Grailbird.data.tweets_2016_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/0wcKssZ4CO",
      "expanded_url" : "http:\/\/shz.am\/t10847217",
      "display_url" : "shz.am\/t10847217"
    } ]
  },
  "geo" : { },
  "id_str" : "757220294033563651",
  "text" : "\u0421 \u043F\u043E\u043C\u043E\u0449\u044C\u044E Shazam \u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E \u043D\u0430\u0448\u0435\u043B To Mickey's Memory \u043E\u0442 Chet Baker. https:\/\/t.co\/0wcKssZ4CO",
  "id" : 757220294033563651,
  "created_at" : "2016-07-24 14:26:01 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/j11bnrtwmv",
      "expanded_url" : "http:\/\/shz.am\/t264376",
      "display_url" : "shz.am\/t264376"
    } ]
  },
  "geo" : { },
  "id_str" : "749546701439037440",
  "text" : "\u0421 \u043F\u043E\u043C\u043E\u0449\u044C\u044E Shazam \u044F \u0442\u043E\u043B\u044C\u043A\u043E \u0447\u0442\u043E \u043D\u0430\u0448\u0435\u043B Straighten Up And Fly Right \u043E\u0442 Nat King Cole. https:\/\/t.co\/j11bnrtwmv",
  "id" : 749546701439037440,
  "created_at" : "2016-07-03 10:13:54 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]