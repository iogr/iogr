Grailbird.data.tweets_2015_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 55 ],
      "url" : "https:\/\/t.co\/AkQMtXWLtk",
      "expanded_url" : "https:\/\/ridero.ru\/books\/prototype466\/",
      "display_url" : "ridero.ru\/books\/prototyp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "681917347519672322",
  "text" : "\u0421\u0438\u043C\u043E\u043D \u041B\u0438\u0431\u0435\u0440\u0442\u0438\u043D \u2014 Prototype466 \u2014 https:\/\/t.co\/AkQMtXWLtk",
  "id" : 681917347519672322,
  "created_at" : "2015-12-29 19:18:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "678517736402771968",
  "text" : "Run, run Rudolph, Santa's got to make it to town\n\nRun, run Rudolph, reeling like a merry-go-round",
  "id" : 678517736402771968,
  "created_at" : "2015-12-20 10:10:09 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "677538561059651584",
  "text" : "\u0415\u0441\u043B\u0438 \u043F\u0438\u0448\u0435\u0448\u044C \u0440\u043E\u043C\u0430\u043D \u043F\u0440\u043E \u0441\u0435\u043A\u0441, \u043D\u0430\u0440\u043A\u043E\u0442\u0438\u043A\u0438 \u0438 \u0440\u043E\u043A-\u043D-\u0440\u043E\u043B\u043B, \u0431\u0443\u0434\u044C \u0433\u043E\u0442\u043E\u0432 \u043A \u0442\u043E\u043C\u0443, \u0447\u0442\u043E \u0438\u0437\u0434\u0430\u0442\u0435\u043B\u044C \u043F\u043E\u0442\u0440\u0435\u0431\u0443\u0435\u0442 \u0443\u0434\u0430\u043B\u0438\u0442\u044C \u0438\u0437 \u043D\u0435\u0433\u043E \u0441\u0435\u043A\u0441, \u043D\u0430\u0440\u043A\u043E\u0442\u0438\u043A\u0438 \u0438 \u0440\u043E\u043A-\u043D-\u0440\u043E\u043B\u043B.",
  "id" : 677538561059651584,
  "created_at" : "2015-12-17 17:19:15 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676106304339836928",
  "text" : "\u041D\u0430 \u0430\u0440\u0431\u0430\u0442\u0435 \u043F\u043E\u0442\u0435\u0440\u044F\u043B\u0441\u044F \u0440\u0443\u0447\u043D\u043E\u0439 \u0445\u043E\u0440\u0435\u043A",
  "id" : 676106304339836928,
  "created_at" : "2015-12-13 18:27:59 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "676041137489108992",
  "text" : "Thomas Brinkmann",
  "id" : 676041137489108992,
  "created_at" : "2015-12-13 14:09:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "675765182417805312",
  "text" : "\u0421\u0445\u043E\u0434\u0438\u043B \u0447\u0435\u0440\u0435\u0437 \u0431\u043E\u043B\u044C \u043D\u0430 Zilberman \u0438 \u043D\u0435 \u0431\u044B\u043B \u0440\u0430\u0437\u043E\u0447\u0430\u0440\u043E\u0432\u0430\u043D",
  "id" : 675765182417805312,
  "created_at" : "2015-12-12 19:52:29 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ui5CpPMqsH",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=8C-MO3QSXUc",
      "display_url" : "youtube.com\/watch?v=8C-MO3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "675272989286539264",
  "text" : "https:\/\/t.co\/ui5CpPMqsH \u041F\u043E\u043A\u0430 \u044F \u043F\u0438\u0441\u0430\u043B \u043F\u0435\u0440\u0432\u044B\u0439 \u0440\u043E\u043C\u0430\u043D, \u041B\u0435\u043D\u0430 \u0443\u0441\u043F\u0435\u043B\u0430 \u0441\u043C\u0435\u043D\u0438\u0442\u044C \u0434\u0432\u0430 \u0432\u0438\u0434\u0430 \u0435\u0432\u0430\u043D\u0433\u0435\u043B\u0438\u0437\u043C\u0430",
  "id" : 675272989286539264,
  "created_at" : "2015-12-11 11:16:41 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "674384882865311744",
  "text" : "quoad one's cybernetic organism the underworld of depression turns up and out to be tbe hammered-solo psychic region",
  "id" : 674384882865311744,
  "created_at" : "2015-12-09 00:27:40 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 38, 46 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 33 ],
      "url" : "https:\/\/t.co\/nIBvP0UI58",
      "expanded_url" : "https:\/\/youtu.be\/r4E7JqG3AvY",
      "display_url" : "youtu.be\/r4E7JqG3AvY"
    } ]
  },
  "geo" : { },
  "id_str" : "674006303052832768",
  "text" : "maoz tzur https:\/\/t.co\/nIBvP0UI58 via @YouTube",
  "id" : 674006303052832768,
  "created_at" : "2015-12-07 23:23:19 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673931990421360640",
  "text" : "jerome romain wears romain jerome",
  "id" : 673931990421360640,
  "created_at" : "2015-12-07 18:28:02 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "673629376995528704",
  "text" : "\u041D\u0435 \u0438\u0434\u0435\u0430\u043B\u044C\u043D\u043E - \u0432\u044B\u0431\u0440\u0430\u0441\u044B\u0432\u0430\u0435\u0448\u044C.",
  "id" : 673629376995528704,
  "created_at" : "2015-12-06 22:25:33 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672461595365216256",
  "text" : "Cadence Symphony meets Major Umlaut",
  "id" : 672461595365216256,
  "created_at" : "2015-12-03 17:05:12 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672192382507606016",
  "text" : "\u044F \u0432\u0438\u0434\u0435\u043B \u0445\u0443\u0434\u0448\u0438\u0435 \u043A\u0443\u0440\u0442\u043A\u0438 \u0441\u0432\u043E\u0435\u0433\u043E \u043F\u043E\u043A\u043E\u043B\u0435\u043D\u0438\u044F, \u0432\u044B\u0440\u0432\u0430\u043D\u043D\u044B\u0435 \u0432\u043E\u0441\u043A\u043E\u043C \u0438\u0437 \u0447\u0435\u0440\u043D\u043E\u0433\u043E \u0431\u0435\u0437\u0443\u043C\u0438\u044F",
  "id" : 672192382507606016,
  "created_at" : "2015-12-02 23:15:27 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "672020326855925760",
  "text" : "Steven Jesse Bernstein",
  "id" : 672020326855925760,
  "created_at" : "2015-12-02 11:51:46 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "671693764335902721",
  "text" : "\u0411\u0430\u043B\u044C\u0434\u0430\u0441\u0441\u0430\u0440\u0435 \u0413\u0430\u043B\u0443\u043F\u043F\u0438",
  "id" : 671693764335902721,
  "created_at" : "2015-12-01 14:14:07 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]