Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613231727654404096",
  "text" : "\u0438 \u043F\u0440\u0435\u0441\u0435\u0447\u0435\u043D\u0438\u0435 \u043C\u043E\u0440\u044F \u043D\u043E\u0447\u0438, \u0438 \u043F\u0440\u0435\u043B\u043E\u043C\u043B\u0435\u043D\u0438\u0435 \u0445\u043B\u0435\u0431\u0430 \u0434\u043D\u044F",
  "id" : 613231727654404096,
  "created_at" : "2015-06-23 06:26:51 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612308116986851328",
  "text" : "Loop Minded Individuals fit great for one of those unplugging-prohibited days",
  "id" : 612308116986851328,
  "created_at" : "2015-06-20 17:16:45 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611436707750219776",
  "text" : "\u0412\u043D\u0438\u043C\u0430\u043D\u0438\u0435! \u0414\u0430\u043D\u043D\u044B\u0439 \u0442\u0435\u043A\u0441\u0442 \u0438\u043C\u0435\u0435\u0442 \u0432\u043E\u0437\u0440\u0430\u0441\u0442\u043D\u044B\u0435 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u044F: \u041C\u043E\u0438\u0441\u0435\u0439 +",
  "id" : 611436707750219776,
  "created_at" : "2015-06-18 07:34:05 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041F\u0440\u043E\u0441\u0442\u043E \u2764\uFE0F \u041C\u0438\u043B\u0430",
      "screen_name" : "ProstoMilochka",
      "indices" : [ 0, 15 ],
      "id_str" : "441625387",
      "id" : 441625387
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "608651096240889856",
  "geo" : { },
  "id_str" : "608651631450796033",
  "in_reply_to_user_id" : 441625387,
  "text" : "@ProstoMilochka \u043F\u0430\u0448\u0443 \u0442\u0430\u043A \u043F\u0440\u043E\u0437\u0432\u0430\u043B\u0438 \u0438\u0437-\u0437\u0430 \u043D\u0435\u0440\u0432\u043D\u043E\u0433\u043E \u0442\u0438\u043A\u0430 :)",
  "id" : 608651631450796033,
  "in_reply_to_status_id" : 608651096240889856,
  "created_at" : "2015-06-10 15:07:11 +0000",
  "in_reply_to_screen_name" : "ProstoMilochka",
  "in_reply_to_user_id_str" : "441625387",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607265546296524800",
  "text" : "that's namely a backed by Adam Green's songs weekend",
  "id" : 607265546296524800,
  "created_at" : "2015-06-06 19:19:23 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]