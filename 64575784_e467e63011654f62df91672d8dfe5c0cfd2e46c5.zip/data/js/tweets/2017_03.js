Grailbird.data.tweets_2017_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/yIrTK11g2i",
      "expanded_url" : "https:\/\/shz.am\/t412736",
      "display_url" : "shz.am\/t412736"
    } ]
  },
  "geo" : { },
  "id_str" : "840965842120650752",
  "text" : "The Animals - Don't Bring Me Down https:\/\/t.co\/yIrTK11g2i",
  "id" : 840965842120650752,
  "created_at" : "2017-03-12 16:40:55 +0000",
  "user" : {
    "name" : "Anton Gorbunov",
    "screen_name" : "iogr",
    "protected" : false,
    "id_str" : "64575784",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/838834384\/15305390_normal.jpg",
    "id" : 64575784,
    "verified" : false
  }
} ]