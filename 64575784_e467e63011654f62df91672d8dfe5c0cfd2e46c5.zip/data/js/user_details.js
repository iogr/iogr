var user_details =  {
  "screen_name" : "iogr",
  "location" : "Moscow",
  "full_name" : "Anton Gorbunov",
  "bio" : "Doubidouwap",
  "id" : "64575784",
  "created_at" : "2009-08-11 00:58:41 +0000"
}